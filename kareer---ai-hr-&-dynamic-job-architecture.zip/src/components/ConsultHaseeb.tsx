import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { MarkdownView } from './MarkdownView';
import {
  Sparkles,
  Send,
  UserCheck,
  User,
  RefreshCw,
  HelpCircle,
  ShieldAlert,
  ArrowRight,
  Briefcase,
  TrendingUp,
  MessageSquare
} from 'lucide-react';

export const ConsultHaseeb: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `### Welcome! I'm Haseeb.

I serve as the Lead AI HR Consultant, Career Strategist, and Job Analysis Architect for **Kareer**. 

My core focus is making career guidance crystal-clear for students, job seekers, and hiring teams across **Pakistan** and **global remote markets**. Whether you are targeting student internships at **Nestlé** and **PepsiCo**, entry software roles at **Systems Limited**, or high-dollar remote roles from home, I am here to guide you.

**How can I assist your career or talent strategy today?**
- Tailoring your CV/resume for **Nestlé**, **PepsiCo**, or **Unilever** MTO cycles
- Breaking down KSAO behavioral questions for entry & mid-level interviews
- Localized salary guidance in **Pakistani Rupees (PKR)** or **Global Remote USD**
- Transitioning into modern tech roles (AI, Full-Stack, Data, Product)

*Note: My recommendations are AI-assisted consultative insights to help you draft materials and evaluate options. Final application and HR decisions remain your personal responsibility.*`,
      timestamp: 'Just now',
    },
  ]);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [userRole, setUserRole] = useState<'Student / Job Seeker' | 'Hiring Manager / HR'>('Student / Job Seeker');
  const [targetMarket, setTargetMarket] = useState('Pakistan (PKR) & Global Remote (USD)');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (messageText?: string) => {
    const textToSend = messageText || input;
    if (!textToSend.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    if (!messageText) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/consult-haseeb', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
          userRole,
          market: targetMarket,
        }),
      });

      const data = await res.json();
      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.reply || "I apologize, but I couldn't process that query. Please try again.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.error('Failed to consult Haseeb', err);
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content:
          "### Connection Notice\nI encountered a transient connection issue. Remember: whether applying for a student internship at Nestlé or a remote USD developer role, always quantify your projects and leadership using the Google XYZ formula. Please retry your query!",
        timestamp: 'Just now',
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickPrompt = (prompt: string) => {
    handleSend(prompt);
  };

  const quickPrompts = [
    'How do I crack the Nestlé or PepsiCo MTO assessment and interview?',
    'What should a Pakistani student put on a resume if they have zero formal experience?',
    'How can I land a $1,500/month remote software job while living in Pakistan?',
    'What is a fair entry salary in PKR for a fresh graduate in Lahore/Karachi?',
  ];

  return (
    <div className="space-y-6">
      {/* Intro Header - Light Theme */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center justify-center font-bold text-lg">
              <UserCheck className="w-6 h-6 text-emerald-700" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-slate-900">Consult with Haseeb</h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                  Lead AI HR Consultant
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Direct strategic advisory on Pakistani internships, MTO preparation, resume polishing, and remote USD work.
              </p>
            </div>
          </div>

          {/* Context Selectors */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl text-xs">
              <span className="text-slate-500 text-[11px]">Role:</span>
              <select
                value={userRole}
                onChange={(e) => setUserRole(e.target.value as any)}
                className="bg-transparent text-slate-800 font-semibold focus:outline-none cursor-pointer"
              >
                <option value="Student / Job Seeker">Student / Job Seeker</option>
                <option value="Hiring Manager / HR">Hiring Manager / HR</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl text-xs">
              <span className="text-slate-500 text-[11px]">Market:</span>
              <select
                value={targetMarket}
                onChange={(e) => setTargetMarket(e.target.value)}
                className="bg-transparent text-slate-800 font-semibold focus:outline-none cursor-pointer"
              >
                <option value="Pakistan (PKR) & Global Remote (USD)">Pakistan PKR & Remote USD</option>
                <option value="Pakistan (Lahore / Karachi)">Pakistan Onsite (Lahore/Karachi)</option>
                <option value="UAE / GCC (AED)">UAE / GCC (Dubai AED)</option>
                <option value="Global Remote (USD)">100% Remote (USD)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="mt-4 flex flex-wrap gap-2">
          {quickPrompts.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleQuickPrompt(q)}
              disabled={loading}
              className="text-xs px-3 py-1.5 rounded-lg bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border border-slate-200 hover:border-emerald-300 transition-all font-medium flex items-center gap-1.5 text-left"
            >
              <Sparkles className="w-3 h-3 text-emerald-600 shrink-0" />
              <span>{q}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Box */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col h-[580px]">
        {/* Scrollable Message List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 bg-slate-50/50">
          {messages.map((msg) => {
            const isHaseeb = msg.role === 'assistant';
            return (
              <div key={msg.id} className={`flex gap-3 sm:gap-4 ${isHaseeb ? '' : 'flex-row-reverse'}`}>
                {/* Avatar */}
                <div
                  className={`w-9 h-9 rounded-xl shrink-0 flex items-center justify-center font-bold text-xs shadow-xs ${
                    isHaseeb
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 text-slate-800'
                  }`}
                >
                  {isHaseeb ? <UserCheck className="w-5 h-5 text-white" /> : <User className="w-4 h-4 text-slate-700" />}
                </div>

                {/* Message Bubble */}
                <div
                  className={`max-w-[85%] sm:max-w-[78%] rounded-2xl p-4 sm:p-5 text-sm ${
                    isHaseeb
                      ? 'bg-white border border-slate-200 text-slate-800 shadow-xs'
                      : 'bg-emerald-600 text-white font-medium shadow-xs'
                  }`}
                >
                  <div className="flex items-center justify-between gap-3 mb-1.5 pb-1 border-b border-slate-100">
                    <span className={`text-[11px] font-bold ${isHaseeb ? 'text-emerald-800' : 'text-emerald-100'}`}>
                      {isHaseeb ? 'Haseeb (AI HR Lead)' : 'You'}
                    </span>
                    <span className={`text-[10px] ${isHaseeb ? 'text-slate-400' : 'text-emerald-100'}`}>
                      {msg.timestamp}
                    </span>
                  </div>

                  {isHaseeb ? (
                    <MarkdownView content={msg.content} />
                  ) : (
                    <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                  )}
                </div>
              </div>
            );
          })}

          {loading && (
            <div className="flex gap-3 items-center text-xs text-slate-500 animate-pulse pl-12">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-600" />
              <span>Haseeb is formulating strategic HR recommendations...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-white border-t border-slate-200 space-y-2">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask Haseeb about Nestlé internships, Systems Limited roles, PKR tax, or remote USD jobs..."
              className="flex-1 bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-4 py-3 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              disabled={loading}
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center gap-2 shadow-md shadow-emerald-600/20 transition-all disabled:opacity-50"
            >
              <span>Send</span>
              <Send className="w-4 h-4 stroke-[2.5]" />
            </button>
          </form>

          {/* Boundaries & Disclaimer micro-footer */}
          <div className="flex items-center justify-between text-[11px] text-slate-500 px-1">
            <span className="flex items-center gap-1.5">
              <ShieldAlert className="w-3 h-3 text-amber-600 shrink-0" />
              <span>AI-assisted career recommendations. Personal implementation responsibility applies.</span>
            </span>
            <span className="hidden sm:inline font-mono text-[10px] text-slate-400">Powered by Kareer Engine</span>
          </div>
        </div>
      </div>
    </div>
  );
};
