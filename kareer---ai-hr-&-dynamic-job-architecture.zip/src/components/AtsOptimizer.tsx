import React, { useState } from 'react';
import { AtsAnalysisResult } from '../types';
import { SAMPLE_RESUMES } from '../data/sampleData';
import {
  FileCheck,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Copy,
  Check,
  TrendingUp,
  Target,
  ArrowRight,
  RefreshCw,
  Zap,
  Tag,
  ShieldCheck,
  FileText
} from 'lucide-react';

interface AtsOptimizerProps {
  initialJobTitle?: string;
  initialResumeText?: string;
}

export const AtsOptimizer: React.FC<AtsOptimizerProps> = ({ initialJobTitle, initialResumeText }) => {
  const [targetJobTitle, setTargetJobTitle] = useState(
    initialJobTitle || 'Nestlé Pakistan - Management Trainee Officer'
  );
  const [targetJobDescription, setTargetJobDescription] = useState(
    'Seeking energetic graduate for rotational MTO program in Supply Chain, Talent Acquisition, or Sales. Requires strong communication, Excel data analysis, leadership, and proactive ownership.'
  );
  const [resumeText, setResumeText] = useState(initialResumeText || SAMPLE_RESUMES.softwareEngineer);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AtsAnalysisResult | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Sync if prop changes
  React.useEffect(() => {
    if (initialJobTitle) {
      setTargetJobTitle(initialJobTitle);
    }
  }, [initialJobTitle]);

  React.useEffect(() => {
    if (initialResumeText) {
      setResumeText(initialResumeText);
    }
  }, [initialResumeText]);

  const handleAnalyze = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!resumeText.trim() || !targetJobTitle.trim()) return;

    setLoading(true);
    try {
      const res = await fetch('/api/analyze-resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetJobTitle,
          targetJobDescription,
          resumeText,
        }),
      });
      const data = await res.json();
      setResult(data);
    } catch (err) {
      console.error('Failed to analyze resume', err);
    } finally {
      setLoading(false);
    }
  };

  const handleLoadSample = (key: 'softwareEngineer' | 'hrProfessional' | 'productManager') => {
    setResumeText(SAMPLE_RESUMES[key]);
    if (key === 'softwareEngineer') {
      setTargetJobTitle('Systems Limited - Associate Software Engineer');
      setTargetJobDescription('React, TypeScript, Node.js, .NET Core, SQL databases, Git version control.');
    } else if (key === 'hrProfessional') {
      setTargetJobTitle('Nestlé Pakistan - HR & Talent Acquisition Specialist');
      setTargetJobDescription('KSAO job architecture, MTO recruitment, localized compensation, HRIS systems, employee engagement.');
    } else {
      setTargetJobTitle('JazzCash - Associate Digital Product Manager');
      setTargetJobDescription('Agile scrum, fintech roadmap execution, user analytics, conversion funnels, Raast payment APIs.');
    }
  };

  const handleCopyRewrite = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Header Banner - Light Theme */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs">
        <div className="max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-50 border border-teal-200 text-teal-800 text-xs font-semibold">
            <Zap className="w-3.5 h-3.5 text-teal-600" />
            <span>Applicant Tracking System (ATS) Diagnostic & XYZ Formula</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            ATS Resume Optimization & Impact Engineering
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Over 75% of student and professional resumes in Pakistan and multinational portals (Nestlé, Pepsi, Unilever) are filtered by ATS before reaching a human. Haseeb audits your resume, detects missing semantic keywords, and rewrites bullets into the Google XYZ formula: <em className="text-emerald-800 font-semibold">Accomplished [X], as measured by [Y], by doing [Z]</em>.
          </p>
        </div>

        {/* 1-Click Sample Resumes */}
        <div className="mt-5 pt-5 border-t border-slate-100 flex flex-wrap items-center gap-2.5">
          <span className="text-xs font-bold text-slate-700">Load Student / Candidate Sample:</span>
          <button
            onClick={() => handleLoadSample('softwareEngineer')}
            className="text-xs px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 transition-colors font-medium"
          >
            Software Engineer (Systems Ltd)
          </button>
          <button
            onClick={() => handleLoadSample('hrProfessional')}
            className="text-xs px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 transition-colors font-medium"
          >
            HR / People Ops (Nestlé / FMCG)
          </button>
          <button
            onClick={() => handleLoadSample('productManager')}
            className="text-xs px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 transition-colors font-medium"
          >
            Product / FinTech (JazzCash / HBL)
          </button>
        </div>
      </div>

      {/* Main Form & Analysis Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Form (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4 shadow-sm">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <FileText className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Candidate & Job Inputs</h2>
          </div>

          <form onSubmit={handleAnalyze} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Target Job Role</label>
              <input
                type="text"
                value={targetJobTitle}
                onChange={(e) => setTargetJobTitle(e.target.value)}
                placeholder="e.g. Nestlé MTO, Systems Limited Developer"
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Target Job Description / Key Competencies
              </label>
              <textarea
                value={targetJobDescription}
                onChange={(e) => setTargetJobDescription(e.target.value)}
                rows={3}
                placeholder="Paste the target job description or requirements here..."
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl p-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-none resize-none"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700">Resume Content (Plain Text)</label>
                <span className="text-[11px] text-slate-500">{resumeText.split(/\s+/).filter(Boolean).length} words</span>
              </div>
              <textarea
                value={resumeText}
                onChange={(e) => setResumeText(e.target.value)}
                rows={11}
                placeholder="Paste your resume text here (experience, projects, education)..."
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl p-3 text-xs font-mono text-slate-800 focus:outline-none resize-none leading-relaxed"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading || !resumeText.trim()}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-all disabled:opacity-50"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Evaluating ATS Compatibility...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 stroke-[2.5]" />
                  <span>Analyze ATS Match & Optimize Bullets</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Column: ATS Report (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {!result && !loading && (
            <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-4 shadow-sm">
              <div className="w-12 h-12 rounded-2xl bg-teal-50 border border-teal-200 flex items-center justify-center mx-auto text-teal-600">
                <FileCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Ready for ATS Audit</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Click the button to scan your resume against the target role requirements and get instant XYZ-formula bullet rewrites.
                </p>
              </div>
              <button
                onClick={() => handleAnalyze()}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-colors"
              >
                Scan Loaded Resume
              </button>
            </div>
          )}

          {loading && (
            <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center space-y-4 shadow-sm">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto text-emerald-600 animate-spin">
                <RefreshCw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Auditing Semantic Alignment</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Parsing keywords, evaluating action verbs, and architecting XYZ metric achievements...
                </p>
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* ATS Score Overview Card */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
                  <div className="flex items-center gap-4">
                    <div className="relative w-20 h-20 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col items-center justify-center">
                      <span className="text-3xl font-black text-emerald-700">{result.atsScore}</span>
                      <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">/ 100</span>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                          {result.atsScore >= 80 ? 'ATS High Match' : result.atsScore >= 65 ? 'Moderate Match - Polish Needed' : 'Low Match - High Filter Risk'}
                        </span>
                      </div>
                      <h3 className="text-lg font-bold text-slate-900">Applicant Tracking System Score</h3>
                      <p className="text-xs text-slate-500 mt-0.5">Target: {targetJobTitle}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleAnalyze()}
                    className="self-start sm:self-center px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-200"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Re-Audit</span>
                  </button>
                </div>

                {/* Score Breakdown Bars */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-700 font-medium">Keyword Match Rate</span>
                      <span className="font-bold text-emerald-700">{result.scoreBreakdown.keywordMatch}%</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                        style={{ width: `${result.scoreBreakdown.keywordMatch}%` }}
                      />
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-700 font-medium">Action Verb Strength</span>
                      <span className="font-bold text-teal-700">{result.scoreBreakdown.actionVerbStrength}%</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-teal-600 h-full rounded-full transition-all duration-500"
                        style={{ width: `${result.scoreBreakdown.actionVerbStrength}%` }}
                      />
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-700 font-medium">Quantified Impact (XYZ Factor)</span>
                      <span className="font-bold text-amber-700">{result.scoreBreakdown.quantifiedImpact}%</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-amber-600 h-full rounded-full transition-all duration-500"
                        style={{ width: `${result.scoreBreakdown.quantifiedImpact}%` }}
                      />
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-700 font-medium">Layout & ATS Readability</span>
                      <span className="font-bold text-blue-700">{result.scoreBreakdown.layoutClarity}%</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-blue-600 h-full rounded-full transition-all duration-500"
                        style={{ width: `${result.scoreBreakdown.layoutClarity}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Haseeb's Verdict */}
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800 uppercase tracking-wider">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Haseeb's Executive Strategic Verdict:</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">{result.verdict}</p>
                </div>
              </div>

              {/* Missing Keywords Diagnostic */}
              {result.missingKeywords && result.missingKeywords.length > 0 && (
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
                  <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                    <Tag className="w-4 h-4 text-amber-600" />
                    <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                      Detected Missing Keywords & Insertion Context
                    </h3>
                  </div>

                  <div className="space-y-3">
                    {result.missingKeywords.map((kw, i) => (
                      <div
                        key={i}
                        className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 p-3.5 rounded-xl bg-slate-50 border border-slate-200"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-sm text-emerald-800">{kw.keyword}</span>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                kw.importance === 'High'
                                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                                  : 'bg-amber-100 text-amber-800 border border-amber-200'
                              }`}
                            >
                              {kw.importance} Priority
                            </span>
                          </div>
                          <p className="text-xs text-slate-600">{kw.contextSuggestion}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Bullet-Point Rewriter: XYZ Formula */}
              {result.bulletPointRewrites && result.bulletPointRewrites.length > 0 && (
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <Target className="w-5 h-5 text-emerald-600" />
                      <div>
                        <h3 className="text-base font-bold text-slate-900">Google XYZ Formula Bullet Rewriter</h3>
                        <p className="text-xs text-slate-500">Accomplished [X], as measured by [Y], by doing [Z]</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {result.bulletPointRewrites.map((rewrite, rIdx) => (
                      <div key={rIdx} className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                        {/* Original vs Rewritten */}
                        <div className="space-y-2">
                          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs space-y-1">
                            <span className="text-[10px] font-bold text-rose-800 uppercase tracking-wider block">
                              Original Bullet (Passive / Duty-Focused):
                            </span>
                            <p className="text-slate-700 italic">"{rewrite.original}"</p>
                          </div>

                          <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs space-y-1.5">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">
                                Haseeb's Optimized Rewrite (XYZ Impact):
                              </span>
                              <button
                                onClick={() => handleCopyRewrite(rewrite.rewritten, rIdx)}
                                className="px-2 py-1 rounded bg-white hover:bg-slate-100 text-slate-800 text-[11px] font-medium flex items-center gap-1 transition-colors border border-slate-200 shadow-xs"
                              >
                                {copiedIndex === rIdx ? (
                                  <>
                                    <Check className="w-3 h-3 text-emerald-600" />
                                    <span>Copied</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3 h-3" />
                                    <span>Copy Bullet</span>
                                  </>
                                )}
                              </button>
                            </div>
                            <p className="text-emerald-950 font-bold leading-relaxed">
                              "{rewrite.rewritten}"
                            </p>
                          </div>
                        </div>

                        {/* Haseeb's Critique */}
                        <div className="text-[11px] text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200 flex items-start gap-2">
                          <Sparkles className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                          <span>
                            <strong className="text-slate-800">Why this wins:</strong> {rewrite.critique}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Strengths & Critical Gaps */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
                  <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs uppercase tracking-wider pb-2 border-b border-slate-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Detected Strengths</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-700">
                    {result.detectedStrengths.map((str, sIdx) => (
                      <li key={sIdx} className="flex items-start gap-2">
                        <span className="text-emerald-600 font-bold">•</span>
                        <span>{str}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
                  <div className="flex items-center gap-2 text-amber-800 font-bold text-xs uppercase tracking-wider pb-2 border-b border-slate-100">
                    <AlertCircle className="w-4 h-4 text-amber-600" />
                    <span>Areas for Immediate Polish</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-700">
                    {result.criticalGaps.map((gap, gIdx) => (
                      <li key={gIdx} className="flex items-start gap-2">
                        <span className="text-amber-600 font-bold">•</span>
                        <span>{gap}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Haseeb's Final Advice */}
              <div className="bg-emerald-50/60 border border-emerald-200 rounded-2xl p-5 shadow-sm space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-900 uppercase tracking-wider">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>Strategic Positioning Advice from Haseeb:</span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed">{result.haseebAdvice}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
