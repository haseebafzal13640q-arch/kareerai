import React, { useState } from 'react';
import { PROFESSIONS_DATA } from '../data/professionDutiesData';
import { X, Search, Check, Plus, BookOpen, Sparkles } from 'lucide-react';

interface ProfessionDutiesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertDuty: (dutyText: string) => void;
  initialRoleFilter?: string;
}

export const ProfessionDutiesModal: React.FC<ProfessionDutiesModalProps> = ({
  isOpen,
  onClose,
  onInsertDuty,
  initialRoleFilter = '',
}) => {
  if (!isOpen) return null;

  const [search, setSearch] = useState(initialRoleFilter);
  const [selectedProfessionId, setSelectedProfessionId] = useState<string>(
    PROFESSIONS_DATA[0].id
  );
  const [insertedBullets, setInsertedBullets] = useState<Record<string, boolean>>({});

  const filteredProfessions = PROFESSIONS_DATA.filter(
    (p) =>
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.category.toLowerCase().includes(search.toLowerCase()) ||
      p.summary.toLowerCase().includes(search.toLowerCase())
  );

  const currentProfession =
    PROFESSIONS_DATA.find((p) => p.id === selectedProfessionId) ||
    filteredProfessions[0] ||
    PROFESSIONS_DATA[0];

  const handleInsert = (duty: string, index: number) => {
    onInsertDuty(duty);
    setInsertedBullets((prev) => ({ ...prev, [`${currentProfession.id}-${index}`]: true }));
    setTimeout(() => {
      setInsertedBullets((prev) => ({ ...prev, [`${currentProfession.id}-${index}`]: false }));
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-700">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Insert Vetted Profession Duties into Resume
              </h3>
              <p className="text-xs text-slate-500">
                Curated Google XYZ-formula accomplishment bullets verified by Haseeb
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-200/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Selector */}
        <div className="p-4 border-b border-slate-200 bg-white flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search profession (e.g., MTO, Software Engineer, Data Analyst, Brand Manager)..."
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-500"
            />
          </div>
          <div className="text-xs text-slate-500 whitespace-nowrap">
            Showing <strong>{filteredProfessions.length}</strong> roles
          </div>
        </div>

        {/* Split View: Profession List on Left, Duties on Right */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-3 overflow-hidden">
          {/* Left Column: Profession list */}
          <div className="border-r border-slate-200 overflow-y-auto max-h-[300px] md:max-h-none p-2 space-y-1 bg-slate-50/50">
            {filteredProfessions.map((prof) => (
              <button
                key={prof.id}
                onClick={() => setSelectedProfessionId(prof.id)}
                className={`w-full text-left p-2.5 rounded-lg transition-all text-xs flex flex-col gap-0.5 ${
                  currentProfession.id === prof.id
                    ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                    : 'text-slate-700 hover:bg-slate-200/60'
                }`}
              >
                <span className="truncate">{prof.title}</span>
                <span
                  className={`text-[10px] ${
                    currentProfession.id === prof.id ? 'text-emerald-100' : 'text-slate-500'
                  }`}
                >
                  {prof.category}
                </span>
              </button>
            ))}
          </div>

          {/* Right Column: Key Duties with 1-Click Insert */}
          <div className="md:col-span-2 p-5 overflow-y-auto space-y-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h4 className="text-base font-bold text-slate-900">{currentProfession.title}</h4>
                {currentProfession.badge && (
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                    {currentProfession.badge}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                {currentProfession.summary}
              </p>
            </div>

            <div>
              <h5 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                Curated XYZ-Accomplishment Duties (Click to Insert):
              </h5>
              <div className="space-y-2.5">
                {currentProfession.primaryResponsibilities.map((duty, idx) => {
                  const isInserted = insertedBullets[`${currentProfession.id}-${idx}`];
                  return (
                    <div
                      key={idx}
                      className="p-3 rounded-lg border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/30 transition-all flex items-start justify-between gap-3 text-xs leading-relaxed text-slate-800 group"
                    >
                      <div className="flex items-start gap-2">
                        <span className="text-emerald-600 font-bold">•</span>
                        <span>{duty}</span>
                      </div>
                      <button
                        onClick={() => handleInsert(duty, idx)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold whitespace-nowrap transition-all ${
                          isInserted
                            ? 'bg-emerald-600 text-white'
                            : 'bg-white border border-slate-300 text-slate-700 hover:bg-emerald-600 hover:text-white hover:border-emerald-600'
                        }`}
                      >
                        {isInserted ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Inserted!</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>Insert</span>
                          </>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs text-slate-600">
              <strong className="text-slate-900 block mb-1">
                Employer Wishlist Quick Highlight:
              </strong>
              <div className="flex flex-wrap gap-1 text-[11px]">
                {currentProfession.employerLookingFor.mustHaveHardSkills.map((s, i) => (
                  <span key={i} className="bg-white border border-slate-200 px-2 py-0.5 rounded text-slate-700">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Bullets are formatted with Action Verbs and quantifiable results for high ATS score.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-lg transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
