import React, { useState } from 'react';
import {
  PAKISTANI_JOBS_LIST,
  PAKISTANI_INDUSTRIES,
  PAKISTANI_DEPARTMENTS,
  PAKISTANI_REGIONS
} from '../data/pakistaniJobsData';
import { PakistaniJob } from '../types';
import {
  Building2,
  MapPin,
  Coins,
  GraduationCap,
  Calendar,
  Search,
  ExternalLink,
  Sparkles,
  CheckCircle2,
  Globe2,
  Briefcase,
  Laptop,
  BookOpen,
  Filter,
  Check,
  ChevronRight,
  ShieldCheck,
  ArrowUpRight,
  TrendingUp,
  Heart,
  Tag,
  Layers,
  X,
  RotateCcw
} from 'lucide-react';

interface PakistaniJobsHubProps {
  onSelectRoleForAnalysis?: (roleTitle: string, company: string, location: string) => void;
  onOpenATS?: (roleTitle: string) => void;
  onBuildResumeForRole?: (roleTitle: string, company: string) => void;
}

export const PakistaniJobsHub: React.FC<PakistaniJobsHubProps> = ({
  onSelectRoleForAnalysis,
  onOpenATS,
  onBuildResumeForRole,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'internship' | 'onsite' | 'remote'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState<string>('All Industries');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('All Departments');
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [activeJobModal, setActiveJobModal] = useState<PakistaniJob | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<Record<string, boolean>>({});

  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarkedIds((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleResetFilters = () => {
    setSelectedCategory('all');
    setSearchQuery('');
    setSelectedIndustry('All Industries');
    setSelectedDepartment('All Departments');
    setSelectedCity('all');
  };

  const filteredJobs = PAKISTANI_JOBS_LIST.filter((job) => {
    // Category filter
    if (selectedCategory !== 'all' && job.category !== selectedCategory) {
      return false;
    }
    // Industry filter
    if (selectedIndustry !== 'All Industries' && job.industry !== selectedIndustry) {
      return false;
    }
    // Department filter
    if (selectedDepartment !== 'All Departments' && job.department !== selectedDepartment) {
      return false;
    }
    // City filter
    if (selectedCity !== 'all') {
      if (selectedCity === 'Remote') {
        if (job.category !== 'remote' && job.city !== 'Remote') return false;
      } else {
        const matchesCity = job.city.toLowerCase() === selectedCity.toLowerCase() ||
          job.location.toLowerCase().includes(selectedCity.toLowerCase());
        if (!matchesCity) return false;
      }
    }
    // Search query: matching company, title, industry, department, location, requirements
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = job.title.toLowerCase().includes(q);
      const matchCompany = job.company.toLowerCase().includes(q);
      const matchIndustry = job.industry.toLowerCase().includes(q);
      const matchDept = job.department.toLowerCase().includes(q);
      const matchLoc = job.location.toLowerCase().includes(q) || job.city.toLowerCase().includes(q) || job.province.toLowerCase().includes(q);
      const matchReq = job.keyRequirements.some((r) => r.toLowerCase().includes(q));
      if (!matchTitle && !matchCompany && !matchIndustry && !matchDept && !matchLoc && !matchReq) {
        return false;
      }
    }
    return true;
  });

  const internshipCount = PAKISTANI_JOBS_LIST.filter((j) => j.category === 'internship').length;
  const onsiteCount = PAKISTANI_JOBS_LIST.filter((j) => j.category === 'onsite').length;
  const remoteCount = PAKISTANI_JOBS_LIST.filter((j) => j.category === 'remote').length;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Hero Banner tailored for Pakistani Students & Professionals */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white p-6 sm:p-8 shadow-xl shadow-emerald-500/10">
        <div className="relative z-10 max-w-4xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-emerald-50 text-xs font-semibold border border-white/20">
            <span className="w-2 h-2 rounded-full bg-emerald-200 animate-pulse"></span>
            <span>All-Pakistan Verified Job Network · Across Punjab, Sindh, KPK, Balochistan & Remote</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white">
            Pakistan Careers & Internships Hub
          </h1>

          <p className="text-sm text-emerald-50 leading-relaxed max-w-3xl font-normal">
            Every career discipline for students and graduates across all Pakistani cities. Search by <strong>Human Resources (HR), Management Trainee (MTO), Software Engineering, Brand Marketing, Supply Chain, Finance, or UI/UX</strong> across Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad, Multan, Sialkot, Peshawar, Quetta, and high-paying <strong>Global Remote USD</strong> opportunities.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-4 text-xs font-semibold text-emerald-100">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-200" />
              <span>Industries Always Visible to Students</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-200" />
              <span>Real PKR & USD Salary Transparency</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-200" />
              <span>1-Click AI Resume Scoring & KSAO Matching</span>
            </div>
          </div>
        </div>

        {/* Decorative background element */}
        <div className="absolute -right-8 -bottom-12 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        {/* Category Tabs: All, Internships, Onsite, Remote */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                selectedCategory === 'all'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>All Jobs ({PAKISTANI_JOBS_LIST.length})</span>
            </button>

            <button
              onClick={() => setSelectedCategory('internship')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                selectedCategory === 'internship'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200/60'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>🎓 Student Internships & MTO ({internshipCount})</span>
            </button>

            <button
              onClick={() => setSelectedCategory('onsite')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                selectedCategory === 'onsite'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/60'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>🏢 Pakistan Onsite ({onsiteCount})</span>
            </button>

            <button
              onClick={() => setSelectedCategory('remote')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                selectedCategory === 'remote'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200/60'
              }`}
            >
              <Laptop className="w-3.5 h-3.5" />
              <span>🌐 Remote & USD ($) ({remoteCount})</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">
              Showing <strong className="text-slate-800">{filteredJobs.length}</strong> opportunities
            </span>
            {(selectedCategory !== 'all' || selectedIndustry !== 'All Industries' || selectedDepartment !== 'All Departments' || selectedCity !== 'all' || searchQuery) && (
              <button
                onClick={handleResetFilters}
                className="text-[11px] font-bold text-red-600 hover:text-red-700 flex items-center gap-1 px-2 py-1 rounded bg-red-50 hover:bg-red-100 transition-colors"
                title="Reset all filters"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        {/* Multi-Dimensional Search Bar & Dropdown Selectors */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Main Search input */}
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search companies (Nestlé, Systems, Engro), roles (HR, MTO), skills..."
              className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Industry Filter (Always visible) */}
          <div className="md:col-span-2.5">
            <select
              value={selectedIndustry}
              onChange={(e) => setSelectedIndustry(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-700 focus:outline-none"
            >
              {PAKISTANI_INDUSTRIES.map((ind) => (
                <option key={ind} value={ind}>
                  {ind}
                </option>
              ))}
            </select>
          </div>

          {/* Department / Function Filter */}
          <div className="md:col-span-2.5">
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-700 focus:outline-none"
            >
              {PAKISTANI_DEPARTMENTS.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>

          {/* City & Province Filter */}
          <div className="md:col-span-2">
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-700 focus:outline-none"
            >
              {PAKISTANI_REGIONS.map((reg) => (
                <option key={reg.label} value={reg.city}>
                  {reg.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Search Tags for Students */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1 text-xs">
          <span className="text-slate-400 font-medium mr-1 text-[11px]">Popular Searches:</span>
          {[
            { label: '🏢 Nestlé MTO', q: 'Nestlé' },
            { label: '👥 Human Resources (HR)', q: 'Human Resources' },
            { label: '💻 Systems Limited', q: 'Systems' },
            { label: '🌿 Engro Corp', q: 'Engro' },
            { label: '💵 Remote USD ($)', q: 'USD' },
            { label: '📍 Lahore', q: 'Lahore' },
            { label: '📍 Karachi', q: 'Karachi' },
            { label: '📍 Islamabad', q: 'Islamabad' },
            { label: '📍 Faisalabad', q: 'Faisalabad' },
            { label: '📍 Multan', q: 'Multan' },
            { label: '📍 Peshawar', q: 'Peshawar' },
            { label: '📍 Quetta', q: 'Quetta' },
          ].map((tag) => (
            <button
              key={tag.label}
              onClick={() => {
                setSearchQuery(tag.q);
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-200 border border-slate-200/80 text-[11px] font-medium text-slate-700 transition-colors"
            >
              {tag.label}
            </button>
          ))}
        </div>
      </div>

      {/* Zero State if no results */}
      {filteredJobs.length === 0 && (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 space-y-4">
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900">No matching jobs found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Try resetting your search query or broadening your location and industry filters to discover other verified openings.
          </p>
          <button
            onClick={handleResetFilters}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors"
          >
            Reset All Filters
          </button>
        </div>
      )}

      {/* Job Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredJobs.map((job) => {
          const isBookmarked = !!bookmarkedIds[job.id];
          return (
            <div
              key={job.id}
              onClick={() => setActiveJobModal(job)}
              className="group bg-white rounded-2xl border border-slate-200 hover:border-emerald-400 p-5 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between cursor-pointer relative"
            >
              <div>
                {/* Header: Company, Industry & Category Badge */}
                <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-xs text-slate-800 group-hover:bg-emerald-50 group-hover:text-emerald-700 group-hover:border-emerald-200 transition-colors shadow-xs shrink-0">
                      {job.logoText.slice(0, 4)}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-700 transition-colors line-clamp-1">
                        {job.company}
                      </h4>
                      {/* INDUSTRY BADGE - ALWAYS SHOWN TO STUDENTS */}
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1">
                          <Tag className="w-2.5 h-2.5 text-emerald-600" />
                          <span>{job.industry}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={(e) => toggleBookmark(job.id, e)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-slate-50 transition-colors"
                    title={isBookmarked ? 'Remove bookmark' : 'Bookmark job'}
                  >
                    <Heart
                      className={`w-4 h-4 ${
                        isBookmarked ? 'fill-red-500 text-red-500' : 'text-slate-400'
                      }`}
                    />
                  </button>
                </div>

                {/* Job Title and Category */}
                <div className="mt-3.5 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        job.category === 'internship'
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : job.category === 'remote'
                          ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                          : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      }`}
                    >
                      {job.category === 'internship'
                        ? '🎓 Internship / MTO'
                        : job.category === 'remote'
                        ? '🌐 Remote Work'
                        : '🏢 Pakistan Onsite'}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-500">
                      {job.department}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 leading-snug group-hover:text-emerald-700 transition-colors line-clamp-2">
                    {job.title}
                  </h3>
                </div>

                {/* Metadata Pills: Location and Salary */}
                <div className="mt-3 space-y-2 text-xs">
                  <div className="flex items-center gap-1.5 text-slate-600">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{job.location}</span>
                  </div>

                  <div className="flex items-center gap-1.5 font-bold text-emerald-800 bg-emerald-50/70 p-2 rounded-xl border border-emerald-100">
                    <Coins className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span className="truncate text-xs">{job.stipendOrSalary}</span>
                  </div>
                </div>

                {/* Description snippet */}
                <p className="mt-3 text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {job.description}
                </p>

                {/* Requirements tags */}
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {job.keyRequirements.slice(0, 2).map((req, rIdx) => (
                    <span
                      key={rIdx}
                      className="text-[10px] px-2 py-0.5 rounded-md bg-slate-50 border border-slate-200 text-slate-600 max-w-[220px] truncate"
                    >
                      ✓ {req}
                    </span>
                  ))}
                  {job.keyRequirements.length > 2 && (
                    <span className="text-[10px] text-slate-400 font-medium">
                      +{job.keyRequirements.length - 2} more
                    </span>
                  )}
                </div>
              </div>

              {/* Card Footer */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-500">{job.deadline}</span>
                <span className="text-emerald-600 font-bold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform text-xs">
                  <span>View Details</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal Dialog for Full Job Details */}
      {activeJobModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-150"
          >
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center font-black text-sm text-emerald-800 shadow-xs">
                  {activeJobModal.logoText.slice(0, 4)}
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                      {activeJobModal.company}
                    </span>
                    {/* Industry Badge */}
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-800 border border-slate-200">
                      {activeJobModal.industry}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      {activeJobModal.department}
                    </span>
                  </div>
                  <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 mt-1">
                    {activeJobModal.title}
                  </h2>
                </div>
              </div>

              <button
                onClick={() => setActiveJobModal(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                  Location
                </span>
                <span className="font-semibold text-slate-900">{activeJobModal.location}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                  Compensation
                </span>
                <span className="font-semibold text-emerald-700">{activeJobModal.stipendOrSalary}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                  Experience
                </span>
                <span className="font-semibold text-slate-900">{activeJobModal.experience}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                  Education
                </span>
                <span className="font-semibold text-slate-900">{activeJobModal.education}</span>
              </div>
            </div>

            {/* Role Overview */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Position Overview
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {activeJobModal.description}
              </p>
            </div>

            {/* Candidate Requirements */}
            <div className="space-y-2.5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Key Requirements & Qualifications
              </h3>
              <ul className="space-y-2 text-xs text-slate-700">
                {activeJobModal.keyRequirements.map((req, rIdx) => (
                  <li key={rIdx} className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Perks & Benefits */}
            <div className="space-y-2.5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Compensation, Perks & Professional Benefits
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {activeJobModal.perks.map((perk, pIdx) => (
                  <div
                    key={pIdx}
                    className="p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-100 text-xs text-emerald-950 font-medium flex items-center gap-2"
                  >
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{perk}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer with AI Actions & Apply Button */}
            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                {onSelectRoleForAnalysis && (
                  <button
                    onClick={() => {
                      onSelectRoleForAnalysis(
                        activeJobModal.title,
                        activeJobModal.company,
                        activeJobModal.location
                      );
                      setActiveJobModal(null);
                    }}
                    className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Analyze with Haseeb (KSAO)</span>
                  </button>
                )}

                {onOpenATS && (
                  <button
                    onClick={() => {
                      onOpenATS(activeJobModal.title);
                      setActiveJobModal(null);
                    }}
                    className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <span>Check Resume</span>
                  </button>
                )}

                {onBuildResumeForRole && (
                  <button
                    onClick={() => {
                      onBuildResumeForRole(activeJobModal.title, activeJobModal.company);
                      setActiveJobModal(null);
                    }}
                    className="px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <span>Build CV for Role</span>
                  </button>
                )}
              </div>

              <a
                href={activeJobModal.applyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all"
              >
                <span>Visit Official Portal</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
