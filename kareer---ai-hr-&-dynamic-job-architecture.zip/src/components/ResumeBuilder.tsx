import React, { useState, useEffect, useRef } from 'react';
import { ResumeData, ResumeTemplateId } from '../types';
import {
  INTERNATIONAL_TEMPLATES,
  SAMPLE_RESUMES,
  TemplateMetadata,
} from '../data/resumeTemplatesData';
import { ResumeDocumentView } from './ResumeDocumentView';
import { ResumeEditorForm } from './ResumeEditorForm';
import { ProfessionDutiesModal } from './ProfessionDutiesModal';
import {
  Printer,
  Sparkles,
  FileCheck,
  RotateCcw,
  CheckCircle,
  AlertCircle,
  Globe,
  GraduationCap,
  Briefcase,
  ChevronDown,
  Layers,
  Copy,
  Download,
  BookOpen,
  Save,
  Upload,
  Check,
  HelpCircle,
  FileText
} from 'lucide-react';

interface ResumeBuilderProps {
  onSendToAts?: (resumeText: string, jobTitle: string) => void;
  onOpenProfessionDutiesTab?: () => void;
}

export const ResumeBuilder: React.FC<ResumeBuilderProps> = ({
  onSendToAts,
  onOpenProfessionDutiesTab,
}) => {
  // Load saved template & draft or default to 'fresh-graduate'
  const [selectedTemplate, setSelectedTemplate] = useState<ResumeTemplateId>(() => {
    return (localStorage.getItem('kareer_resume_template') as ResumeTemplateId) || 'fresh-graduate';
  });

  const [resumeData, setResumeData] = useState<ResumeData>(() => {
    const saved = localStorage.getItem('kareer_resume_draft');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved resume:', e);
      }
    }
    return SAMPLE_RESUMES['fresh-student'].data;
  });

  const [activeTab, setActiveTab] = useState<'editor' | 'preview' | 'split'>('split');
  const [isDutiesModalOpen, setIsDutiesModalOpen] = useState(false);
  const [targetExpIndexForDuty, setTargetExpIndexForDuty] = useState(0);
  const [copiedNotification, setCopiedNotification] = useState(false);
  const [savedNotification, setSavedNotification] = useState<string | null>(null);
  const [showPrintTips, setShowPrintTips] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-save to localStorage
  useEffect(() => {
    localStorage.setItem('kareer_resume_draft', JSON.stringify(resumeData));
  }, [resumeData]);

  useEffect(() => {
    localStorage.setItem('kareer_resume_template', selectedTemplate);
  }, [selectedTemplate]);

  // Explicit Save Draft handler
  const handleSaveDraft = () => {
    localStorage.setItem('kareer_resume_draft', JSON.stringify(resumeData));
    localStorage.setItem('kareer_resume_template', selectedTemplate);
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setSavedNotification(`Saved successfully at ${now}`);
    setTimeout(() => setSavedNotification(null), 3500);
  };

  // Export JSON Backup file
  const handleExportJson = () => {
    const jsonStr = JSON.stringify(resumeData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeName = (resumeData.personalInfo.fullName || 'resume').toLowerCase().replace(/\s+/g, '-');
    link.href = url;
    link.download = `kareer-${safeName}-draft.json`;
    link.click();
    URL.revokeObjectURL(url);
    setSavedNotification('Downloaded JSON backup file!');
    setTimeout(() => setSavedNotification(null), 3000);
  };

  // Import JSON Backup file
  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.personalInfo && parsed.experience) {
          setResumeData(parsed);
          setSavedNotification('Resume draft restored successfully!');
          setTimeout(() => setSavedNotification(null), 3000);
        } else {
          alert('Invalid resume JSON format.');
        }
      } catch (err) {
        alert('Failed to parse the uploaded JSON file.');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Handle template selection
  const handleSelectTemplate = (id: ResumeTemplateId) => {
    setSelectedTemplate(id);
  };

  // Handle loading a starter sample profile
  const handleLoadSample = (key: string) => {
    if (SAMPLE_RESUMES[key]) {
      setResumeData(SAMPLE_RESUMES[key].data);
      if (key === 'fresh-student') {
        setSelectedTemplate('fresh-graduate');
      } else if (key === 'mto-candidate') {
        setSelectedTemplate('harvard-classic');
      } else if (key === 'software-engineer') {
        setSelectedTemplate('silicon-valley');
      }
    }
  };

  // Insert duty from modal into specific experience entry
  const handleInsertDuty = (dutyText: string) => {
    if (resumeData.experience.length === 0) {
      const newExp = {
        id: `exp-${Date.now()}`,
        jobTitle: resumeData.personalInfo.title || 'Professional / Management Trainee',
        company: 'Target Company',
        location: 'Pakistan',
        startDate: 'Jan 2024',
        endDate: 'Present',
        isCurrent: true,
        bullets: [dutyText],
      };
      setResumeData({ ...resumeData, experience: [newExp] });
    } else {
      const idx = Math.min(targetExpIndexForDuty, resumeData.experience.length - 1);
      const updated = [...resumeData.experience];
      updated[idx].bullets.push(dutyText);
      setResumeData({ ...resumeData, experience: updated });
    }
  };

  // Calculate live ATS checklist score
  const calculateAtsScore = () => {
    let score = 0;
    const checks = {
      hasContact: !!(resumeData.personalInfo.email && resumeData.personalInfo.phone),
      hasLinkedIn: !!resumeData.personalInfo.linkedin,
      hasSummary: resumeData.summary.length >= 100,
      hasExperience: resumeData.experience.length > 0,
      hasMetrics: false,
      hasTechnicalSkills: resumeData.skills.technical.length >= 3,
      hasEducation: resumeData.education.length > 0,
    };

    const allBullets = [
      ...resumeData.experience.flatMap((e) => e.bullets),
      ...resumeData.projects.flatMap((p) => p.bullets),
    ].join(' ');

    if (/\d+%|\$\d+|PKR\s*\d+|\b\d+\s*(users|clients|hours|days|leads|M|K)\b/i.test(allBullets)) {
      checks.hasMetrics = true;
    }

    if (checks.hasContact) score += 15;
    if (checks.hasLinkedIn) score += 10;
    if (checks.hasSummary) score += 15;
    if (checks.hasExperience) score += 20;
    if (checks.hasMetrics) score += 15;
    if (checks.hasTechnicalSkills) score += 15;
    if (checks.hasEducation) score += 10;

    return { score, checks };
  };

  const { score: atsScore, checks } = calculateAtsScore();

  // Print / Save to PDF
  const handlePrint = () => {
    window.print();
  };

  // Export plain text resume for ATS testing
  const generatePlainTextResume = () => {
    const p = resumeData.personalInfo;
    let txt = `${p.fullName}\n${p.title}\n${p.email} | ${p.phone} | ${p.location}\n`;
    if (p.linkedin) txt += `LinkedIn: ${p.linkedin}\n`;
    if (p.github) txt += `GitHub: ${p.github}\n`;
    txt += `\nPROFESSIONAL SUMMARY\n${resumeData.summary}\n\n`;

    txt += `WORK EXPERIENCE\n`;
    resumeData.experience.forEach((e) => {
      txt += `${e.jobTitle} - ${e.company}, ${e.location} (${e.startDate} - ${e.isCurrent ? 'Present' : e.endDate})\n`;
      e.bullets.forEach((b) => {
        txt += `• ${b}\n`;
      });
      txt += `\n`;
    });

    txt += `EDUCATION\n`;
    resumeData.education.forEach((ed) => {
      txt += `${ed.degree} - ${ed.institution} (${ed.graduationYear})\n`;
      if (ed.gpaOrHonors) txt += `Honors: ${ed.gpaOrHonors}\n`;
      if (ed.details) txt += `${ed.details}\n`;
    });

    txt += `\nSKILLS\n`;
    txt += `Technical: ${resumeData.skills.technical.join(', ')}\n`;
    txt += `Tools: ${resumeData.skills.tools.join(', ')}\n`;
    txt += `Soft Skills: ${resumeData.skills.soft.join(', ')}\n`;

    return txt;
  };

  const handleCopyText = () => {
    const text = generatePlainTextResume();
    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  const handleSendToOptimizer = () => {
    if (onSendToAts) {
      const text = generatePlainTextResume();
      onSendToAts(text, resumeData.personalInfo.title || 'Professional');
    }
  };

  return (
    <div className="space-y-6">
      {/* Hidden file input for JSON restore */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleImportJson}
        accept=".json"
        className="hidden"
      />

      {/* Top Header Card */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Kareer CV Studio
              </span>
              <span className="text-xs text-slate-500">· 8 International ATS-Compliant Standards</span>
            </div>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
              Resume Builder & International Templates
            </h1>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
              Craft student and professional resumes tailored to international hiring standards. Choose from 8 international formats (Harvard ATS, Fresh Graduate, Silicon Valley, Europass, Nordic Minimalist, Creative Showcase, Academic CV) with live PDF export and auto-save.
            </p>
          </div>

          {/* Quick Action Buttons: Save, Print, Score, Export */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Primary Save Draft Button */}
            <button
              onClick={handleSaveDraft}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all active:scale-95"
              title="Save current resume changes to browser storage"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Draft</span>
            </button>

            {/* Primary Print / Save PDF Button */}
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs transition-all active:scale-95"
              title="Print document or Save as PDF"
            >
              <Printer className="w-3.5 h-3.5 text-emerald-400" />
              <span>Print / Save as PDF</span>
            </button>

            {/* Print Help Tip Button */}
            <button
              onClick={() => setShowPrintTips(!showPrintTips)}
              className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs transition-colors"
              title="PDF print instructions"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            {/* Score in ATS Optimizer */}
            <button
              onClick={handleSendToOptimizer}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-semibold transition-colors"
              title="Test this resume in our ATS Optimizer"
            >
              <FileCheck className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Score in ATS</span>
            </button>

            {/* Backup JSON */}
            <button
              onClick={handleExportJson}
              className="inline-flex items-center gap-1 px-2.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-medium transition-colors"
              title="Download backup JSON file to your computer"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Backup .json</span>
            </button>

            {/* Restore JSON */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1 px-2.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-medium transition-colors"
              title="Restore from a previously saved JSON file"
            >
              <Upload className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Restore</span>
            </button>

            {/* Copy Plain Text */}
            <button
              onClick={handleCopyText}
              className="inline-flex items-center gap-1.5 px-2.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-medium transition-colors"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copiedNotification ? 'Copied!' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* Save confirmation toast */}
        {savedNotification && (
          <div className="mt-3 p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold flex items-center gap-2 animate-in fade-in duration-200">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{savedNotification}</span>
          </div>
        )}

        {/* Print instructions banner */}
        {showPrintTips && (
          <div className="mt-3 p-3.5 bg-sky-50 border border-sky-200 rounded-xl text-xs text-sky-950 space-y-1">
            <div className="font-bold flex items-center gap-1.5">
              <Printer className="w-4 h-4 text-sky-700" />
              <span>Quick Tips for Exporting Perfect PDFs:</span>
            </div>
            <ul className="list-disc list-inside space-y-0.5 text-sky-900 ml-1">
              <li>In your browser's print dialog, select <strong>Destination: Save as PDF</strong>.</li>
              <li>Set <strong>Paper size: A4</strong> (or Letter).</li>
              <li>Under More Settings, check <strong>Background graphics</strong> to preserve subtle divider lines.</li>
              <li>Set <strong>Margins: None or Default</strong> for full-bleed borders.</li>
            </ul>
          </div>
        )}

        {/* International Template Selector Bar (8 Templates) */}
        <div className="mt-6 pt-5 border-t border-slate-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-600" />
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Select International Standard ({INTERNATIONAL_TEMPLATES.length} Templates):
              </span>
            </div>

            {/* Load Sample Profiles */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-medium hidden sm:inline">Load Sample Profile:</span>
              <select
                onChange={(e) => handleLoadSample(e.target.value)}
                defaultValue="fresh-student"
                className="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1 text-xs text-slate-700 font-medium focus:outline-none focus:border-emerald-600"
              >
                <option value="fresh-student">🎓 Fresh Student (FAST / NUST / LUMS)</option>
                <option value="mto-candidate">🏢 FMCG MTO (Nestlé / PepsiCo / Engro)</option>
                <option value="software-engineer">💻 Senior Full-Stack Engineer (Remote USD)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-2.5">
            {INTERNATIONAL_TEMPLATES.map((tmpl) => {
              const isSelected = selectedTemplate === tmpl.id;
              return (
                <button
                  key={tmpl.id}
                  onClick={() => handleSelectTemplate(tmpl.id)}
                  className={`p-3 rounded-xl text-left border transition-all relative flex flex-col justify-between ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50/70 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'border-slate-200 bg-slate-50/50 hover:bg-white hover:border-slate-300'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-slate-900 leading-tight">
                        {tmpl.name}
                      </span>
                      {isSelected && (
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      )}
                    </div>
                    <p className="text-[10.5px] text-slate-500 line-clamp-1">{tmpl.regionStandard}</p>
                  </div>
                  <div className="mt-2 text-[10px] text-emerald-800 font-medium bg-emerald-100/60 px-1.5 py-0.5 rounded w-fit">
                    {tmpl.id === 'fresh-graduate'
                      ? 'Education First'
                      : tmpl.id === 'harvard-classic'
                      ? '100% ATS Gold'
                      : tmpl.id === 'silicon-valley'
                      ? 'Tech Stack Focus'
                      : tmpl.id === 'creative-portfolio'
                      ? 'Dual Panel'
                      : tmpl.id === 'academic-research'
                      ? 'Scholarship CV'
                      : 'Corporate Clean'}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Live ATS Readiness Score Banner */}
        <div className="mt-5 p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center font-extrabold text-white text-sm shadow-xs">
              {atsScore}%
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-900">
                  Live ATS Readiness & Formatting Score
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                    atsScore >= 85
                      ? 'bg-emerald-100 text-emerald-800'
                      : atsScore >= 65
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-red-100 text-red-800'
                  }`}
                >
                  {atsScore >= 85 ? 'Excellent' : atsScore >= 65 ? 'Good' : 'Needs Optimization'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                {checks.hasMetrics
                  ? '✓ Quantifiable metrics detected in bullets'
                  : '⚠ Add % or numbers to your bullets using the XYZ formula'}
                {' · '}
                {checks.hasTechnicalSkills ? '✓ Skills listed' : '⚠ Add at least 3 skills'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setTargetExpIndexForDuty(0);
                setIsDutiesModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-emerald-300 text-emerald-800 rounded-lg text-xs font-semibold hover:bg-emerald-50 transition-colors"
            >
              <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
              <span>Browse Profession Tasks & Duties</span>
            </button>
          </div>
        </div>
      </div>

      {/* View Toggle on Mobile & Tablets */}
      <div className="lg:hidden flex items-center justify-center p-1 bg-slate-200 rounded-xl max-w-xs mx-auto">
        <button
          onClick={() => setActiveTab('editor')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'editor' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
          }`}
        >
          Edit Resume
        </button>
        <button
          onClick={() => setActiveTab('preview')}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'preview' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
          }`}
        >
          Live A4 Preview
        </button>
      </div>

      {/* Main Workspace: Split Editor & Live Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Interactive Form Editor */}
        <div
          className={`lg:col-span-5 h-[850px] ${
            activeTab === 'preview' ? 'hidden lg:block' : 'block'
          }`}
        >
          <ResumeEditorForm
            data={resumeData}
            onChange={setResumeData}
            onOpenProfessionDutiesModal={(expIdx) => {
              setTargetExpIndexForDuty(expIdx);
              setIsDutiesModalOpen(true);
            }}
          />
        </div>

        {/* Right Column: High-Fidelity A4 Document Canvas */}
        <div
          className={`lg:col-span-7 bg-slate-200/80 p-3 sm:p-5 rounded-2xl border border-slate-300/80 h-[850px] overflow-y-auto ${
            activeTab === 'editor' ? 'hidden lg:block' : 'block'
          }`}
        >
          <div className="flex items-center justify-between mb-3 px-1 text-xs text-slate-600">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span className="font-semibold text-slate-800">
                Live A4 Preview: {INTERNATIONAL_TEMPLATES.find((t) => t.id === selectedTemplate)?.name}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrint}
                className="text-[11px] font-bold text-emerald-800 hover:text-emerald-950 inline-flex items-center gap-1"
              >
                <Printer className="w-3 h-3" />
                <span>Print Document</span>
              </button>
            </div>
          </div>

          {/* Document View Component */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <ResumeDocumentView data={resumeData} templateId={selectedTemplate} />
          </div>
        </div>
      </div>

      {/* Modal to insert pre-vetted task duties */}
      <ProfessionDutiesModal
        isOpen={isDutiesModalOpen}
        onClose={() => setIsDutiesModalOpen(false)}
        onInsertDuty={handleInsertDuty}
        initialRoleFilter={resumeData.personalInfo.title}
      />
    </div>
  );
};
