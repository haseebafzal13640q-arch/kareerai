import React, { useState } from 'react';
import { JobAnalysisResult } from '../types';
import { JOB_PRESETS } from '../data/sampleData';
import {
  Briefcase,
  Sparkles,
  Layers,
  Award,
  CheckCircle2,
  Copy,
  Check,
  Download,
  AlertTriangle,
  HelpCircle,
  TrendingUp,
  Cpu,
  RefreshCw,
  Building2,
  MapPin,
  Clock,
  Printer
} from 'lucide-react';

interface DynamicJobArchitectProps {
  initialRole?: string;
  initialCompany?: string;
  initialRegion?: string;
}

export const DynamicJobArchitect: React.FC<DynamicJobArchitectProps> = ({
  initialRole,
  initialCompany,
  initialRegion,
}) => {
  const [roleTitle, setRoleTitle] = useState(initialRole || 'Management Trainee Officer (MTO)');
  const [industry, setIndustry] = useState('FMCG & Consumer Goods');
  const [companyType, setCompanyType] = useState(initialCompany || 'Nestlé Pakistan / PepsiCo');
  const [region, setRegion] = useState(initialRegion || 'Pakistan (Lahore / Karachi / Islamabad PKR)');
  const [experienceLevel, setExperienceLevel] = useState('Fresh Graduate / Student (0-1 yr)');
  const [workMode, setWorkMode] = useState('Onsite (Pakistan)');
  const [customContext, setCustomContext] = useState(
    'Rotational MTO across supply chain, talent acquisition, brand marketing, and factory operations in Pakistan.'
  );

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<JobAnalysisResult | null>(null);
  const [copied, setCopied] = useState(false);

  // Sync if props change
  React.useEffect(() => {
    if (initialRole) setRoleTitle(initialRole);
    if (initialCompany) setCompanyType(initialCompany);
    if (initialRegion) setRegion(initialRegion);
  }, [initialRole, initialCompany, initialRegion]);

  const handleApplyPreset = (presetId: string) => {
    const preset = JOB_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    setRoleTitle(preset.roleTitle);
    setIndustry(preset.industry);
    setCompanyType(preset.companyType);
    setRegion(preset.region);
    setExperienceLevel(preset.experienceLevel);
    setWorkMode(preset.workMode);
    setCustomContext(preset.customContext);
  };

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!roleTitle.trim()) return;

    setLoading(true);
    try {
      const res = await fetch('/api/generate-job-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roleTitle,
          industry,
          companyType,
          region,
          experienceLevel,
          workMode,
          customContext,
        }),
      });
      const data = await res.json();
      setResult(data);
    } catch (err) {
      console.error('Failed to generate job analysis', err);
    } finally {
      setLoading(false);
    }
  };

  // Generate on first mount if empty
  React.useEffect(() => {
    if (!result) {
      handleGenerate();
    }
  }, []);

  const handleCopyMarkdown = () => {
    if (!result) return;
    let md = `# Job Description: ${result.jobTitle}\n\n`;
    md += `**Department:** ${result.department} | **Reports To:** ${result.reportingTo}\n`;
    md += `**Role Summary:** ${result.roleSummary}\n\n`;
    md += `## Key Duties & Responsibilities\n`;
    result.keyDuties.forEach((cat) => {
      md += `### ${cat.category} (${cat.weight})\n`;
      cat.duties.forEach((d) => (md += `- ${d}\n`));
    });
    md += `\n## Job Specifications: KSAO Profile\n`;
    md += `### Knowledge:\n` + result.ksao.knowledge.map((k) => `- ${k}`).join('\n') + '\n\n';
    md += `### Skills:\n` + result.ksao.skills.map((s) => `- ${s}`).join('\n') + '\n\n';
    md += `### Abilities:\n` + result.ksao.abilities.map((a) => `- ${a}`).join('\n') + '\n\n';
    md += `### Other Characteristics:\n` + result.ksao.other.map((o) => `- ${o}`).join('\n') + '\n\n';
    md += `## Compensation & Market Benchmarking (${result.compensation.currency})\n`;
    md += `- **Estimated Range:** ${result.compensation.range} (${result.compensation.frequency})\n`;
    md += `- **Entry Tier:** ${result.compensation.tierBreakdown.entry}\n`;
    md += `- **Median Benchmark:** ${result.compensation.tierBreakdown.median}\n`;
    md += `- **Top-Tier / Remote Peak:** ${result.compensation.tierBreakdown.topTier}\n\n`;
    md += `**Key Perks:**\n` + result.compensation.benefitsAndPerks.map((b) => `- ${b}`).join('\n') + '\n\n';
    md += `> **Market Insight by Haseeb:** ${result.compensation.marketInsights}\n`;

    navigator.clipboard.writeText(md);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadJSON = () => {
    if (!result) return;
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${result.jobTitle.replace(/[^a-zA-Z0-9]/g, '_')}_Kareer_Job_Architecture.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Intro Mission Card - Light Theme */}
      <div className="relative overflow-hidden rounded-2xl bg-white border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
            <Cpu className="w-3.5 h-3.5 text-emerald-600" />
            <span>Overcoming Static DOT & O*NET with Real-Time Data</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Dynamic Job Analysis & KSAO Architecture
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Traditional US databases (like DOT & O*NET) miss modern Pakistani corporate realities, internships, and remote USD dynamics. Haseeb generates precise <strong>Job Descriptions</strong> and <strong>KSAO Job Specifications</strong> (Knowledge, Skills, Abilities, Others) with transparent PKR and USD compensation ranges.
          </p>
        </div>

        {/* Quick Presets for Pakistani Companies */}
        <div className="mt-6 pt-5 border-t border-slate-100">
          <div className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">
            Quick 1-Click Company & Role Presets:
          </div>
          <div className="flex flex-wrap gap-2">
            {JOB_PRESETS.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handleApplyPreset(preset.id)}
                className="text-xs px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border border-slate-200 hover:border-emerald-300 transition-all font-medium flex items-center gap-1.5"
              >
                <Sparkles className="w-3 h-3 text-emerald-600" />
                <span>{preset.title}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Grid: Form on Left, Output on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Inputs (4 cols on lg) */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4 shadow-sm">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Layers className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Configure Role Parameters</h2>
          </div>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Target Job Title</label>
              <input
                type="text"
                value={roleTitle}
                onChange={(e) => setRoleTitle(e.target.value)}
                placeholder="e.g. Management Trainee Officer, Software Engineer"
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
                required
              />
            </div>

            <div className="grid grid-cols-1 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Company / Organization</label>
                <input
                  type="text"
                  value={companyType}
                  onChange={(e) => setCompanyType(e.target.value)}
                  placeholder="e.g. Nestlé Pakistan, PepsiCo, Systems Limited, Engro"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Industry Sector</label>
                <input
                  type="text"
                  value={industry}
                  onChange={(e) => setIndustry(e.target.value)}
                  placeholder="e.g. FMCG, IT Services, FinTech, Banking"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Location & Currency</label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-slate-900 focus:outline-none"
              >
                <option value="Pakistan (Lahore / Karachi / Islamabad PKR)">Pakistan (Lahore / Karachi / Islamabad PKR)</option>
                <option value="Pakistan (Onsite Lahore PKR)">Pakistan (Onsite Lahore PKR)</option>
                <option value="Pakistan (Onsite Karachi PKR)">Pakistan (Onsite Karachi PKR)</option>
                <option value="Pakistan (100% Remote PKR)">Pakistan (100% Remote PKR)</option>
                <option value="Global Remote (USD Base)">Global Remote (USD Base - Work from Pakistan)</option>
                <option value="UAE / GCC (Dubai AED)">UAE / GCC (Dubai AED)</option>
                <option value="United Kingdom (London GBP)">United Kingdom (GBP)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Experience</label>
                <select
                  value={experienceLevel}
                  onChange={(e) => setExperienceLevel(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-2.5 py-2 text-xs text-slate-900 focus:outline-none"
                >
                  <option value="Student / Internship (0 yrs)">Internship (0 yrs)</option>
                  <option value="Fresh Graduate / Student (0-1 yr)">Fresh Grad (0-1 yr)</option>
                  <option value="Junior / Mid (1-3 yrs)">Junior (1-3 yrs)</option>
                  <option value="Senior (4-7 yrs)">Senior (4-7 yrs)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Work Setup</label>
                <select
                  value={workMode}
                  onChange={(e) => setWorkMode(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-2.5 py-2 text-xs text-slate-900 focus:outline-none"
                >
                  <option value="Onsite (Pakistan)">Onsite Office</option>
                  <option value="Hybrid (2-3 days office)">Hybrid</option>
                  <option value="100% Remote (Work from Home)">100% Remote</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Context & University / Focus</label>
              <textarea
                value={customContext}
                onChange={(e) => setCustomContext(e.target.value)}
                rows={3}
                placeholder="Mention specific departments (Supply Chain, Engineering, Marketing) or tools..."
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl p-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-none resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading || !roleTitle.trim()}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-all disabled:opacity-50"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Haseeb is Architecting...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 stroke-[2.5]" />
                  <span>Generate Job Architecture</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results Column (8 cols on lg) */}
        <div className="lg:col-span-8 space-y-6">
          {loading && !result && (
            <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center space-y-4 shadow-sm">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto text-emerald-600 animate-pulse">
                <Cpu className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Synthesizing Competencies & Localized Benchmarks</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  Haseeb is structuring KSAOs, key duties, and calibrated compensation for {region}...
                </p>
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* Header & Export Bar */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 mb-1">
                      <Building2 className="w-3.5 h-3.5" />
                      <span>{result.department}</span>
                      <span className="text-slate-300">•</span>
                      <span>Reports to: {result.reportingTo}</span>
                    </div>
                    <h2 className="text-2xl font-black text-slate-900 tracking-tight">{result.jobTitle}</h2>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={handleCopyMarkdown}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-200"
                      title="Copy complete markdown specification"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied' : 'Copy MD'}</span>
                    </button>
                    <button
                      onClick={handleDownloadJSON}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-200"
                      title="Download structured JSON"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>JSON</span>
                    </button>
                    <button
                      onClick={() => window.print()}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-200 no-print"
                      title="Print or Save as PDF"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Print / PDF</span>
                    </button>
                  </div>
                </div>

                {/* Role Summary */}
                <div className="mt-5 space-y-2">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Role Summary</h4>
                  <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100">
                    {result.roleSummary}
                  </p>
                </div>

                {/* Static O*NET Critique Badge */}
                {result.onetCritique && (
                  <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs space-y-2">
                    <div className="flex items-center gap-2 font-bold text-amber-900">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>The Static O*NET / DOT Limitation For This Role</span>
                    </div>
                    <p className="text-slate-700 leading-relaxed">
                      <strong className="text-slate-900">Legacy Flaw:</strong> {result.onetCritique.staticLimitation}
                    </p>
                    <p className="text-emerald-900 leading-relaxed">
                      <strong className="text-emerald-800">Kareer Real-Time Advantage:</strong> {result.onetCritique.modernDynamicAdvantage}
                    </p>
                  </div>
                )}
              </div>

              {/* Categorized Key Duties & Responsibilities */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <h3 className="text-base font-bold text-slate-900">Key Duties & Weighted Responsibilities</h3>
                  </div>
                  <span className="text-xs text-slate-500 font-mono">Job Description Core</span>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {result.keyDuties.map((cat, idx) => (
                    <div key={idx} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                      <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                        <span className="font-bold text-sm text-slate-900">{cat.category}</span>
                        <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                          {cat.weight} Focus
                        </span>
                      </div>
                      <ul className="space-y-2 text-xs text-slate-700">
                        {cat.duties.map((duty, dIdx) => (
                          <li key={dIdx} className="flex items-start gap-2.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                            <span className="leading-relaxed">{duty}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>

              {/* Job Specification: KSAO Profile */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-teal-600" />
                    <div>
                      <h3 className="text-base font-bold text-slate-900">Job Specifications (KSAO Matrix)</h3>
                      <p className="text-xs text-slate-500">Knowledge, Skills, Abilities, and Other Characteristics</p>
                    </div>
                  </div>
                  <span className="text-xs text-slate-500 font-mono">I-O Competency Model</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Knowledge */}
                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                    <div className="flex items-center gap-2 mb-2.5 text-emerald-800 font-bold text-xs uppercase tracking-wider">
                      <div className="w-5 h-5 rounded-md bg-emerald-100 flex items-center justify-center text-emerald-800 text-xs">
                        K
                      </div>
                      <span>Knowledge (Principles & Domain)</span>
                    </div>
                    <ul className="space-y-2 text-xs text-slate-700">
                      {result.ksao.knowledge.map((k, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-emerald-600 font-bold">•</span>
                          <span>{k}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Skills */}
                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                    <div className="flex items-center gap-2 mb-2.5 text-teal-800 font-bold text-xs uppercase tracking-wider">
                      <div className="w-5 h-5 rounded-md bg-teal-100 flex items-center justify-center text-teal-800 text-xs">
                        S
                      </div>
                      <span>Skills (Execution & Technical Stack)</span>
                    </div>
                    <ul className="space-y-2 text-xs text-slate-700">
                      {result.ksao.skills.map((s, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-teal-600 font-bold">•</span>
                          <span>{s}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Abilities */}
                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                    <div className="flex items-center gap-2 mb-2.5 text-blue-800 font-bold text-xs uppercase tracking-wider">
                      <div className="w-5 h-5 rounded-md bg-blue-100 flex items-center justify-center text-blue-800 text-xs">
                        A
                      </div>
                      <span>Abilities (Cognitive & Adaptive)</span>
                    </div>
                    <ul className="space-y-2 text-xs text-slate-700">
                      {result.ksao.abilities.map((a, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-blue-600 font-bold">•</span>
                          <span>{a}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Others */}
                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                    <div className="flex items-center gap-2 mb-2.5 text-purple-800 font-bold text-xs uppercase tracking-wider">
                      <div className="w-5 h-5 rounded-md bg-purple-100 flex items-center justify-center text-purple-800 text-xs">
                        O
                      </div>
                      <span>Other Characteristics (Mindset & Values)</span>
                    </div>
                    <ul className="space-y-2 text-xs text-slate-700">
                      {result.ksao.other.map((o, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-purple-600 font-bold">•</span>
                          <span>{o}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Localized Compensation & Market Benchmarking */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-emerald-600" />
                    <div>
                      <h3 className="text-base font-bold text-slate-900">Localized Compensation Architecture</h3>
                      <p className="text-xs text-slate-500">
                        Market-calibrated for {region} ({result.compensation.currency})
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-black text-emerald-700">{result.compensation.range}</div>
                    <div className="text-[10px] text-slate-500 font-medium">{result.compensation.frequency}</div>
                  </div>
                </div>

                {/* Tier Breakdown */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                      Entry / P25 Tier
                    </span>
                    <span className="text-xs font-bold text-slate-800">{result.compensation.tierBreakdown.entry}</span>
                  </div>
                  <div className="bg-emerald-50 p-3.5 rounded-xl border border-emerald-200 text-center">
                    <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block mb-1">
                      Median / P50 Benchmark
                    </span>
                    <span className="text-xs font-extrabold text-emerald-900">{result.compensation.tierBreakdown.median}</span>
                  </div>
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] font-bold text-teal-800 uppercase tracking-wider block mb-1">
                      Top-Tier / P90 Peak
                    </span>
                    <span className="text-xs font-bold text-slate-800">{result.compensation.tierBreakdown.topTier}</span>
                  </div>
                </div>

                {/* Localized Benefits & Perks */}
                <div>
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">
                    Localized Benefits & Total Rewards Package:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {result.compensation.benefitsAndPerks.map((perk, pIdx) => (
                      <div
                        key={pIdx}
                        className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs text-slate-700"
                      >
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{perk}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Haseeb's Market Insights */}
                <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-200 text-xs text-slate-700 space-y-1.5">
                  <div className="font-bold text-emerald-800 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Haseeb's Talent Market Intelligence:</span>
                  </div>
                  <p className="leading-relaxed text-slate-600">{result.compensation.marketInsights}</p>
                </div>
              </div>

              {/* KSAO-Aligned Interview Evaluation Questions */}
              {result.interviewQuestions && result.interviewQuestions.length > 0 && (
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
                  <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                    <HelpCircle className="w-5 h-5 text-blue-600" />
                    <div>
                      <h3 className="text-base font-bold text-slate-900">Targeted Interview Questions (KSAO-Validated)</h3>
                      <p className="text-xs text-slate-500">Structured evaluation questions for hiring managers & candidates</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {result.interviewQuestions.map((q, qIdx) => (
                      <div key={qIdx} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 border border-blue-200">
                            {q.type}
                          </span>
                        </div>
                        <p className="text-sm font-semibold text-slate-900">"{q.question}"</p>
                        <div className="text-xs text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200">
                          <strong className="text-slate-800">What to look for in response:</strong> {q.whatToLookFor}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
