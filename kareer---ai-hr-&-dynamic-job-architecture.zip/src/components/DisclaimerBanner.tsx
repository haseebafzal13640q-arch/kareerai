import React, { useState } from 'react';
import { ShieldAlert, Info, X } from 'lucide-react';

interface DisclaimerBannerProps {
  onOpenModal: () => void;
}

export const DisclaimerBanner: React.FC<DisclaimerBannerProps> = ({ onOpenModal }) => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="bg-amber-50/90 border-b border-amber-200/80 px-4 py-2 text-xs text-amber-900">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
          <span className="truncate">
            <strong className="text-amber-950 font-semibold">AI HR Advisory Notice:</strong>{' '}
            Guidance, job specifications, and ATS insights provided by Haseeb are AI-assisted recommendations to help draft materials, not absolute legal HR counsel or guaranteed placement.
          </span>
          <button
            onClick={onOpenModal}
            className="text-emerald-700 hover:text-emerald-900 underline font-medium inline-flex items-center gap-1 shrink-0 ml-1"
          >
            <Info className="w-3 h-3" />
            Terms & Disclaimer
          </button>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="text-amber-800 hover:text-amber-950 p-1 shrink-0 rounded transition-colors"
          title="Dismiss notice"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
