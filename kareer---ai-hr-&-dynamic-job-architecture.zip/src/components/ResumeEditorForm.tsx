import React, { useState } from 'react';
import {
  ResumeData,
  ResumeWorkExperience,
  ResumeEducation,
  ResumeProject,
  ResumeCertification,
} from '../types';
import {
  User,
  Briefcase,
  GraduationCap,
  FolderGit2,
  Cpu,
  Award,
  Plus,
  Trash2,
  Sparkles,
  CheckCircle2,
  BookOpen,
  ArrowRight
} from 'lucide-react';

interface ResumeEditorFormProps {
  data: ResumeData;
  onChange: (updated: ResumeData) => void;
  onOpenProfessionDutiesModal: (targetExperienceIndex: number) => void;
}

export const ResumeEditorForm: React.FC<ResumeEditorFormProps> = ({
  data,
  onChange,
  onOpenProfessionDutiesModal,
}) => {
  const [activeSection, setActiveSection] = useState<
    'personal' | 'experience' | 'education' | 'projects' | 'skills' | 'certs'
  >('personal');

  const [enhancingBulletKey, setEnhancingBulletKey] = useState<string | null>(null);

  // Helper to update personal info
  const handlePersonalInfoChange = (field: keyof ResumeData['personalInfo'], val: string) => {
    onChange({
      ...data,
      personalInfo: {
        ...data.personalInfo,
        [field]: val,
      },
    });
  };

  // Helper to call AI bullet enhancement (Google XYZ formula)
  const handleEnhanceBullet = async (expIndex: number, bulletIndex: number, currentBullet: string) => {
    if (!currentBullet.trim()) return;
    const key = `${expIndex}-${bulletIndex}`;
    setEnhancingBulletKey(key);

    try {
      const res = await fetch('/api/optimize-resume-bullet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bullet: currentBullet,
          targetRole: data.experience[expIndex]?.jobTitle || data.personalInfo.title || 'Professional',
        }),
      });
      const result = await res.json();
      if (result.enhancedBullet) {
        const newExp = [...data.experience];
        newExp[expIndex].bullets[bulletIndex] = result.enhancedBullet;
        onChange({ ...data, experience: newExp });
      }
    } catch (e) {
      console.error('Enhance bullet error:', e);
    } finally {
      setEnhancingBulletKey(null);
    }
  };

  // Experience handlers
  const handleAddExperience = () => {
    const newEntry: ResumeWorkExperience = {
      id: `exp-${Date.now()}`,
      jobTitle: 'Associate / Management Trainee',
      company: 'Company / Organization Name',
      location: 'City, Pakistan',
      startDate: 'Jan 2025',
      endDate: 'Present',
      isCurrent: true,
      bullets: [
        'Executed primary responsibilities, delivering 15% improvement in operational turnaround time.',
        'Collaborated with cross-functional teams to standardize weekly performance tracking.',
      ],
    };
    onChange({ ...data, experience: [newEntry, ...data.experience] });
  };

  const handleUpdateExp = (index: number, field: keyof ResumeWorkExperience, value: any) => {
    const updated = [...data.experience];
    updated[index] = { ...updated[index], [field]: value };
    onChange({ ...data, experience: updated });
  };

  const handleDeleteExp = (index: number) => {
    const updated = data.experience.filter((_, i) => i !== index);
    onChange({ ...data, experience: updated });
  };

  const handleAddExpBullet = (expIndex: number) => {
    const updated = [...data.experience];
    updated[expIndex].bullets.push('Accomplished [Task] as measured by [Metric %], by implementing [Method/Tool].');
    onChange({ ...data, experience: updated });
  };

  const handleUpdateExpBullet = (expIndex: number, bulletIndex: number, text: string) => {
    const updated = [...data.experience];
    updated[expIndex].bullets[bulletIndex] = text;
    onChange({ ...data, experience: updated });
  };

  const handleDeleteExpBullet = (expIndex: number, bulletIndex: number) => {
    const updated = [...data.experience];
    updated[expIndex].bullets = updated[expIndex].bullets.filter((_, i) => i !== bulletIndex);
    onChange({ ...data, experience: updated });
  };

  // Education handlers
  const handleAddEducation = () => {
    const newEdu: ResumeEducation = {
      id: `edu-${Date.now()}`,
      degree: 'Bachelor of Science in Computer Science / Business Administration',
      institution: 'University / Institute Name',
      location: 'Lahore, Pakistan',
      graduationYear: '2022 - 2026',
      gpaOrHonors: 'CGPA: 3.65 / 4.00',
      details: 'Major coursework, honors, or key university society leadership.',
    };
    onChange({ ...data, education: [...data.education, newEdu] });
  };

  const handleUpdateEdu = (index: number, field: keyof ResumeEducation, value: string) => {
    const updated = [...data.education];
    updated[index] = { ...updated[index], [field]: value };
    onChange({ ...data, education: updated });
  };

  const handleDeleteEdu = (index: number) => {
    onChange({ ...data, education: data.education.filter((_, i) => i !== index) });
  };

  // Project handlers
  const handleAddProject = () => {
    const newProj: ResumeProject = {
      id: `proj-${Date.now()}`,
      name: 'Key Project / Final Year Project (FYP)',
      role: 'Lead Architect / Team Lead',
      technologies: 'React, Node.js, PostgreSQL, Docker',
      link: 'github.com/your-username/project-repo',
      bullets: [
        'Built full-stack application serving 500+ active users with 99.9% uptime.',
        'Engineered responsive interface and secure authentication flow.',
      ],
    };
    onChange({ ...data, projects: [...data.projects, newProj] });
  };

  const handleUpdateProject = (index: number, field: keyof ResumeProject, value: any) => {
    const updated = [...data.projects];
    updated[index] = { ...updated[index], [field]: value };
    onChange({ ...data, projects: updated });
  };

  const handleDeleteProject = (index: number) => {
    onChange({ ...data, projects: data.projects.filter((_, i) => i !== index) });
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col h-full overflow-hidden">
      {/* Section Navigation Tabs */}
      <div className="flex items-center gap-1 p-2 bg-slate-50 border-b border-slate-200 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveSection('personal')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
            activeSection === 'personal'
              ? 'bg-white text-emerald-800 shadow-xs border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <User className="w-3.5 h-3.5 text-emerald-600" />
          <span>Profile & Info</span>
        </button>

        <button
          onClick={() => setActiveSection('experience')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
            activeSection === 'experience'
              ? 'bg-white text-emerald-800 shadow-xs border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Briefcase className="w-3.5 h-3.5 text-emerald-600" />
          <span>Experience ({data.experience.length})</span>
        </button>

        <button
          onClick={() => setActiveSection('education')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
            activeSection === 'education'
              ? 'bg-white text-emerald-800 shadow-xs border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <GraduationCap className="w-3.5 h-3.5 text-emerald-600" />
          <span>Education ({data.education.length})</span>
        </button>

        <button
          onClick={() => setActiveSection('projects')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
            activeSection === 'projects'
              ? 'bg-white text-emerald-800 shadow-xs border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FolderGit2 className="w-3.5 h-3.5 text-emerald-600" />
          <span>Projects ({data.projects.length})</span>
        </button>

        <button
          onClick={() => setActiveSection('skills')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
            activeSection === 'skills'
              ? 'bg-white text-emerald-800 shadow-xs border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Cpu className="w-3.5 h-3.5 text-emerald-600" />
          <span>Skills Matrix</span>
        </button>

        <button
          onClick={() => setActiveSection('certs')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
            activeSection === 'certs'
              ? 'bg-white text-emerald-800 shadow-xs border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Award className="w-3.5 h-3.5 text-emerald-600" />
          <span>Certs & Languages</span>
        </button>
      </div>

      {/* Editor Content Area */}
      <div className="p-5 flex-1 overflow-y-auto space-y-5">
        {/* Section 1: Personal Info & Summary */}
        {activeSection === 'personal' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={data.personalInfo.fullName}
                  onChange={(e) => handlePersonalInfoChange('fullName', e.target.value)}
                  placeholder="e.g. Zainab Ahmed"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Target Headline / Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={data.personalInfo.title}
                  onChange={(e) => handlePersonalInfoChange('title', e.target.value)}
                  placeholder="e.g. BS Computer Science Graduate | Full-Stack Engineer"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={data.personalInfo.email}
                  onChange={(e) => handlePersonalInfoChange('email', e.target.value)}
                  placeholder="e.g. name@example.com"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Phone Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={data.personalInfo.phone}
                  onChange={(e) => handlePersonalInfoChange('phone', e.target.value)}
                  placeholder="e.g. +92 300 1234567"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Location / City <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={data.personalInfo.location}
                  onChange={(e) => handlePersonalInfoChange('location', e.target.value)}
                  placeholder="e.g. Lahore, Pakistan"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  LinkedIn URL or Handle
                </label>
                <input
                  type="text"
                  value={data.personalInfo.linkedin}
                  onChange={(e) => handlePersonalInfoChange('linkedin', e.target.value)}
                  placeholder="e.g. linkedin.com/in/username"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  GitHub Profile (Optional)
                </label>
                <input
                  type="text"
                  value={data.personalInfo.github || ''}
                  onChange={(e) => handlePersonalInfoChange('github', e.target.value)}
                  placeholder="e.g. github.com/username"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Portfolio / Personal Website (Optional)
                </label>
                <input
                  type="text"
                  value={data.personalInfo.portfolio || ''}
                  onChange={(e) => handlePersonalInfoChange('portfolio', e.target.value)}
                  placeholder="e.g. yourportfolio.com"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>
            </div>

            {/* Summary */}
            <div className="pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  Professional Summary / Career Objective
                </label>
                <span className="text-[11px] text-slate-500">
                  {data.summary.length} characters (Recommended: 250 - 450)
                </span>
              </div>
              <textarea
                rows={4}
                value={data.summary}
                onChange={(e) => onChange({ ...data, summary: e.target.value })}
                placeholder="Write a 3-4 sentence summary highlighting your degree, key technical competencies, academic projects, or commercial achievements..."
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 leading-relaxed"
              />
            </div>
          </div>
        )}

        {/* Section 2: Work Experience & Internships */}
        {activeSection === 'experience' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900">Work Experience & Internships</h3>
                <p className="text-[11px] text-slate-500">
                  Format bullets using the XYZ Formula: "Accomplished [X] as measured by [Y] by doing [Z]"
                </p>
              </div>
              <button
                onClick={handleAddExperience}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Position</span>
              </button>
            </div>

            {data.experience.map((exp, expIdx) => (
              <div
                key={exp.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3 relative group"
              >
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="text-xs font-bold text-slate-800">
                    Position #{expIdx + 1}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onOpenProfessionDutiesModal(expIdx)}
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 transition-colors"
                      title="Insert pre-vetted task duties from top professions"
                    >
                      <BookOpen className="w-3 h-3" />
                      <span>Insert Profession Duties</span>
                    </button>
                    <button
                      onClick={() => handleDeleteExp(expIdx)}
                      className="text-slate-400 hover:text-red-600 p-1 transition-colors"
                      title="Delete this position"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Job Title / Role
                    </label>
                    <input
                      type="text"
                      value={exp.jobTitle}
                      onChange={(e) => handleUpdateExp(expIdx, 'jobTitle', e.target.value)}
                      placeholder="e.g. Software Engineering Intern"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Company / Organization
                    </label>
                    <input
                      type="text"
                      value={exp.company}
                      onChange={(e) => handleUpdateExp(expIdx, 'company', e.target.value)}
                      placeholder="e.g. Systems Limited or Nestlé Pakistan"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Location
                    </label>
                    <input
                      type="text"
                      value={exp.location}
                      onChange={(e) => handleUpdateExp(expIdx, 'location', e.target.value)}
                      placeholder="e.g. Lahore, Pakistan or Remote"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex-1">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Start Date
                      </label>
                      <input
                        type="text"
                        value={exp.startDate}
                        onChange={(e) => handleUpdateExp(expIdx, 'startDate', e.target.value)}
                        placeholder="Jun 2024"
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                      />
                    </div>
                    <div className="flex-1">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        End Date
                      </label>
                      <input
                        type="text"
                        disabled={exp.isCurrent}
                        value={exp.isCurrent ? 'Present' : exp.endDate}
                        onChange={(e) => handleUpdateExp(expIdx, 'endDate', e.target.value)}
                        placeholder="Present or Aug 2024"
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600 disabled:bg-slate-100 disabled:text-slate-400"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id={`current-${exp.id}`}
                    checked={exp.isCurrent}
                    onChange={(e) => handleUpdateExp(expIdx, 'isCurrent', e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <label htmlFor={`current-${exp.id}`} className="text-xs text-slate-600 font-medium cursor-pointer">
                    I currently work in this position
                  </label>
                </div>

                {/* Bullets */}
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-bold text-slate-700">
                      Key Accomplishments & Bullet Points:
                    </label>
                    <button
                      onClick={() => handleAddExpBullet(expIdx)}
                      className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 inline-flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Add Bullet</span>
                    </button>
                  </div>

                  {exp.bullets.map((bullet, bulletIdx) => {
                    const isEnhancing = enhancingBulletKey === `${expIdx}-${bulletIdx}`;
                    return (
                      <div key={bulletIdx} className="space-y-1">
                        <div className="flex items-start gap-1.5">
                          <span className="text-slate-400 text-xs mt-2">•</span>
                          <textarea
                            rows={2}
                            value={bullet}
                            onChange={(e) => handleUpdateExpBullet(expIdx, bulletIdx, e.target.value)}
                            className="flex-1 px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600 leading-snug"
                          />
                          <div className="flex flex-col gap-1">
                            <button
                              onClick={() => handleEnhanceBullet(expIdx, bulletIdx, bullet)}
                              disabled={isEnhancing}
                              title="Enhance with Haseeb (Google XYZ Formula)"
                              className="p-1.5 rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 transition-colors disabled:opacity-50"
                            >
                              <Sparkles className={`w-3.5 h-3.5 ${isEnhancing ? 'animate-spin' : ''}`} />
                            </button>
                            <button
                              onClick={() => handleDeleteExpBullet(expIdx, bulletIdx)}
                              title="Remove bullet"
                              className="p-1.5 text-slate-400 hover:text-red-600 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Section 3: Education */}
        {activeSection === 'education' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900">Education & Academic Distinctions</h3>
                <p className="text-[11px] text-slate-500">
                  Highlight degrees, CGPA/Honors, and key university achievements.
                </p>
              </div>
              <button
                onClick={handleAddEducation}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Degree</span>
              </button>
            </div>

            {data.education.map((edu, eduIdx) => (
              <div
                key={edu.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3"
              >
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="text-xs font-bold text-slate-800">Degree #{eduIdx + 1}</span>
                  <button
                    onClick={() => handleDeleteEdu(eduIdx)}
                    className="text-slate-400 hover:text-red-600 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Degree / Program
                    </label>
                    <input
                      type="text"
                      value={edu.degree}
                      onChange={(e) => handleUpdateEdu(eduIdx, 'degree', e.target.value)}
                      placeholder="e.g. BS Computer Science or BBA (Honors)"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      University / Institution
                    </label>
                    <input
                      type="text"
                      value={edu.institution}
                      onChange={(e) => handleUpdateEdu(eduIdx, 'institution', e.target.value)}
                      placeholder="e.g. FAST-NUCES, NUST, LUMS, IBA, or GIKI"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Graduation Year or Period
                    </label>
                    <input
                      type="text"
                      value={edu.graduationYear}
                      onChange={(e) => handleUpdateEdu(eduIdx, 'graduationYear', e.target.value)}
                      placeholder="e.g. 2022 - 2026"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      CGPA / Honors / Grade
                    </label>
                    <input
                      type="text"
                      value={edu.gpaOrHonors || ''}
                      onChange={(e) => handleUpdateEdu(eduIdx, 'gpaOrHonors', e.target.value)}
                      placeholder="e.g. CGPA: 3.75 / 4.00 (Dean’s Honor List)"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Relevant Coursework & Societies (Optional)
                  </label>
                  <input
                    type="text"
                    value={edu.details || ''}
                    onChange={(e) => handleUpdateEdu(eduIdx, 'details', e.target.value)}
                    placeholder="e.g. Data Structures, Algorithms, Cloud Architecture; Head of IEEE Student Branch"
                    className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Section 4: Projects */}
        {activeSection === 'projects' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900">Key Projects & Final Year Project (FYP)</h3>
                <p className="text-[11px] text-slate-500">
                  Critical proof-of-work for students and graduates applying for competitive roles.
                </p>
              </div>
              <button
                onClick={handleAddProject}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Project</span>
              </button>
            </div>

            {data.projects.map((proj, projIdx) => (
              <div
                key={proj.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3"
              >
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="text-xs font-bold text-slate-800">Project #{projIdx + 1}</span>
                  <button
                    onClick={() => handleDeleteProject(projIdx)}
                    className="text-slate-400 hover:text-red-600 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Project Title
                    </label>
                    <input
                      type="text"
                      value={proj.name}
                      onChange={(e) => handleUpdateProject(projIdx, 'name', e.target.value)}
                      placeholder="e.g. AI-Powered Smart Campus Shuttle App"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Role / Contribution
                    </label>
                    <input
                      type="text"
                      value={proj.role || ''}
                      onChange={(e) => handleUpdateProject(projIdx, 'role', e.target.value)}
                      placeholder="e.g. Lead Full-Stack Architect"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Technologies & Tech Stack
                    </label>
                    <input
                      type="text"
                      value={proj.technologies}
                      onChange={(e) => handleUpdateProject(projIdx, 'technologies', e.target.value)}
                      placeholder="e.g. React, Node.js, PostgreSQL, Docker"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      GitHub or Live Demo URL (Optional)
                    </label>
                    <input
                      type="text"
                      value={proj.link || ''}
                      onChange={(e) => handleUpdateProject(projIdx, 'link', e.target.value)}
                      placeholder="e.g. github.com/username/project"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Project Outcomes & Impact Bullets:
                  </label>
                  <textarea
                    rows={2}
                    value={proj.bullets.join('\n')}
                    onChange={(e) =>
                      handleUpdateProject(
                        projIdx,
                        'bullets',
                        e.target.value.split('\n').filter((b) => b.trim().length > 0)
                      )
                    }
                    placeholder="Enter each bullet on a new line..."
                    className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:border-emerald-600 leading-snug"
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Section 5: Skills Matrix */}
        {activeSection === 'skills' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Skills & Competency Matrix</h3>
              <p className="text-[11px] text-slate-500">
                Separate items with commas. ATS parsers match skills directly against job descriptions.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Technical & Core Hard Skills
              </label>
              <textarea
                rows={2}
                value={data.skills.technical.join(', ')}
                onChange={(e) =>
                  onChange({
                    ...data,
                    skills: {
                      ...data.skills,
                      technical: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                    },
                  })
                }
                placeholder="e.g. Python, TypeScript, React, SQL, Financial Modeling, P&L Management"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Software, Tools & Platforms
              </label>
              <textarea
                rows={2}
                value={data.skills.tools.join(', ')}
                onChange={(e) =>
                  onChange({
                    ...data,
                    skills: {
                      ...data.skills,
                      tools: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                    },
                  })
                }
                placeholder="e.g. Git, Docker, PowerBI, SAP S/4HANA, Figma, AWS, Postman"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Soft Competencies & Work Ethic
              </label>
              <textarea
                rows={2}
                value={data.skills.soft.join(', ')}
                onChange={(e) =>
                  onChange({
                    ...data,
                    skills: {
                      ...data.skills,
                      soft: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                    },
                  })
                }
                placeholder="e.g. Cross-Functional Teamwork, Executive Presentation, Structured Problem Solving"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-600"
              />
            </div>
          </div>
        )}

        {/* Section 6: Certifications & Languages */}
        {activeSection === 'certs' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Certifications & Accreditations</h3>
              <p className="text-[11px] text-slate-500">
                Industry certifications boost student credibility by 40% on recruitment screening.
              </p>
            </div>

            <div className="space-y-3">
              {data.certifications.map((cert, certIdx) => (
                <div key={cert.id} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={cert.name}
                    onChange={(e) => {
                      const updated = [...data.certifications];
                      updated[certIdx].name = e.target.value;
                      onChange({ ...data, certifications: updated });
                    }}
                    placeholder="e.g. AWS Solutions Architect Associate"
                    className="flex-2 px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                  />
                  <input
                    type="text"
                    value={cert.issuer}
                    onChange={(e) => {
                      const updated = [...data.certifications];
                      updated[certIdx].issuer = e.target.value;
                      onChange({ ...data, certifications: updated });
                    }}
                    placeholder="e.g. Amazon Web Services"
                    className="flex-1 px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                  />
                  <input
                    type="text"
                    value={cert.year}
                    onChange={(e) => {
                      const updated = [...data.certifications];
                      updated[certIdx].year = e.target.value;
                      onChange({ ...data, certifications: updated });
                    }}
                    placeholder="e.g. 2025"
                    className="w-20 px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                  />
                  <button
                    onClick={() => {
                      onChange({
                        ...data,
                        certifications: data.certifications.filter((_, i) => i !== certIdx),
                      });
                    }}
                    className="text-slate-400 hover:text-red-600 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}

              <button
                onClick={() => {
                  const newCert: ResumeCertification = {
                    id: `cert-${Date.now()}`,
                    name: 'Professional Certificate Name',
                    issuer: 'Coursera / Google / Meta / McKinsey',
                    year: '2025',
                  };
                  onChange({ ...data, certifications: [...data.certifications, newCert] });
                }}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 hover:text-emerald-900"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Certification</span>
              </button>
            </div>

            <div className="pt-4 border-t border-slate-200">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Languages (comma-separated)
              </label>
              <input
                type="text"
                value={data.languages.join(', ')}
                onChange={(e) =>
                  onChange({
                    ...data,
                    languages: e.target.value.split(',').map((l) => l.trim()).filter(Boolean),
                  })
                }
                placeholder="e.g. English (Fluent / Professional), Urdu (Native / Bilingual)"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-600"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
