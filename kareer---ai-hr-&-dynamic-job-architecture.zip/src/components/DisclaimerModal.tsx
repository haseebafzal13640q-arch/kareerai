import React from 'react';
import { ShieldCheck, Scale, Award, AlertCircle, X, Check } from 'lucide-react';

interface DisclaimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccept?: () => void;
  isOnboarding?: boolean;
}

export const DisclaimerModal: React.FC<DisclaimerModalProps> = ({
  isOpen,
  onClose,
  onAccept,
  isOnboarding = false,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 border border-emerald-200 flex items-center justify-center text-emerald-700">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                {isOnboarding ? 'Welcome to Kareer: Ethical HR Boundary' : 'Professional Boundary & Ethical AI Disclaimer'}
              </h2>
              <p className="text-xs text-slate-500">Standard Governance & Student/Candidate Agreement</p>
            </div>
          </div>
          {!isOnboarding && (
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="space-y-4 my-6 text-sm text-slate-700 leading-relaxed">
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong className="block text-amber-950 font-semibold mb-1">Notice of Professional Boundary:</strong>
              Guidance, job specifications, compensation estimates, and ATS feedback provided by Haseeb and Kareer are AI-assisted recommendations designed to help students and professionals draft materials, evaluate options, and architect roles. They do <strong>not</strong> constitute absolute legal HR counsel or guaranteed job placement.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-2 text-emerald-800 font-semibold text-xs mb-1.5">
                <Scale className="w-4 h-4" />
                <span>Personal Responsibility</span>
              </div>
              <p className="text-xs text-slate-600">
                By utilizing these insights, you agree that final implementation remains your personal responsibility for all provided application materials, hiring criteria, compensation decisions, and career moves.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-2 text-blue-800 font-semibold text-xs mb-1.5">
                <Award className="w-4 h-4" />
                <span>Pakistani & Global Standards</span>
              </div>
              <p className="text-xs text-slate-600">
                Our dynamic job analysis bypasses static, outdated occupational models (such as DOT & O*NET) to reflect real-time 2026 competencies, localized Pakistani industry realities (PKR), internships, and global remote opportunities.
              </p>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Haseeb’s Operational Commitment:</h4>
            <ul className="text-xs space-y-1.5 text-slate-600 list-disc list-inside">
              <li>Deliver clear KSAO frameworks (Knowledge, Skills, Abilities, Others) tailored to specific companies.</li>
              <li>Provide honest, actionable ATS score evaluations without false optimism.</li>
              <li>Advocate for fair localized compensation benchmarks (Pakistani PKR gross/net and remote USD).</li>
              <li>Empower students with accessible pathways to top companies like Nestlé, PepsiCo, Engro, and Systems.</li>
            </ul>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
          {isOnboarding ? (
            <button
              onClick={() => {
                if (onAccept) onAccept();
                onClose();
              }}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md shadow-emerald-600/20"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              I Understand & Agree to Terms
            </button>
          ) : (
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-medium text-xs transition-colors"
            >
              Close
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
