import React from 'react';

interface MarkdownViewProps {
  content: string;
  className?: string;
}

export const MarkdownView: React.FC<MarkdownViewProps> = ({ content, className = '' }) => {
  if (!content) return null;

  // Split into lines and parse common markdown elements
  const lines = content.split('\n');

  const renderFormattedText = (text: string) => {
    // Process bold, italic, inline code
    const parts: React.ReactNode[] = [];
    let remaining = text;
    let key = 0;

    // Simple parser for **bold**, *italic*, `code`, and [link](url)
    const regex = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
    let match;
    let lastIndex = 0;

    while ((match = regex.exec(remaining)) !== null) {
      if (match.index > lastIndex) {
        parts.push(remaining.substring(lastIndex, match.index));
      }

      const matchedText = match[0];
      if (matchedText.startsWith('**') && matchedText.endsWith('**')) {
        parts.push(
          <strong key={key++} className="font-semibold text-emerald-800">
            {matchedText.slice(2, -2)}
          </strong>
        );
      } else if (matchedText.startsWith('*') && matchedText.endsWith('*')) {
        parts.push(
          <em key={key++} className="italic text-slate-700">
            {matchedText.slice(1, -1)}
          </em>
        );
      } else if (matchedText.startsWith('`') && matchedText.endsWith('`')) {
        parts.push(
          <code key={key++} className="px-1.5 py-0.5 rounded bg-slate-100 text-emerald-800 font-mono text-xs border border-slate-200">
            {matchedText.slice(1, -1)}
          </code>
        );
      }

      lastIndex = match.index + matchedText.length;
    }

    if (lastIndex < remaining.length) {
      parts.push(remaining.substring(lastIndex));
    }

    return parts.length > 0 ? parts : text;
  };

  return (
    <div className={`space-y-2 text-sm leading-relaxed text-slate-700 ${className}`}>
      {lines.map((line, idx) => {
        const trimmed = line.trim();

        if (trimmed.startsWith('### ')) {
          return (
            <h3 key={idx} className="text-base font-bold text-slate-900 mt-4 mb-2 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 inline-block"></span>
              {trimmed.substring(4)}
            </h3>
          );
        }
        if (trimmed.startsWith('## ')) {
          return (
            <h2 key={idx} className="text-lg font-bold text-slate-900 mt-5 mb-2 pb-1 border-b border-slate-200">
              {trimmed.substring(3)}
            </h2>
          );
        }
        if (trimmed.startsWith('# ')) {
          return (
            <h1 key={idx} className="text-xl font-extrabold text-slate-900 mt-6 mb-3">
              {trimmed.substring(2)}
            </h1>
          );
        }
        if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
          return (
            <div key={idx} className="flex items-start gap-2 pl-2 my-1">
              <span className="text-emerald-600 mt-1 select-none font-bold">•</span>
              <div className="flex-1">{renderFormattedText(trimmed.substring(2))}</div>
            </div>
          );
        }
        if (/^\d+\.\s/.test(trimmed)) {
          const num = trimmed.match(/^\d+\./)?.[0] || '1.';
          const rest = trimmed.replace(/^\d+\.\s*/, '');
          return (
            <div key={idx} className="flex items-start gap-2 pl-2 my-1">
              <span className="text-emerald-700 font-mono text-xs mt-0.5 font-bold">{num}</span>
              <div className="flex-1">{renderFormattedText(rest)}</div>
            </div>
          );
        }
        if (trimmed.startsWith('> ')) {
          return (
            <blockquote key={idx} className="pl-3 border-l-2 border-emerald-600 text-slate-600 italic my-2 py-0.5 bg-emerald-50 rounded-r">
              {renderFormattedText(trimmed.substring(2))}
            </blockquote>
          );
        }
        if (trimmed === '---') {
          return <hr key={idx} className="border-slate-200 my-4" />;
        }
        if (!trimmed) {
          return <div key={idx} className="h-1.5" />;
        }

        return <p key={idx} className="my-1">{renderFormattedText(line)}</p>;
      })}
    </div>
  );
};
