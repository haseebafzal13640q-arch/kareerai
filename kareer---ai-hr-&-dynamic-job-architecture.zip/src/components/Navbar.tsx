import React from 'react';
import { ActiveTab } from '../types';
import {
  Briefcase,
  FileCheck,
  Compass,
  TrendingUp,
  Sparkles,
  Shield,
  UserCheck,
  GraduationCap,
  FileText,
  BookOpen,
} from 'lucide-react';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenDisclaimer: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, onOpenDisclaimer }) => {
  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    {
      id: 'pak-jobs',
      label: 'Pakistan Jobs & Internships',
      icon: <GraduationCap className="w-4 h-4 text-emerald-600" />,
      badge: 'Nestle, Pepsi, Engro',
    },
    {
      id: 'resume-builder',
      label: 'Resume Builder',
      icon: <FileText className="w-4 h-4 text-teal-600" />,
      badge: '5 Intl Templates',
    },
    {
      id: 'profession-duties',
      label: 'Professions & Duties',
      icon: <BookOpen className="w-4 h-4 text-emerald-600" />,
      badge: 'Tasks & Wishlist',
    },
    {
      id: 'job-architect',
      label: 'Job Architect (KSAOs)',
      icon: <Briefcase className="w-4 h-4" />,
    },
    {
      id: 'ats-optimizer',
      label: 'ATS Optimizer',
      icon: <FileCheck className="w-4 h-4" />,
    },
    {
      id: 'skill-gap',
      label: 'Skill Gap & Roadmap',
      icon: <Compass className="w-4 h-4" />,
    },
    {
      id: 'market-radar',
      label: 'Market Comp',
      icon: <TrendingUp className="w-4 h-4" />,
    },
    {
      id: 'consult-haseeb',
      label: 'Consult Haseeb',
      icon: <Sparkles className="w-4 h-4 text-emerald-600" />,
      badge: 'Live AI HR',
    },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Identity */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('pak-jobs')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 p-0.5 shadow-md shadow-emerald-500/10">
              <div className="w-full h-full bg-emerald-600 rounded-[10px] flex items-center justify-center">
                <span className="font-extrabold text-lg text-white">K</span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-slate-900 font-['Plus_Jakarta_Sans',sans-serif]">
                  Kareer
                </span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                  AI HR & Jobs
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Led by <strong className="text-slate-700">Haseeb</strong>, AI Job Architect</span>
              </div>
            </div>
          </div>

          {/* Desktop Nav Items */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-50 p-1.5 rounded-xl border border-slate-200">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all relative ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {item.badge && !isActive && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Header Actions */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onOpenDisclaimer}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs border border-slate-200 transition-colors font-medium"
              title="View Ethical AI & Legal Boundary Disclaimer"
            >
              <Shield className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Disclaimer</span>
            </button>

            <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center justify-center font-bold text-xs">
                <UserCheck className="w-4 h-4 text-emerald-700" />
              </div>
              <div className="text-left hidden md:block">
                <div className="text-xs font-semibold text-slate-900 leading-tight">Haseeb</div>
                <div className="text-[10px] text-emerald-700 font-medium">Lead Consultant</div>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="flex lg:hidden overflow-x-auto py-2.5 gap-1.5 border-t border-slate-200 scrollbar-none">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                  isActive
                    ? 'bg-emerald-600 text-white font-bold shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
