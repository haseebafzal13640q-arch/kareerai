import React from 'react';
import { ResumeData, ResumeTemplateId } from '../types';
import { Mail, Phone, MapPin, Globe, Linkedin, Github, ExternalLink } from 'lucide-react';

interface ResumeDocumentViewProps {
  data: ResumeData;
  templateId: ResumeTemplateId;
}

export const ResumeDocumentView: React.FC<ResumeDocumentViewProps> = ({ data, templateId }) => {
  const { personalInfo, summary, experience, education, skills, projects, certifications, languages } = data;

  // Render Template 1: Harvard Classic (ATS Gold Standard)
  if (templateId === 'harvard-classic') {
    return (
      <div className="bg-white text-slate-900 p-8 sm:p-10 font-serif leading-relaxed text-[13px] shadow-sm max-w-[850px] mx-auto min-h-[1050px] print:p-0 print:shadow-none print:max-w-none print:text-[12px]">
        {/* Header */}
        <div className="text-center border-b-2 border-slate-900 pb-3 mb-4">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-normal uppercase text-slate-900">
            {personalInfo.fullName || 'Your Full Name'}
          </h1>
          {personalInfo.title && (
            <p className="text-xs font-sans tracking-wide text-slate-700 mt-1 uppercase font-semibold">
              {personalInfo.title}
            </p>
          )}
          <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-xs font-sans text-slate-700 mt-2">
            {personalInfo.email && <span>{personalInfo.email}</span>}
            {personalInfo.phone && <span>·</span>}
            {personalInfo.phone && <span>{personalInfo.phone}</span>}
            {personalInfo.location && <span>·</span>}
            {personalInfo.location && <span>{personalInfo.location}</span>}
            {personalInfo.linkedin && <span>·</span>}
            {personalInfo.linkedin && <span>{personalInfo.linkedin}</span>}
            {personalInfo.github && <span>·</span>}
            {personalInfo.github && <span>{personalInfo.github}</span>}
          </div>
        </div>

        {/* Summary */}
        {summary && (
          <div className="mb-4">
            <h2 className="text-xs font-sans font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-1.5">
              Professional Summary
            </h2>
            <p className="text-justify font-sans text-[12.5px] text-slate-800 leading-snug">
              {summary}
            </p>
          </div>
        )}

        {/* Experience */}
        {experience.length > 0 && (
          <div className="mb-4">
            <h2 className="text-xs font-sans font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
              Professional Experience
            </h2>
            <div className="space-y-3 font-sans">
              {experience.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                    <div>
                      <span>{exp.jobTitle}</span>
                      <span className="font-normal text-slate-700"> — {exp.company}</span>
                    </div>
                    <span className="text-[11px] font-normal text-slate-600">
                      {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate} | {exp.location}
                    </span>
                  </div>
                  <ul className="list-disc list-outside ml-4 mt-1 space-y-1 text-[12px] text-slate-800 leading-snug">
                    {exp.bullets.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education */}
        {education.length > 0 && (
          <div className="mb-4">
            <h2 className="text-xs font-sans font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
              Education
            </h2>
            <div className="space-y-2 font-sans">
              {education.map((edu) => (
                <div key={edu.id}>
                  <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                    <span>{edu.institution}</span>
                    <span className="text-[11px] font-normal text-slate-600">
                      {edu.graduationYear} | {edu.location}
                    </span>
                  </div>
                  <div className="text-xs text-slate-800 italic">
                    {edu.degree} {edu.gpaOrHonors && <span className="font-normal not-italic text-slate-700">({edu.gpaOrHonors})</span>}
                  </div>
                  {edu.details && <p className="text-[11.5px] text-slate-600 mt-0.5">{edu.details}</p>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Key Projects */}
        {projects.length > 0 && (
          <div className="mb-4">
            <h2 className="text-xs font-sans font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
              Key Projects & Capstones
            </h2>
            <div className="space-y-2 font-sans">
              {projects.map((proj) => (
                <div key={proj.id}>
                  <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                    <span>
                      {proj.name} {proj.role && <span className="font-normal text-slate-600">({proj.role})</span>}
                    </span>
                    {proj.technologies && (
                      <span className="text-[11px] font-normal italic text-slate-600">
                        {proj.technologies}
                      </span>
                    )}
                  </div>
                  <ul className="list-disc list-outside ml-4 mt-0.5 space-y-0.5 text-[12px] text-slate-800 leading-snug">
                    {proj.bullets.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Skills */}
        <div className="mb-4 font-sans">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-1.5">
            Skills & Competencies
          </h2>
          <div className="space-y-1 text-xs text-slate-800">
            {skills.technical.length > 0 && (
              <p>
                <strong className="text-slate-900">Technical Skills:</strong>{' '}
                {skills.technical.join(', ')}
              </p>
            )}
            {skills.tools.length > 0 && (
              <p>
                <strong className="text-slate-900">Tools & Platforms:</strong>{' '}
                {skills.tools.join(', ')}
              </p>
            )}
            {skills.soft.length > 0 && (
              <p>
                <strong className="text-slate-900">Core Competencies:</strong>{' '}
                {skills.soft.join(', ')}
              </p>
            )}
          </div>
        </div>

        {/* Certifications & Languages */}
        {(certifications.length > 0 || languages.length > 0) && (
          <div className="font-sans text-xs text-slate-800">
            <h2 className="font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-1.5">
              Certifications & Languages
            </h2>
            <div className="flex flex-col sm:flex-row sm:justify-between gap-2">
              {certifications.length > 0 && (
                <div>
                  <strong className="text-slate-900">Certifications:</strong>{' '}
                  {certifications.map((c) => `${c.name} (${c.issuer})`).join(' · ')}
                </div>
              )}
              {languages.length > 0 && (
                <div>
                  <strong className="text-slate-900">Languages:</strong>{' '}
                  {languages.join(', ')}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // Render Template 2: Fresh Graduate & Student Entry-Level (Education & Honors First)
  if (templateId === 'fresh-graduate') {
    return (
      <div className="bg-white text-slate-900 p-8 sm:p-10 font-['Plus_Jakarta_Sans',sans-serif] text-[13px] shadow-sm max-w-[850px] mx-auto min-h-[1050px] print:p-0 print:shadow-none print:max-w-none print:text-[12px]">
        {/* Header with Emerald Accents */}
        <div className="border-b-2 border-emerald-600 pb-4 mb-5">
          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
                {personalInfo.fullName || 'Your Full Name'}
              </h1>
              {personalInfo.title && (
                <p className="text-sm font-semibold text-emerald-700 mt-0.5">
                  {personalInfo.title}
                </p>
              )}
            </div>
            <div className="text-left sm:text-right text-xs text-slate-600 space-y-0.5">
              <div>{personalInfo.email}</div>
              <div>{personalInfo.phone} · {personalInfo.location}</div>
              <div className="text-emerald-700 font-medium">
                {personalInfo.linkedin && <span>{personalInfo.linkedin}</span>}
                {personalInfo.github && <span> · {personalInfo.github}</span>}
              </div>
            </div>
          </div>
        </div>

        {/* Career Objective / Summary */}
        {summary && (
          <div className="mb-5 bg-emerald-50/50 p-3 rounded-md border-l-4 border-emerald-600">
            <h2 className="text-xs font-bold uppercase tracking-wider text-emerald-900 mb-1">
              Career Objective & Graduate Profile
            </h2>
            <p className="text-xs text-slate-700 leading-relaxed">
              {summary}
            </p>
          </div>
        )}

        {/* Education (Prominently Placed at the Top for Students) */}
        {education.length > 0 && (
          <div className="mb-5">
            <h2 className="text-xs font-bold uppercase tracking-wider text-emerald-800 border-b border-emerald-100 pb-1 mb-2.5 flex items-center justify-between">
              <span>Education & Academic Honors</span>
              <span className="text-[10px] font-normal lowercase text-slate-500">Degree & Coursework</span>
            </h2>
            <div className="space-y-3">
              {education.map((edu) => (
                <div key={edu.id} className="bg-slate-50/70 p-2.5 rounded border border-slate-100">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-bold text-xs text-slate-900">{edu.degree}</div>
                      <div className="text-xs text-emerald-800 font-medium">{edu.institution}</div>
                    </div>
                    <div className="text-right text-xs text-slate-500">
                      <div>{edu.graduationYear}</div>
                      <div>{edu.location}</div>
                    </div>
                  </div>
                  {edu.gpaOrHonors && (
                    <div className="mt-1 text-xs font-semibold text-emerald-700">
                      ★ {edu.gpaOrHonors}
                    </div>
                  )}
                  {edu.details && (
                    <div className="text-[11.5px] text-slate-600 mt-1 leading-snug">
                      {edu.details}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Key Projects & Academic Capstones */}
        {projects.length > 0 && (
          <div className="mb-5">
            <h2 className="text-xs font-bold uppercase tracking-wider text-emerald-800 border-b border-emerald-100 pb-1 mb-2.5">
              Academic Projects & Capstones (Final Year Project)
            </h2>
            <div className="space-y-3">
              {projects.map((proj) => (
                <div key={proj.id}>
                  <div className="flex justify-between items-baseline text-xs">
                    <span className="font-bold text-slate-900">
                      {proj.name} {proj.role && <span className="font-medium text-emerald-700">· {proj.role}</span>}
                    </span>
                    {proj.technologies && (
                      <span className="text-[11px] text-slate-500 font-mono">
                        [{proj.technologies}]
                      </span>
                    )}
                  </div>
                  <ul className="list-disc list-outside ml-4 mt-1 space-y-0.5 text-xs text-slate-700 leading-snug">
                    {proj.bullets.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Internships & Work Experience */}
        {experience.length > 0 && (
          <div className="mb-5">
            <h2 className="text-xs font-bold uppercase tracking-wider text-emerald-800 border-b border-emerald-100 pb-1 mb-2.5">
              Internships & Practical Experience
            </h2>
            <div className="space-y-3">
              {experience.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                    <div>
                      <span>{exp.jobTitle}</span>
                      <span className="font-semibold text-emerald-800"> @ {exp.company}</span>
                    </div>
                    <span className="text-[11px] font-normal text-slate-500">
                      {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate} · {exp.location}
                    </span>
                  </div>
                  <ul className="list-disc list-outside ml-4 mt-1 space-y-0.5 text-xs text-slate-700 leading-snug">
                    {exp.bullets.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Skills & Technical Competencies */}
        <div className="mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-emerald-800 border-b border-emerald-100 pb-1 mb-2">
            Technical & Professional Skills
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <div className="bg-slate-50 p-2 rounded">
              <span className="font-bold text-slate-900 block mb-0.5">Core Technical:</span>
              <span className="text-slate-700">{skills.technical.join(', ')}</span>
            </div>
            <div className="bg-slate-50 p-2 rounded">
              <span className="font-bold text-slate-900 block mb-0.5">Tools & Platforms:</span>
              <span className="text-slate-700">{skills.tools.join(', ')}</span>
            </div>
            <div className="bg-slate-50 p-2 rounded">
              <span className="font-bold text-slate-900 block mb-0.5">Interpersonal:</span>
              <span className="text-slate-700">{skills.soft.join(', ')}</span>
            </div>
          </div>
        </div>

        {/* Certifications & Languages */}
        {(certifications.length > 0 || languages.length > 0) && (
          <div className="border-t border-slate-200 pt-2 text-xs text-slate-700 flex flex-col sm:flex-row justify-between gap-2">
            {certifications.length > 0 && (
              <div>
                <strong className="text-slate-900">Certifications:</strong>{' '}
                {certifications.map((c) => `${c.name} (${c.issuer} '${c.year})`).join(' · ')}
              </div>
            )}
            {languages.length > 0 && (
              <div>
                <strong className="text-slate-900">Languages:</strong> {languages.join(' · ')}
              </div>
            )}
          </div>
        )}
      </div>
    );
  }

  // Render Template 3: Silicon Valley Tech (Modern Clean)
  if (templateId === 'silicon-valley') {
    return (
      <div className="bg-white text-slate-900 p-8 sm:p-10 font-['Plus_Jakarta_Sans',sans-serif] text-[13px] shadow-sm max-w-[850px] mx-auto min-h-[1050px] print:p-0 print:shadow-none print:max-w-none print:text-[12px]">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 mb-5">
          <div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900">
              {personalInfo.fullName || 'Your Full Name'}
            </h1>
            <p className="text-sm font-semibold text-teal-700 mt-0.5">
              {personalInfo.title || 'Senior Software Engineer'}
            </p>
          </div>
          <div className="text-xs text-slate-600 sm:text-right mt-2 sm:mt-0 space-y-0.5">
            <div>{personalInfo.email} · {personalInfo.phone}</div>
            <div className="text-slate-500">{personalInfo.location}</div>
            <div className="font-mono text-teal-800 text-[11px]">
              {personalInfo.github && <span>{personalInfo.github} · </span>}
              {personalInfo.linkedin && <span>{personalInfo.linkedin}</span>}
            </div>
          </div>
        </div>

        {/* Summary */}
        {summary && (
          <div className="mb-5">
            <p className="text-xs text-slate-700 leading-relaxed border-l-2 border-teal-600 pl-3">
              {summary}
            </p>
          </div>
        )}

        {/* Technical Stack Matrix */}
        <div className="mb-5 bg-slate-50 p-3 rounded-lg border border-slate-200/80">
          <h2 className="text-[11px] font-mono uppercase tracking-wider font-bold text-slate-800 mb-2">
            Technical Stack & Core Disciplines
          </h2>
          <div className="space-y-1.5 text-xs">
            {skills.technical.length > 0 && (
              <div>
                <span className="font-bold text-slate-900">Languages & Frameworks: </span>
                <span className="text-slate-700">{skills.technical.join(' · ')}</span>
              </div>
            )}
            {skills.tools.length > 0 && (
              <div>
                <span className="font-bold text-slate-900">Cloud & Tooling: </span>
                <span className="text-slate-700">{skills.tools.join(' · ')}</span>
              </div>
            )}
            {skills.soft.length > 0 && (
              <div>
                <span className="font-bold text-slate-900">Engineering Practices: </span>
                <span className="text-slate-700">{skills.soft.join(' · ')}</span>
              </div>
            )}
          </div>
        </div>

        {/* Experience */}
        {experience.length > 0 && (
          <div className="mb-5">
            <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-3">
              Experience & Systems Impact
            </h2>
            <div className="space-y-4">
              {experience.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline text-xs">
                    <div>
                      <span className="font-bold text-slate-900">{exp.jobTitle}</span>
                      <span className="text-teal-700 font-semibold"> @ {exp.company}</span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-500">
                      {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate} | {exp.location}
                    </span>
                  </div>
                  <ul className="list-disc list-outside ml-4 mt-1.5 space-y-1 text-xs text-slate-700 leading-snug">
                    {exp.bullets.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects */}
        {projects.length > 0 && (
          <div className="mb-5">
            <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-3">
              Open Source & Architecture Projects
            </h2>
            <div className="space-y-3">
              {projects.map((proj) => (
                <div key={proj.id}>
                  <div className="flex justify-between items-baseline text-xs">
                    <span className="font-bold text-slate-900">
                      {proj.name} {proj.role && <span className="font-normal text-slate-500">— {proj.role}</span>}
                    </span>
                    {proj.technologies && (
                      <span className="text-[11px] font-mono text-teal-800">
                        {proj.technologies}
                      </span>
                    )}
                  </div>
                  <ul className="list-disc list-outside ml-4 mt-1 space-y-0.5 text-xs text-slate-700 leading-snug">
                    {proj.bullets.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education & Certs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-200 text-xs">
          <div>
            <h3 className="font-mono font-bold uppercase text-[11px] text-slate-900 mb-1.5">Education</h3>
            {education.map((edu) => (
              <div key={edu.id} className="mb-1.5">
                <div className="font-bold text-slate-900">{edu.degree}</div>
                <div className="text-slate-600">{edu.institution}, {edu.graduationYear}</div>
                {edu.gpaOrHonors && <div className="text-teal-700 text-[11px]">{edu.gpaOrHonors}</div>}
              </div>
            ))}
          </div>
          <div>
            <h3 className="font-mono font-bold uppercase text-[11px] text-slate-900 mb-1.5">Certifications & Accreditations</h3>
            {certifications.map((c) => (
              <div key={c.id} className="text-slate-700 mb-1">
                <span className="font-semibold text-slate-900">{c.name}</span> — {c.issuer} ({c.year})
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Render Template 4: Europass / UK Standard (Structured Grid)
  if (templateId === 'europass-minimal') {
    return (
      <div className="bg-white text-slate-900 p-8 sm:p-10 font-sans text-[13px] shadow-sm max-w-[850px] mx-auto min-h-[1050px] print:p-0 print:shadow-none print:max-w-none print:text-[12px]">
        {/* Header */}
        <div className="border-b-2 border-slate-800 pb-3 mb-5">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
                {personalInfo.fullName || 'Your Full Name'}
              </h1>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-600 mt-1">
                {personalInfo.title}
              </p>
            </div>
            <div className="text-xs text-slate-600 sm:text-right mt-2 sm:mt-0">
              <div>{personalInfo.email} · {personalInfo.phone}</div>
              <div>{personalInfo.location}</div>
              <div className="text-slate-700 font-medium">{personalInfo.linkedin}</div>
            </div>
          </div>
        </div>

        {/* Summary */}
        {summary && (
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-4 pb-4 border-b border-slate-200">
            <div className="sm:col-span-1 text-xs font-bold uppercase text-slate-700 tracking-wider">
              Profile
            </div>
            <div className="sm:col-span-3 text-xs text-slate-800 leading-relaxed text-justify">
              {summary}
            </div>
          </div>
        )}

        {/* Experience */}
        {experience.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-4 pb-4 border-b border-slate-200">
            <div className="sm:col-span-1 text-xs font-bold uppercase text-slate-700 tracking-wider">
              Work Experience
            </div>
            <div className="sm:col-span-3 space-y-4">
              {experience.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                    <span>{exp.jobTitle} — {exp.company}</span>
                    <span className="font-normal text-slate-500 text-[11px]">
                      {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-600 mb-1">{exp.location}</div>
                  <ul className="list-disc list-outside ml-4 space-y-1 text-xs text-slate-800 leading-snug">
                    {exp.bullets.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education */}
        {education.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-4 pb-4 border-b border-slate-200">
            <div className="sm:col-span-1 text-xs font-bold uppercase text-slate-700 tracking-wider">
              Education & Training
            </div>
            <div className="sm:col-span-3 space-y-2">
              {education.map((edu) => (
                <div key={edu.id}>
                  <div className="flex justify-between text-xs font-bold text-slate-900">
                    <span>{edu.degree}</span>
                    <span className="font-normal text-slate-500 text-[11px]">{edu.graduationYear}</span>
                  </div>
                  <div className="text-xs text-slate-700">{edu.institution}, {edu.location}</div>
                  {edu.gpaOrHonors && <div className="text-[11px] text-slate-600">{edu.gpaOrHonors}</div>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Skills */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-4">
          <div className="sm:col-span-1 text-xs font-bold uppercase text-slate-700 tracking-wider">
            Competencies & Skills
          </div>
          <div className="sm:col-span-3 space-y-1.5 text-xs text-slate-800">
            <div>
              <strong className="text-slate-900">Technical Stack:</strong> {skills.technical.join(', ')}
            </div>
            <div>
              <strong className="text-slate-900">Software & Tools:</strong> {skills.tools.join(', ')}
            </div>
            <div>
              <strong className="text-slate-900">Languages:</strong> {languages.join(' · ')}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Render Template 5: Executive & Leadership
  return (
    <div className="bg-white text-slate-900 p-8 sm:p-10 font-['Plus_Jakarta_Sans',sans-serif] text-[13px] shadow-sm max-w-[850px] mx-auto min-h-[1050px] print:p-0 print:shadow-none print:max-w-none print:text-[12px]">
      {/* Executive Dark Slate Banner Header */}
      <div className="bg-slate-900 text-white p-5 rounded-md mb-5">
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          {personalInfo.fullName || 'Your Full Name'}
        </h1>
        <p className="text-sm font-medium text-emerald-400 mt-0.5 tracking-wide">
          {personalInfo.title}
        </p>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-300 mt-2 font-mono">
          <span>{personalInfo.email}</span>
          <span>·</span>
          <span>{personalInfo.phone}</span>
          <span>·</span>
          <span>{personalInfo.location}</span>
          {personalInfo.linkedin && (
            <>
              <span>·</span>
              <span>{personalInfo.linkedin}</span>
            </>
          )}
        </div>
      </div>

      {/* Executive Summary */}
      {summary && (
        <div className="mb-5">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b-2 border-slate-900 pb-1 mb-2">
            Executive Profile & Strategic Leadership
          </h2>
          <p className="text-xs text-slate-700 leading-relaxed text-justify">
            {summary}
          </p>
        </div>
      )}

      {/* Core Competencies 3-Column Grid */}
      <div className="mb-5 bg-slate-50 p-3 rounded border border-slate-200">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-2">
          Core Competencies & Domain Expertise
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs text-slate-800">
          {skills.technical.slice(0, 6).map((s, idx) => (
            <div key={idx} className="flex items-center gap-1.5 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
              <span>{s}</span>
            </div>
          ))}
          {skills.soft.slice(0, 6).map((s, idx) => (
            <div key={idx} className="flex items-center gap-1.5 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-600"></span>
              <span>{s}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Leadership Experience */}
      {experience.length > 0 && (
        <div className="mb-5">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b-2 border-slate-900 pb-1 mb-3">
            Career History & Operational Milestones
          </h2>
          <div className="space-y-4">
            {experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                  <div>
                    <span className="text-sm">{exp.jobTitle}</span>
                    <span className="font-semibold text-emerald-800"> — {exp.company}</span>
                  </div>
                  <span className="text-xs font-normal text-slate-500">
                    {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate} | {exp.location}
                  </span>
                </div>
                <ul className="list-disc list-outside ml-4 mt-1.5 space-y-1 text-xs text-slate-700 leading-snug">
                  {exp.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education & Credentials */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-200 pt-3 text-xs">
        <div>
          <h3 className="font-bold uppercase tracking-wider text-slate-900 mb-1">Education</h3>
          {education.map((edu) => (
            <div key={edu.id} className="text-slate-700">
              <div className="font-bold text-slate-900">{edu.degree}</div>
              <div>{edu.institution}, {edu.graduationYear}</div>
            </div>
          ))}
        </div>
        <div>
          <h3 className="font-bold uppercase tracking-wider text-slate-900 mb-1">Executive Credentials & Certifications</h3>
          {certifications.map((c) => (
            <div key={c.id} className="text-slate-700">
              <span className="font-semibold text-slate-900">{c.name}</span> — {c.issuer}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Render Template 6: Nordic Modern Minimalist
  if (templateId === 'modern-minimalist') {
    return (
      <div className="bg-white text-slate-900 p-8 sm:p-10 font-['Plus_Jakarta_Sans',sans-serif] text-[13px] shadow-sm max-w-[850px] mx-auto min-h-[1050px] print:p-0 print:shadow-none print:max-w-none print:text-[12px]">
        {/* Header */}
        <div className="pb-4 mb-4 border-b-2 border-sky-600">
          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
                {personalInfo.fullName || 'Your Full Name'}
              </h1>
              <p className="text-xs font-semibold tracking-wider uppercase text-sky-700 mt-0.5">
                {personalInfo.title}
              </p>
            </div>
            <div className="text-xs text-slate-600 sm:text-right space-y-0.5">
              <div>{personalInfo.email} · {personalInfo.phone}</div>
              <div>{personalInfo.location} · {personalInfo.linkedin}</div>
              {personalInfo.github && <div className="text-sky-800">{personalInfo.github}</div>}
            </div>
          </div>
        </div>

        {/* Summary */}
        {summary && (
          <div className="mb-4">
            <p className="text-xs text-slate-700 leading-relaxed text-justify">
              {summary}
            </p>
          </div>
        )}

        {/* Experience */}
        {experience.length > 0 && (
          <div className="mb-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-sky-900 border-b border-sky-200 pb-1 mb-2">
              Work Experience & Impact
            </h2>
            <div className="space-y-3">
              {experience.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                    <div>
                      <span>{exp.jobTitle}</span>
                      <span className="font-semibold text-sky-800"> — {exp.company}</span>
                    </div>
                    <span className="text-[11px] font-normal text-slate-500">
                      {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate} | {exp.location}
                    </span>
                  </div>
                  <ul className="list-disc list-outside ml-4 mt-1 space-y-1 text-xs text-slate-700 leading-snug">
                    {exp.bullets.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects */}
        {projects.length > 0 && (
          <div className="mb-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-sky-900 border-b border-sky-200 pb-1 mb-2">
              Projects & Engineering Deliverables
            </h2>
            <div className="space-y-2">
              {projects.map((proj) => (
                <div key={proj.id}>
                  <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                    <span>
                      {proj.name} {proj.role && <span className="font-normal text-slate-600">({proj.role})</span>}
                    </span>
                    {proj.technologies && (
                      <span className="text-[11px] font-mono font-normal text-sky-800">
                        {proj.technologies}
                      </span>
                    )}
                  </div>
                  <ul className="list-disc list-outside ml-4 mt-0.5 space-y-0.5 text-xs text-slate-700 leading-snug">
                    {proj.bullets.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education & Skills */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-200 text-xs">
          <div>
            <h3 className="font-bold uppercase tracking-wider text-sky-900 mb-1.5">Education</h3>
            {education.map((edu) => (
              <div key={edu.id} className="mb-1">
                <div className="font-bold text-slate-900">{edu.degree}</div>
                <div className="text-slate-600">{edu.institution}, {edu.graduationYear}</div>
                {edu.gpaOrHonors && <div className="text-sky-800 text-[11px] font-medium">{edu.gpaOrHonors}</div>}
              </div>
            ))}
          </div>

          <div>
            <h3 className="font-bold uppercase tracking-wider text-sky-900 mb-1.5">Competencies</h3>
            <div className="space-y-1 text-slate-700">
              <div><strong className="text-slate-900">Technical:</strong> {skills.technical.join(', ')}</div>
              <div><strong className="text-slate-900">Tools:</strong> {skills.tools.join(', ')}</div>
              <div><strong className="text-slate-900">Languages:</strong> {languages.join(' · ')}</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Render Template 7: Creative & Brand Showcase (Dual Panel)
  if (templateId === 'creative-portfolio') {
    return (
      <div className="bg-white text-slate-900 font-['Plus_Jakarta_Sans',sans-serif] text-[12.5px] shadow-sm max-w-[850px] mx-auto min-h-[1050px] grid grid-cols-1 sm:grid-cols-12 print:shadow-none print:max-w-none print:text-[11.5px]">
        {/* Left Accent Sidebar */}
        <div className="sm:col-span-4 bg-slate-900 text-slate-100 p-6 space-y-5">
          <div>
            <h1 className="text-xl font-black tracking-tight text-white uppercase">
              {personalInfo.fullName || 'Your Full Name'}
            </h1>
            <p className="text-xs font-semibold text-purple-400 mt-1">
              {personalInfo.title}
            </p>
          </div>

          <div className="space-y-1.5 text-xs text-slate-300 border-t border-slate-800 pt-3">
            <div className="font-bold uppercase text-[10px] tracking-wider text-slate-400 mb-1">Contact</div>
            <div>{personalInfo.email}</div>
            <div>{personalInfo.phone}</div>
            <div>{personalInfo.location}</div>
            {personalInfo.linkedin && <div className="text-purple-300 truncate">{personalInfo.linkedin}</div>}
            {personalInfo.github && <div className="text-purple-300 truncate">{personalInfo.github}</div>}
            {personalInfo.portfolio && <div className="text-purple-300 truncate">{personalInfo.portfolio}</div>}
          </div>

          {/* Core Tools & Stack */}
          <div className="space-y-2 border-t border-slate-800 pt-3 text-xs">
            <div className="font-bold uppercase text-[10px] tracking-wider text-slate-400">Core Tools</div>
            <div className="flex flex-wrap gap-1">
              {skills.tools.map((tool, idx) => (
                <span key={idx} className="bg-slate-800 text-purple-200 px-2 py-0.5 rounded text-[11px]">
                  {tool}
                </span>
              ))}
            </div>
          </div>

          {/* Technical Skills */}
          <div className="space-y-2 border-t border-slate-800 pt-3 text-xs">
            <div className="font-bold uppercase text-[10px] tracking-wider text-slate-400">Expertise</div>
            <ul className="space-y-1 text-slate-300">
              {skills.technical.map((tech, idx) => (
                <li key={idx} className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span>
                  <span>{tech}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Languages */}
          {languages.length > 0 && (
            <div className="space-y-1 border-t border-slate-800 pt-3 text-xs">
              <div className="font-bold uppercase text-[10px] tracking-wider text-slate-400 mb-1">Languages</div>
              <div className="text-slate-300">{languages.join(', ')}</div>
            </div>
          )}
        </div>

        {/* Right Main Body */}
        <div className="sm:col-span-8 p-6 sm:p-8 space-y-4">
          {summary && (
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-purple-900 border-b border-purple-200 pb-1 mb-2">
                Executive Profile
              </h2>
              <p className="text-xs text-slate-700 leading-relaxed text-justify">
                {summary}
              </p>
            </div>
          )}

          {experience.length > 0 && (
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-purple-900 border-b border-purple-200 pb-1 mb-2">
                Work Experience & Campaigns
              </h2>
              <div className="space-y-3">
                {experience.map((exp) => (
                  <div key={exp.id}>
                    <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                      <span>{exp.jobTitle} — <span className="text-purple-800">{exp.company}</span></span>
                      <span className="text-[11px] font-normal text-slate-500">
                        {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate}
                      </span>
                    </div>
                    <ul className="list-disc list-outside ml-4 mt-1 space-y-0.5 text-xs text-slate-700 leading-snug">
                      {exp.bullets.map((b, idx) => (
                        <li key={idx}>{b}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          )}

          {projects.length > 0 && (
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-purple-900 border-b border-purple-200 pb-1 mb-2">
                Portfolio & Strategic Projects
              </h2>
              <div className="space-y-2">
                {projects.map((proj) => (
                  <div key={proj.id}>
                    <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                      <span>{proj.name} {proj.role && <span className="font-normal text-slate-500">({proj.role})</span>}</span>
                      {proj.technologies && <span className="text-[11px] text-purple-700">{proj.technologies}</span>}
                    </div>
                    <ul className="list-disc list-outside ml-4 mt-0.5 space-y-0.5 text-xs text-slate-700 leading-snug">
                      {proj.bullets.map((b, idx) => (
                        <li key={idx}>{b}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          )}

          {education.length > 0 && (
            <div className="pt-2 border-t border-slate-200">
              <h2 className="text-xs font-bold uppercase tracking-wider text-purple-900 mb-1.5">
                Education & Credentials
              </h2>
              {education.map((edu) => (
                <div key={edu.id} className="text-xs text-slate-700 mb-1">
                  <div className="font-bold text-slate-900">{edu.degree}</div>
                  <div>{edu.institution}, {edu.graduationYear} {edu.gpaOrHonors && `(${edu.gpaOrHonors})`}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Render Template 8: Academic & Scholar CV (Higher Studies & Research)
  return (
    <div className="bg-white text-slate-900 p-8 sm:p-10 font-serif leading-relaxed text-[13px] shadow-sm max-w-[850px] mx-auto min-h-[1050px] print:p-0 print:shadow-none print:max-w-none print:text-[12px]">
      {/* Header */}
      <div className="text-center border-b border-slate-400 pb-3 mb-4">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-normal uppercase text-slate-900 font-serif">
          {personalInfo.fullName || 'Your Full Name'}
        </h1>
        <p className="text-xs font-sans tracking-wide text-amber-900 font-semibold uppercase mt-0.5">
          Academic Curriculum Vitae · {personalInfo.title}
        </p>
        <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-xs font-sans text-slate-700 mt-2">
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.phone && <span>· {personalInfo.phone}</span>}
          {personalInfo.location && <span>· {personalInfo.location}</span>}
          {personalInfo.linkedin && <span>· {personalInfo.linkedin}</span>}
          {personalInfo.github && <span>· {personalInfo.github}</span>}
        </div>
      </div>

      {/* Research Statement / Academic Profile */}
      {summary && (
        <div className="mb-4">
          <h2 className="text-xs font-sans font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-1.5">
            Research Statement & Academic Interests
          </h2>
          <p className="font-sans text-xs text-slate-800 text-justify leading-relaxed">
            {summary}
          </p>
        </div>
      )}

      {/* Education & Academic Honors */}
      {education.length > 0 && (
        <div className="mb-4">
          <h2 className="text-xs font-sans font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
            Education
          </h2>
          <div className="space-y-2.5 font-sans">
            {education.map((edu) => (
              <div key={edu.id}>
                <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                  <span>{edu.degree}</span>
                  <span className="font-normal text-slate-600 text-[11px]">{edu.graduationYear}</span>
                </div>
                <div className="text-xs text-slate-800 italic">
                  {edu.institution}, {edu.location}
                </div>
                {edu.gpaOrHonors && (
                  <div className="text-xs text-amber-900 font-medium mt-0.5">
                    Honors: {edu.gpaOrHonors}
                  </div>
                )}
                {edu.details && <p className="text-[11.5px] text-slate-600 mt-0.5">{edu.details}</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Research Projects & Capstones */}
      {projects.length > 0 && (
        <div className="mb-4">
          <h2 className="text-xs font-sans font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
            Research Projects, Thesis & Publications
          </h2>
          <div className="space-y-2.5 font-sans">
            {projects.map((proj) => (
              <div key={proj.id}>
                <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                  <span>
                    {proj.name} {proj.role && <span className="font-normal text-slate-600">[{proj.role}]</span>}
                  </span>
                  {proj.technologies && (
                    <span className="text-[11px] italic font-normal text-slate-600">
                      {proj.technologies}
                    </span>
                  )}
                </div>
                <ul className="list-disc list-outside ml-4 mt-0.5 space-y-0.5 text-xs text-slate-800 leading-snug">
                  {proj.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Teaching & Practical Experience */}
      {experience.length > 0 && (
        <div className="mb-4">
          <h2 className="text-xs font-sans font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 mb-2">
            Teaching & Professional Experience
          </h2>
          <div className="space-y-2.5 font-sans">
            {experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-baseline text-xs font-bold text-slate-900">
                  <span>{exp.jobTitle} — {exp.company}</span>
                  <span className="text-[11px] font-normal text-slate-600">
                    {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate}
                  </span>
                </div>
                <ul className="list-disc list-outside ml-4 mt-0.5 space-y-0.5 text-xs text-slate-800 leading-snug">
                  {exp.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills & Certifications */}
      <div className="font-sans text-xs pt-1 border-t border-slate-300">
        <h2 className="font-bold uppercase tracking-wider text-slate-900 mb-1">
          Technical Skills & Accreditations
        </h2>
        <p className="text-slate-800 leading-relaxed">
          <strong className="text-slate-900">Methodologies & Languages:</strong> {skills.technical.join(', ')} ·{' '}
          <strong className="text-slate-900">Tools:</strong> {skills.tools.join(', ')} ·{' '}
          <strong className="text-slate-900">Languages:</strong> {languages.join(' · ')}
        </p>
      </div>
    </div>
  );
};
