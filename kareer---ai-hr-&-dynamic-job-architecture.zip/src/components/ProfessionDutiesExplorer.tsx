import React, { useState } from 'react';
import { PROFESSIONS_DATA } from '../data/professionDutiesData';
import { ProfessionDutyData, TransferableSkillItem } from '../types';
import {
  Search,
  BookOpen,
  CheckCircle,
  Copy,
  Plus,
  ExternalLink,
  Briefcase,
  AlertTriangle,
  Award,
  TrendingUp,
  Target,
  DollarSign,
  Layers,
  Sparkles,
  ChevronRight,
  ShieldAlert,
  GraduationCap,
  Scale,
  RefreshCw,
  Compass,
  FileText,
  Building2
} from 'lucide-react';

interface ProfessionDutiesExplorerProps {
  onInsertIntoResume?: (duties: string[], roleTitle: string) => void;
  onArchitectRole?: (roleTitle: string, industry: string) => void;
  onExplorePakJobs?: (searchQuery: string) => void;
}

export const ProfessionDutiesExplorer: React.FC<ProfessionDutiesExplorerProps> = ({
  onInsertIntoResume,
  onArchitectRole,
  onExplorePakJobs,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedRole, setSelectedRole] = useState<ProfessionDutyData>(PROFESSIONS_DATA[0]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [copiedTransferableIndex, setCopiedTransferableIndex] = useState<number | null>(null);
  const [copiedAll, setCopiedAll] = useState<boolean>(false);
  const [insertedToResumeMessage, setInsertedToResumeMessage] = useState<string | null>(null);

  const categories = [
    'All',
    'Multinationals & Corporate Leadership',
    'Human Resources & Corporate Strategy',
    'Software & Technology',
    'Data & Analytics',
    'Finance & Banking',
    'Supply Chain & Manufacturing',
    'Operations & Project Management',
    'Design & Product',
    'Marketing & Commercial Strategy',
    'Sales & Business Development',
  ];

  const filteredRoles = PROFESSIONS_DATA.filter((role) => {
    const matchesCategory =
      selectedCategory === 'All' || role.category === selectedCategory;
    const matchesSearch =
      role.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      role.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      role.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      role.employerLookingFor.mustHaveHardSkills.some((s) =>
        s.toLowerCase().includes(searchQuery.toLowerCase())
      ) ||
      role.transferableSkills?.some((t) =>
        t.skill.toLowerCase().includes(searchQuery.toLowerCase())
      );
    return matchesCategory && matchesSearch;
  });

  const handleCopySingle = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleCopyTransferable = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedTransferableIndex(index);
    setTimeout(() => setCopiedTransferableIndex(null), 2000);
  };

  const handleCopyAll = () => {
    const all = selectedRole.primaryResponsibilities.map((b) => `• ${b}`).join('\n');
    navigator.clipboard.writeText(all);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  const handleSendToResume = () => {
    if (onInsertIntoResume) {
      onInsertIntoResume(selectedRole.primaryResponsibilities, selectedRole.title);
      setInsertedToResumeMessage(`Added ${selectedRole.primaryResponsibilities.length} duties to your Resume Builder!`);
      setTimeout(() => setInsertedToResumeMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Profession Competency & Duties Matrix
              </span>
              <span className="text-xs text-slate-500">· Comprehensive National & Global Intelligence</span>
            </div>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
              Professions, Tasks & Employer Wishlists
            </h1>
            <p className="text-xs text-slate-600 mt-1 max-w-3xl leading-relaxed">
              Explore exact duties, daily tasks, <strong>Occupational Requirements</strong> (education, work environments, compliance standards), and <strong>Transferable Skills</strong> across Pakistani corporate and global remote careers. Pre-vetted with Google's XYZ formula.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {onExplorePakJobs && (
              <button
                onClick={() => onExplorePakJobs(selectedRole.title)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-semibold transition-colors"
              >
                <Briefcase className="w-3.5 h-3.5" />
                <span>Search Pakistani Jobs for this Role</span>
              </button>
            )}

            {onArchitectRole && (
              <button
                onClick={() => onArchitectRole(selectedRole.title, selectedRole.category)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>Architect Role with Haseeb</span>
              </button>
            )}
          </div>
        </div>

        {/* Filter Categories Bar */}
        <div className="mt-5 pt-4 border-t border-slate-200 flex flex-wrap items-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-xs font-bold'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Left Sidebar Selector & Right Dossier View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Profession Selector List */}
        <div className="lg:col-span-4 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, skill, or keyword..."
              className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="space-y-2 max-h-[750px] overflow-y-auto pr-1">
            {filteredRoles.map((role) => {
              const isSelected = selectedRole.id === role.id;
              return (
                <div
                  key={role.id}
                  onClick={() => setSelectedRole(role)}
                  className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                    isSelected
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                      {role.category}
                    </span>
                    {role.badge && (
                      <span className="text-[10px] font-semibold text-slate-500">
                        ★
                      </span>
                    )}
                  </div>
                  <h3 className="text-xs font-bold text-slate-900 mt-1 line-clamp-1">
                    {role.title}
                  </h3>
                  <p className="text-[11px] text-slate-500 line-clamp-2 mt-1 leading-snug">
                    {role.summary}
                  </p>
                  <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-100 pt-1.5">
                    <span>{role.primaryResponsibilities.length} Accomplishment Bullets</span>
                    <span className="text-emerald-700 font-bold">{role.averageSalary.pakistanPKR.split('(')[0]}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredRoles.length === 0 && (
            <div className="p-8 text-center bg-white rounded-xl border border-slate-200 text-xs text-slate-500">
              No matching professions found for "{searchQuery}". Try another keyword.
            </div>
          )}
        </div>

        {/* Right Column: Deep-Dive Profession Intelligence Dossier */}
        <div className="lg:col-span-8 space-y-5">
          {/* Role Master Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {selectedRole.category}
                  </span>
                  {selectedRole.badge && (
                    <span className="text-[11px] font-semibold text-slate-700">
                      ★ {selectedRole.badge}
                    </span>
                  )}
                </div>
                <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1.5">
                  {selectedRole.title}
                </h2>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleSendToResume}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add to My Resume Builder</span>
                </button>
                <button
                  onClick={handleCopyAll}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedAll ? 'All Copied!' : 'Copy All Bullets'}</span>
                </button>
              </div>
            </div>

            {insertedToResumeMessage && (
              <div className="p-3 bg-emerald-100/70 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-semibold flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>{insertedToResumeMessage}</span>
              </div>
            )}

            {/* Strategic Summary */}
            <div>
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1.5">
                Official Strategic Role Purpose
              </h4>
              <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                {selectedRole.summary}
              </p>
            </div>

            {/* Compensation Benchmark Box */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 bg-emerald-50/50 rounded-xl border border-emerald-200">
              <div>
                <span className="text-[11px] font-bold text-emerald-900 block mb-0.5">
                  🇵🇰 Pakistan Local Compensation (PKR):
                </span>
                <span className="text-xs font-bold text-slate-900">
                  {selectedRole.averageSalary.pakistanPKR}
                </span>
              </div>
              <div>
                <span className="text-[11px] font-bold text-emerald-900 block mb-0.5">
                  🌐 Global Remote Equivalent (USD):
                </span>
                <span className="text-xs font-bold text-slate-900">
                  {selectedRole.averageSalary.globalUSD}
                </span>
              </div>
            </div>

            {/* OCCUPATIONAL REQUIREMENTS SECTION */}
            {selectedRole.occupationalRequirements && (
              <div className="pt-4 border-t border-slate-200 space-y-3.5">
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-emerald-700" />
                  <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                    Occupational Requirements & Professional Environment
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  {/* Minimum Education */}
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <span className="font-bold text-slate-900 block text-[11px] uppercase tracking-wider text-emerald-800">
                      Formal Education & Accreditations:
                    </span>
                    <ul className="space-y-1 text-slate-700">
                      {selectedRole.occupationalRequirements.minimumEducation.map((edu, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{edu}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Experience Prerequisites */}
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <span className="font-bold text-slate-900 block text-[11px] uppercase tracking-wider text-emerald-800">
                      Experience & Prerequisites:
                    </span>
                    <ul className="space-y-1 text-slate-700">
                      {selectedRole.occupationalRequirements.experiencePrerequisites.map((exp, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <CheckCircle className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                          <span>{exp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Regulatory & Compliance Standards */}
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <span className="font-bold text-slate-900 block text-[11px] uppercase tracking-wider text-emerald-800">
                      Regulatory & Compliance Statutes:
                    </span>
                    <ul className="space-y-1 text-slate-700">
                      {selectedRole.occupationalRequirements.regulatoryAndComplianceStandards.map((reg, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <Scale className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                          <span>{reg}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Cognitive & Physical Demands */}
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <span className="font-bold text-slate-900 block text-[11px] uppercase tracking-wider text-emerald-800">
                      Cognitive & Physical Demands:
                    </span>
                    <ul className="space-y-1 text-slate-700">
                      {selectedRole.occupationalRequirements.cognitiveAndPhysicalDemands.map((cog, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                          <span>{cog}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Work Environment Context */}
                <div className="p-3.5 rounded-xl bg-slate-100/70 border border-slate-200 text-xs text-slate-700 leading-relaxed">
                  <strong className="text-slate-900">Workplace Context: </strong>
                  {selectedRole.occupationalRequirements.workEnvironmentContext}
                </div>
              </div>
            )}

            {/* TRANSFERABLE SKILLS SHOWCASE */}
            {selectedRole.transferableSkills && selectedRole.transferableSkills.length > 0 && (
              <div className="pt-4 border-t border-slate-200 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-emerald-700" />
                    <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                      Transferable Skills (Carry Across Any Industry)
                    </h3>
                  </div>
                  <span className="text-[11px] text-slate-500 hidden sm:inline">
                    High-value competencies that transcend job titles
                  </span>
                </div>

                <div className="space-y-3">
                  {selectedRole.transferableSkills.map((trans, tIdx) => (
                    <div
                      key={tIdx}
                      className="p-4 rounded-xl border border-slate-200 bg-white hover:border-emerald-300 transition-all space-y-2 text-xs"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="font-extrabold text-slate-900 text-xs sm:text-sm">
                            {trans.skill}
                          </span>
                          <p className="text-slate-600 mt-0.5 leading-relaxed">
                            {trans.description}
                          </p>
                        </div>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 shrink-0">
                          Transferable
                        </span>
                      </div>

                      <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/80 text-[11.5px] space-y-1">
                        <div>
                          <strong className="text-slate-900">Cross-Industry Value: </strong>
                          <span className="text-slate-600">{trans.crossIndustryApplication}</span>
                        </div>
                        <div className="pt-1 border-t border-slate-200/60 flex items-start justify-between gap-2">
                          <div>
                            <strong className="text-emerald-900">How to write this on your resume (XYZ): </strong>
                            <span className="text-slate-800 italic font-mono text-[11px]">
                              "{trans.howToDemonstrateInResume}"
                            </span>
                          </div>
                          <button
                            onClick={() => handleCopyTransferable(trans.howToDemonstrateInResume, tIdx)}
                            className="text-slate-400 hover:text-emerald-700 p-1 rounded hover:bg-slate-200 transition-colors shrink-0"
                            title="Copy XYZ bullet"
                          >
                            {copiedTransferableIndex === tIdx ? (
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Task & Responsibilities Section (XYZ Formula) */}
            <div className="pt-4 border-t border-slate-200">
              <div className="flex items-center justify-between mb-2.5">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Core Accomplishment Responsibilities (Google XYZ Formula)
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Ready-to-use bullet points with action verbs, context, and quantified impact.
                  </p>
                </div>
              </div>

              <div className="space-y-2.5">
                {selectedRole.primaryResponsibilities.map((duty, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-emerald-300 transition-all flex items-start justify-between gap-3 text-xs leading-relaxed text-slate-800"
                  >
                    <div className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span>{duty}</span>
                    </div>
                    <button
                      onClick={() => handleCopySingle(duty, idx)}
                      className="text-slate-400 hover:text-emerald-700 p-1.5 rounded hover:bg-slate-100 transition-colors shrink-0"
                      title="Copy bullet"
                    >
                      {copiedIndex === idx ? (
                        <CheckCircle className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Daily Operational Tasks */}
            <div>
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                Typical Daily Operational Tasks & Routine
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-700 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                {selectedRole.dailyTasks.map((t, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-emerald-600 font-bold">•</span>
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* What Employers Are REALLY Looking For (The Employer Wishlist) */}
            <div className="pt-4 border-t border-slate-200 space-y-4">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-emerald-700" />
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                  What Employers Are REALLY Looking For (Hiring Rubric)
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Must-Have Hard Skills */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <span className="text-xs font-bold text-slate-900 block">
                    Must-Have Hard Skills & Tools:
                  </span>
                  <ul className="space-y-1 text-xs text-slate-700">
                    {selectedRole.employerLookingFor.mustHaveHardSkills.map((s, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Essential Soft Skills */}
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <span className="text-xs font-bold text-slate-900 block">
                    Essential Interpersonal Attributes:
                  </span>
                  <ul className="space-y-1 text-xs text-slate-700">
                    {selectedRole.employerLookingFor.essentialSoftSkills.map((s, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <CheckCircle className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Red Flags & Dealbreakers */}
              <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2">
                <div className="flex items-center gap-1.5 text-amber-900 font-bold text-xs">
                  <AlertTriangle className="w-4 h-4 text-amber-700" />
                  <span>Interview Dealbreakers & Common Candidate Red Flags:</span>
                </div>
                <ul className="space-y-1 text-xs text-amber-900/90 ml-1">
                  {selectedRole.employerLookingFor.redFlagsAndDealbreakers.map((rf, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-amber-700 font-bold">✕</span>
                      <span>{rf}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Typical Interview Case Focus */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs">
                <span className="font-bold text-slate-900 block">
                  Typical Interview Focus & Case Scenarios:
                </span>
                <ul className="space-y-1 text-slate-700">
                  {selectedRole.employerLookingFor.typicalInterviewFocus.map((q, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-slate-400 font-bold">Q:</span>
                      <span className="italic">{q}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Key Performance Indicators (KPIs) & Career Ladder */}
            <div className="pt-4 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <span className="font-bold text-slate-900 block mb-1.5 uppercase tracking-wider text-[11px]">
                  Job Success KPIs & Metrics:
                </span>
                <ul className="space-y-1 text-slate-700">
                  {selectedRole.keyPerformanceIndicators.map((kpi, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <TrendingUp className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{kpi}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="font-bold text-slate-900 block mb-1.5 uppercase tracking-wider text-[11px]">
                  Career Progression Ladder:
                </span>
                <div className="space-y-1 text-slate-700">
                  {selectedRole.careerProgression.map((step, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recommended Certifications */}
            <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div>
                <span className="font-bold text-slate-900">Recommended Certifications: </span>
                <span className="text-slate-600">
                  {selectedRole.recommendedCertifications.join(' · ')}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
