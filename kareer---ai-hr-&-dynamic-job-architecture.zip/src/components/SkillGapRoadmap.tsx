import React, { useState } from 'react';
import { SkillGapResult } from '../types';
import {
  Compass,
  Sparkles,
  BookOpen,
  Calendar,
  CheckCircle,
  Clock,
  ArrowRight,
  RefreshCw,
  Trophy,
  ExternalLink,
  Target,
  Zap,
  ListChecks
} from 'lucide-react';

export const SkillGapRoadmap: React.FC = () => {
  const [targetRole, setTargetRole] = useState('Nestlé Pakistan - Management Trainee Officer (Supply Chain & Digital)');
  const [currentSkills, setCurrentSkills] = useState(
    'University Student / BBA final year. Basic Excel modeling, marketing course projects, university society leadership, communication skills.'
  );
  const [experienceYears, setExperienceYears] = useState('1');
  const [targetTimeline, setTargetTimeline] = useState('3 months (90 Days)');

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SkillGapResult | null>(null);
  const [completedMilestones, setCompletedMilestones] = useState<Record<string, boolean>>({});

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!targetRole.trim()) return;

    setLoading(true);
    try {
      const res = await fetch('/api/skill-gap-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetRole,
          currentSkills,
          experienceYears,
          targetTimeline,
        }),
      });
      const data = await res.json();
      setResult(data);
    } catch (err) {
      console.error('Failed to generate skill gap roadmap', err);
    } finally {
      setLoading(false);
    }
  };

  // Run on mount once
  React.useEffect(() => {
    if (!result) {
      handleGenerate();
    }
  }, []);

  const toggleMilestone = (id: string) => {
    setCompletedMilestones((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const calculateCompletionStats = () => {
    if (!result) return { total: 0, done: 0, percent: 0 };
    const allMilestones = [
      ...result.roadmap.phase1_30Days.milestones,
      ...result.roadmap.phase2_60Days.milestones,
      ...result.roadmap.phase3_90Days.milestones,
    ];
    const total = allMilestones.length;
    const done = allMilestones.filter((m) => completedMilestones[m]).length;
    const percent = total > 0 ? Math.round((done / total) * 100) : 0;
    return { total, done, percent };
  };

  const stats = calculateCompletionStats();

  return (
    <div className="space-y-8">
      {/* Intro Mission Banner - Light Theme */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs">
        <div className="max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-800 text-xs font-semibold">
            <Compass className="w-3.5 h-3.5 text-blue-600" />
            <span>Targeted Upskilling & Phased Execution</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Skill Gap Diagnosis & 30-60-90 Day Roadmap
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Students and job seekers frequently ask: <em>"How do I qualify for Nestlé, PepsiCo, Systems Limited, or Global Remote roles?"</em> Haseeb diagnoses your exact competency differential and architects a 30-60-90 day learning roadmap with verified courses, interview prep, and hands-on capstones.
          </p>
        </div>
      </div>

      {/* Main Grid: Form on Left, Roadmap on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Column (4 cols) */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4 shadow-sm">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Target className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Upskilling Parameters</h2>
          </div>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Target Destination Role</label>
              <input
                type="text"
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
                placeholder="e.g. Nestlé MTO, Remote React Engineer"
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Current Skills & Educational Background
              </label>
              <textarea
                value={currentSkills}
                onChange={(e) => setCurrentSkills(e.target.value)}
                rows={4}
                placeholder="List your university degree, tools, languages, or existing experience..."
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl p-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-none resize-none leading-relaxed"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Experience</label>
                <select
                  value={experienceYears}
                  onChange={(e) => setExperienceYears(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-2.5 py-2 text-xs text-slate-900 focus:outline-none"
                >
                  <option value="0">Student (0 yrs)</option>
                  <option value="1">Fresh Grad (1 yr)</option>
                  <option value="3">2-4 Years</option>
                  <option value="6">5+ Years</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Target Pace</label>
                <select
                  value={targetTimeline}
                  onChange={(e) => setTargetTimeline(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-2.5 py-2 text-xs text-slate-900 focus:outline-none"
                >
                  <option value="1 month">Aggressive (30 Days)</option>
                  <option value="3 months (90 Days)">Standard (90 Days)</option>
                  <option value="6 months">Comprehensive (6 Mo)</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading || !targetRole.trim()}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition-all disabled:opacity-50"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Synthesizing Learning Pathway...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 stroke-[2.5]" />
                  <span>Diagnose Gaps & Build Roadmap</span>
                </>
              )}
            </button>
          </form>

          {/* Progress Tracker Card if Result Available */}
          {result && (
            <div className="mt-6 pt-4 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-700 font-bold">Personal Sprint Progress</span>
                <span className="text-emerald-700 font-mono font-bold">
                  {stats.done} / {stats.total} Milestones ({stats.percent}%)
                </span>
              </div>
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-600 h-full rounded-full transition-all duration-300"
                  style={{ width: `${stats.percent}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500">
                Check off milestones as you complete each study block or build your capstone deliverables.
              </p>
            </div>
          )}
        </div>

        {/* Results Column (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          {loading && !result && (
            <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center space-y-4 shadow-sm">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center mx-auto text-blue-600 animate-spin">
                <RefreshCw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Analyzing Competency Taxonomy</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Haseeb is mapping your current capabilities against 2026 hiring benchmarks and curating verified course pathways...
                </p>
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* Readiness Overview */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-4">
                    <div className="relative w-16 h-16 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col items-center justify-center">
                      <span className="text-2xl font-black text-blue-700">{result.readinessScore}%</span>
                      <span className="text-[9px] text-slate-500 font-bold uppercase">Readiness</span>
                    </div>
                    <div>
                      <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                        Target: {result.targetRole}
                      </span>
                      <h3 className="text-lg font-bold text-slate-900 mt-1">Role Competency Differential</h3>
                    </div>
                  </div>

                  <button
                    onClick={() => handleGenerate()}
                    className="self-start sm:self-center px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors border border-slate-200"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Recalculate</span>
                  </button>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100">
                  {result.summary}
                </p>

                {/* 3-Tier Skill Gap Matrix */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 space-y-2">
                    <span className="text-[11px] font-bold text-rose-900 uppercase tracking-wider block">
                      Critical Gaps (Prerequisites):
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-700">
                      {result.skillGaps.criticalGaps.map((gap, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-rose-600 mt-0.5 font-bold">•</span>
                          <span>{gap}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 space-y-2">
                    <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider block">
                      Secondary Gaps (Competitive Edge):
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-700">
                      {result.skillGaps.secondaryGaps.map((gap, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-amber-600 mt-0.5 font-bold">•</span>
                          <span>{gap}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 space-y-2">
                    <span className="text-[11px] font-bold text-emerald-900 uppercase tracking-wider block">
                      Emerging / 2026 AI Tools:
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-700">
                      {result.skillGaps.emergingDifferentiators.map((gap, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-emerald-600 mt-0.5 font-bold">•</span>
                          <span>{gap}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Recommended Course & Credential Pathways */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                  <BookOpen className="w-5 h-5 text-teal-600" />
                  <div>
                    <h3 className="text-base font-bold text-slate-900">Curated Certification & Learning Pathways</h3>
                    <p className="text-xs text-slate-500">High-credibility programs prioritized for fastest competency acquisition</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {result.recommendedCourses.map((course, cIdx) => (
                    <div
                      key={cIdx}
                      className="bg-slate-50 rounded-xl p-4 border border-slate-200 flex flex-col justify-between space-y-3"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 border border-teal-200">
                            {course.provider}
                          </span>
                          <span className="text-[10px] text-slate-500 flex items-center gap-1 font-mono">
                            <Clock className="w-3 h-3" />
                            {course.estimatedDuration}
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-slate-900 leading-snug">{course.title}</h4>
                        <div className="text-[11px] text-emerald-700 font-semibold">{course.focusArea}</div>
                      </div>

                      <p className="text-xs text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200 leading-relaxed">
                        {course.reason}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Phased 30-60-90 Day Roadmap */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-emerald-600" />
                    <div>
                      <h3 className="text-base font-bold text-slate-900">Structured 30-60-90 Day Action Roadmap</h3>
                      <p className="text-xs text-slate-500">Click checkboxes to track your sprint progression</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-800 px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200">
                    Phased Sprints
                  </span>
                </div>

                <div className="space-y-6">
                  {/* Phase 1: 30 Days */}
                  <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 space-y-3.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 border-b border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
                          1
                        </span>
                        <h4 className="text-sm font-bold text-slate-900">Phase 1: Days 1–30 (Foundation & Tooling)</h4>
                      </div>
                      <span className="text-xs text-emerald-800 font-semibold">{result.roadmap.phase1_30Days.focus}</span>
                    </div>

                    <div className="space-y-2">
                      <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                        Sprint Milestones:
                      </span>
                      {result.roadmap.phase1_30Days.milestones.map((m, idx) => {
                        const isDone = !!completedMilestones[m];
                        return (
                          <div
                            key={idx}
                            onClick={() => toggleMilestone(m)}
                            className={`flex items-start gap-2.5 p-2 rounded-lg cursor-pointer transition-colors text-xs ${
                              isDone ? 'bg-emerald-50 text-emerald-900' : 'hover:bg-slate-100 text-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isDone}
                              onChange={() => {}}
                              className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-0 cursor-pointer"
                            />
                            <span className={isDone ? 'line-through text-slate-400' : ''}>{m}</span>
                          </div>
                        );
                      })}
                    </div>

                    <div className="bg-white p-3 rounded-lg border border-slate-200 flex items-start gap-2 text-xs">
                      <Trophy className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-amber-800 block">30-Day Capstone Deliverable:</strong>
                        <span className="text-slate-700">{result.roadmap.phase1_30Days.capstone}</span>
                      </div>
                    </div>
                  </div>

                  {/* Phase 2: 60 Days */}
                  <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 space-y-3.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 border-b border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-teal-600 text-white font-bold text-xs flex items-center justify-center">
                          2
                        </span>
                        <h4 className="text-sm font-bold text-slate-900">Phase 2: Days 31–60 (Advanced Practical Mastery)</h4>
                      </div>
                      <span className="text-xs text-teal-800 font-semibold">{result.roadmap.phase2_60Days.focus}</span>
                    </div>

                    <div className="space-y-2">
                      <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                        Sprint Milestones:
                      </span>
                      {result.roadmap.phase2_60Days.milestones.map((m, idx) => {
                        const isDone = !!completedMilestones[m];
                        return (
                          <div
                            key={idx}
                            onClick={() => toggleMilestone(m)}
                            className={`flex items-start gap-2.5 p-2 rounded-lg cursor-pointer transition-colors text-xs ${
                              isDone ? 'bg-teal-50 text-teal-900' : 'hover:bg-slate-100 text-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isDone}
                              onChange={() => {}}
                              className="mt-0.5 rounded border-slate-300 text-teal-600 focus:ring-0 cursor-pointer"
                            />
                            <span className={isDone ? 'line-through text-slate-400' : ''}>{m}</span>
                          </div>
                        );
                      })}
                    </div>

                    <div className="bg-white p-3 rounded-lg border border-slate-200 flex items-start gap-2 text-xs">
                      <Trophy className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-teal-800 block">60-Day Capstone Deliverable:</strong>
                        <span className="text-slate-700">{result.roadmap.phase2_60Days.capstone}</span>
                      </div>
                    </div>
                  </div>

                  {/* Phase 3: 90 Days */}
                  <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 space-y-3.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 border-b border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
                          3
                        </span>
                        <h4 className="text-sm font-bold text-slate-900">Phase 3: Days 61–90 (Executive Polish & Placement)</h4>
                      </div>
                      <span className="text-xs text-blue-800 font-semibold">{result.roadmap.phase3_90Days.focus}</span>
                    </div>

                    <div className="space-y-2">
                      <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                        Sprint Milestones:
                      </span>
                      {result.roadmap.phase3_90Days.milestones.map((m, idx) => {
                        const isDone = !!completedMilestones[m];
                        return (
                          <div
                            key={idx}
                            onClick={() => toggleMilestone(m)}
                            className={`flex items-start gap-2.5 p-2 rounded-lg cursor-pointer transition-colors text-xs ${
                              isDone ? 'bg-blue-50 text-blue-900' : 'hover:bg-slate-100 text-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isDone}
                              onChange={() => {}}
                              className="mt-0.5 rounded border-slate-300 text-blue-600 focus:ring-0 cursor-pointer"
                            />
                            <span className={isDone ? 'line-through text-slate-400' : ''}>{m}</span>
                          </div>
                        );
                      })}
                    </div>

                    <div className="bg-white p-3 rounded-lg border border-slate-200 flex items-start gap-2 text-xs">
                      <Trophy className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-blue-800 block">90-Day Capstone Deliverable:</strong>
                        <span className="text-slate-700">{result.roadmap.phase3_90Days.capstone}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
