import React, { useState } from 'react';
import { MARKET_BENCHMARKS } from '../data/sampleData';
import {
  TrendingUp,
  Globe,
  Coins,
  ShieldCheck,
  Building,
  Calculator,
  ArrowRight,
  Info,
  Check,
  Sparkles,
  PieChart
} from 'lucide-react';

export const MarketRadar: React.FC = () => {
  const [selectedRegionIndex, setSelectedRegionIndex] = useState(0); // 0 is Pakistan (PKR)
  const [calculatorInput, setCalculatorInput] = useState('180000'); // MTO entry default PKR 180k
  const currentBenchmark = MARKET_BENCHMARKS[selectedRegionIndex];

  // Quick gross-to-net estimator for Pakistan PKR
  const calculatePkrNet = (grossMonthly: number) => {
    // 2024-2026 progressive Pakistan tax approximation
    const annual = grossMonthly * 12;
    let annualTax = 0;

    if (annual <= 600000) {
      annualTax = 0;
    } else if (annual <= 1200000) {
      annualTax = (annual - 600000) * 0.05;
    } else if (annual <= 2200000) {
      annualTax = 30000 + (annual - 1200000) * 0.15;
    } else if (annual <= 3200000) {
      annualTax = 180000 + (annual - 2200000) * 0.25;
    } else if (annual <= 4100000) {
      annualTax = 430000 + (annual - 3200000) * 0.30;
    } else {
      annualTax = 700000 + (annual - 4100000) * 0.35;
    }

    const monthlyTax = Math.round(annualTax / 12);
    const monthlyNet = Math.max(0, grossMonthly - monthlyTax);
    const effectiveTaxRate = annual > 0 ? ((annualTax / annual) * 100).toFixed(1) : '0';

    return {
      monthlyTax,
      monthlyNet,
      effectiveTaxRate,
    };
  };

  const pkrStats = calculatePkrNet(Number(calculatorInput) || 0);

  return (
    <div className="space-y-8">
      {/* Intro Mission Card - Light Theme */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs">
        <div className="max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
            <Globe className="w-3.5 h-3.5 text-emerald-600" />
            <span>Pakistani Currency (PKR) & Global Remote (USD) Economics</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Market Radar & Localized Compensation Intelligence
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Real compensation data tailored for Pakistan (Lahore, Karachi, Islamabad) and international remote jobs. Understand student stipend baselines, MTO entry salaries, senior packages, and monthly take-home tax calculations.
          </p>
        </div>

        {/* Region Switcher Pills */}
        <div className="mt-6 flex flex-wrap gap-2 pt-6 border-t border-slate-100">
          {MARKET_BENCHMARKS.map((item, idx) => (
            <button
              key={item.region}
              onClick={() => setSelectedRegionIndex(idx)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedRegionIndex === idx
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
              }`}
            >
              <span className="text-base">{item.flag}</span>
              <span>{item.region}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Selected Benchmark Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Tiers & Perks (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{currentBenchmark.flag}</span>
                <div>
                  <h2 className="text-lg font-bold text-slate-900">{currentBenchmark.region}</h2>
                  <p className="text-xs text-slate-500">Official Currency: {currentBenchmark.currency}</p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">
                2026 Calibrated
              </span>
            </div>

            {/* Experience Level Tiers */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Market Salary Bands by Seniority:
              </h3>
              <div className="grid grid-cols-1 gap-2.5">
                {currentBenchmark.tierLevels.map((tier, tIdx) => (
                  <div
                    key={tIdx}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3.5 rounded-xl bg-slate-50 border border-slate-200"
                  >
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">{tier.level}</span>
                      <span className="text-[11px] text-slate-500 font-mono">Approx. {tier.usdApprox}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-black text-emerald-700 font-mono">{tier.range}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Localized Statutory Perks & Benefits */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Common Pakistani Benefits & Perks (Nestle, Jazz, Systems):
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {currentBenchmark.commonPerks.map((perk, pIdx) => (
                  <div
                    key={pIdx}
                    className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs text-slate-700"
                  >
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{perk}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Market Context from Haseeb */}
            <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200 text-xs text-slate-700 space-y-1.5">
              <div className="flex items-center gap-2 font-bold text-emerald-900">
                <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                <span>Haseeb's Talent Market Context:</span>
              </div>
              <p className="leading-relaxed text-slate-600">{currentBenchmark.marketContext}</p>
            </div>
          </div>
        </div>

        {/* Right Column: Local Calculator & Strategy Guide (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Pakistan PKR Gross-to-Net Estimator */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Calculator className="w-5 h-5 text-emerald-600" />
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                  Pakistan PKR Take-Home Calculator
                </h3>
                <p className="text-[11px] text-slate-500">Monthly Gross vs. Estimated Withholding Tax</p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Monthly Gross Salary (PKR)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-500">PKR</span>
                  <input
                    type="number"
                    value={calculatorInput}
                    onChange={(e) => setCalculatorInput(e.target.value)}
                    step="25000"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl pl-12 pr-3.5 py-2 text-sm text-slate-900 font-mono focus:outline-none"
                  />
                </div>
              </div>

              {/* Quick Presets */}
              <div className="flex flex-wrap gap-1.5">
                {[
                  { label: 'Intern (50k)', val: '50000' },
                  { label: 'Fresh MTO (180k)', val: '180000' },
                  { label: 'Mid Dev (350k)', val: '350000' },
                  { label: 'Senior (650k)', val: '650000' }
                ].map((preset) => (
                  <button
                    key={preset.val}
                    onClick={() => setCalculatorInput(preset.val)}
                    className="text-[10px] px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors font-mono font-medium"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              {/* Calculation Output Cards */}
              <div className="grid grid-cols-2 gap-2.5 pt-2">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                  <span className="text-[10px] text-slate-500 font-bold uppercase block mb-0.5">Est. Monthly Tax</span>
                  <span className="text-sm font-black text-rose-600 font-mono">
                    PKR {pkrStats.monthlyTax.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">({pkrStats.effectiveTaxRate}% effective)</span>
                </div>

                <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 text-center">
                  <span className="text-[10px] text-emerald-800 font-bold uppercase block mb-0.5">Estimated Net Pay</span>
                  <span className="text-sm font-black text-emerald-900 font-mono">
                    PKR {pkrStats.monthlyNet.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">Take-home / mo</span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-start gap-2">
              <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                Based on current progressive salaried tax slabs in Pakistan. Annual income up to PKR 600,000 (PKR 50k/mo, typical for internships) is completely tax exempt!
              </span>
            </div>
          </div>

          {/* Haseeb's Comp Negotiation Playbook */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <PieChart className="w-5 h-5 text-teal-600" />
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Haseeb's Student & Graduate Playbook
              </h3>
            </div>

            <div className="space-y-2.5 text-xs text-slate-700">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <strong className="text-emerald-800 block">1. Internship Stipends & Certificates:</strong>
                <p className="text-slate-600">
                  Top tier FMCGs (Nestlé, PepsiCo, Unilever) offer paid internships (PKR 40,000 to 65,000/mo) with pick-and-drop. Never settle for unpaid programs when reputable multinationals offer both stipends and PPOs (Pre-Placement Offers).
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <strong className="text-teal-800 block">2. USD Remote Banking (Wise / Payoneer / Elevate):</strong>
                <p className="text-slate-600">
                  When landing global remote gigs, set up an account on Wise, Payoneer, or Elevate linked to your Pakistani bank (HBL, Meezan, Faysal) to receive full USD value with zero arbitrary currency haircuts.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <strong className="text-blue-800 block">3. Inpatient & Outpatient Family Coverage:</strong>
                <p className="text-slate-600">
                  At Pakistani software houses and corporates, comprehensive health insurance covering yourself and your parents can be worth over PKR 300,000/year in financial peace of mind.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
