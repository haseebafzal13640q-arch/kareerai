import { PakistaniJob } from '../types';

export const PAKISTANI_INDUSTRIES: string[] = [
  'All Industries',
  'FMCG & Consumer Goods',
  'IT & Enterprise Software',
  'Banking & FinTech',
  'Telecommunications',
  'Pharmaceuticals & Healthcare',
  'Textiles & Apparel Manufacturing',
  'Energy & Chemicals',
  'Logistics & Supply Chain',
  'E-Commerce & Retail',
  'Engineering & Construction'
];

export const PAKISTANI_DEPARTMENTS: string[] = [
  'All Departments',
  'Human Resources (HR)',
  'Management & Leadership',
  'Software & Cloud Engineering',
  'Marketing & Brand Management',
  'Finance, Accounts & Audit',
  'Supply Chain & Logistics',
  'Data & Business Intelligence',
  'UI/UX & Product Design',
  'Quality Assurance & Regulatory',
  'Sales & Client Relations'
];

export const PAKISTANI_REGIONS: { label: string; city: string; province: string }[] = [
  { label: 'All of Pakistan', city: 'all', province: 'all' },
  { label: 'Lahore (Punjab)', city: 'Lahore', province: 'Punjab' },
  { label: 'Karachi (Sindh)', city: 'Karachi', province: 'Sindh' },
  { label: 'Islamabad (Capital)', city: 'Islamabad', province: 'Islamabad (ICT)' },
  { label: 'Rawalpindi (Punjab)', city: 'Rawalpindi', province: 'Punjab' },
  { label: 'Faisalabad (Punjab)', city: 'Faisalabad', province: 'Punjab' },
  { label: 'Multan (Punjab)', city: 'Multan', province: 'Punjab' },
  { label: 'Sialkot (Punjab)', city: 'Sialkot', province: 'Punjab' },
  { label: 'Peshawar (KPK)', city: 'Peshawar', province: 'Khyber Pakhtunkhwa' },
  { label: 'Quetta (Balochistan)', city: 'Quetta', province: 'Balochistan' },
  { label: 'Gujranwala (Punjab)', city: 'Gujranwala', province: 'Punjab' },
  { label: 'Sheikhupura (Punjab)', city: 'Sheikhupura', province: 'Punjab' },
  { label: 'Hyderabad (Sindh)', city: 'Hyderabad', province: 'Sindh' },
  { label: 'Sukkur & Daharki (Sindh)', city: 'Sukkur', province: 'Sindh' },
  { label: 'Abbottabad (KPK)', city: 'Abbottabad', province: 'Khyber Pakhtunkhwa' },
  { label: 'Gilgit & AJK', city: 'Gilgit', province: 'Gilgit-Baltistan & AJK' },
  { label: '100% Remote (USD & PKR)', city: 'Remote', province: 'Nationwide / Remote' }
];

export const PAKISTANI_JOBS_LIST: PakistaniJob[] = [
  // ==========================================
  // 1. HUMAN RESOURCES (HR) & PEOPLE OPS
  // ==========================================
  {
    id: 'nestle-hr-trainee',
    title: 'HR People Operations & Talent Trainee',
    company: 'Nestlé Pakistan',
    category: 'internship',
    industry: 'FMCG & Consumer Goods',
    department: 'Human Resources (HR)',
    location: 'Lahore (Upper Mall Head Office) / Sheikhupura Factory',
    city: 'Lahore',
    province: 'Punjab',
    stipendOrSalary: 'PKR 45,000 - 65,000 / month',
    currency: 'PKR',
    experience: 'Undergrad Students (3rd/4th Year) or Fresh BBA/MBA',
    education: 'BBA / BS in Human Resources / Public Administration',
    deadline: 'Rolling Intake 2026',
    logoText: 'Nestlé',
    badgeColor: 'blue',
    description: 'Work with the Corporate Human Resources team at Nestlé Pakistan. Support talent acquisition funnels, onboarding bootcamps, and factory labor employee engagement across Sheikhupura and Kabirwala plants.',
    keyRequirements: [
      'Knowledge of recruitment life cycles and talent screening practices',
      'High interpersonal empathy and strong written communication in English and Urdu',
      'Proficiency in Microsoft Excel (VLOOKUP, Pivot) and PowerPoint presentations',
      'Ability to coordinate university campus recruitment drives across LUMS, IBA, and FAST'
    ],
    perks: [
      'Official Nestlé HR Internship Credential',
      'Fast-track interview for HR Management Trainee (MTO) cycle',
      'Free air-conditioned transport & subsidized company cafeteria',
      'Mentorship with Nestlé Pakistan HR Director'
    ],
    applyUrl: 'https://www.nestle.pk/jobs'
  },
  {
    id: 'systems-talent-acquisition',
    title: 'Associate Talent Acquisition Specialist (Tech Hiring)',
    company: 'Systems Limited',
    category: 'onsite',
    industry: 'IT & Enterprise Software',
    department: 'Human Resources (HR)',
    location: 'Karachi (Shahrah-e-Faisal) & Lahore (Tech Vista)',
    city: 'Karachi',
    province: 'Sindh',
    stipendOrSalary: 'PKR 110,000 - 165,000 / month',
    currency: 'PKR',
    experience: '0-2 years experience in IT recruitment or HR coordination',
    education: 'Bachelors in HR, Business Administration, or Computer Science',
    deadline: 'Immediate Opening',
    logoText: 'Systems',
    badgeColor: 'teal',
    description: 'Lead technical headhunting and candidate pipeline operations for Pakistan’s largest software export powerhouse. Source top full-stack engineers, cloud architects, and data scientists across Pakistan.',
    keyRequirements: [
      'Understanding of tech terminology (.NET, React, AWS, Kubernetes, Python)',
      'Hands-on expertise using LinkedIn Recruiter, Rozee.pk, and Applicant Tracking Systems (ATS)',
      'High-velocity interview scheduling and candidate stakeholder management'
    ],
    perks: [
      'Bi-annual performance bonuses and hiring commission allowances',
      'Inpatient and outpatient medical insurance for employee and parents',
      'Annual company trip, gym, and daycare facilities onsite'
    ],
    applyUrl: 'https://www.systemsltd.com/careers'
  },
  {
    id: 'engro-hrbp-officer',
    title: 'HR Business Partner (HRBP) Executive',
    company: 'Engro Corporation',
    category: 'onsite',
    industry: 'Energy & Chemicals',
    department: 'Human Resources (HR)',
    location: 'Daharki Plant Site / Karachi Harbour Front',
    city: 'Sukkur',
    province: 'Sindh',
    stipendOrSalary: 'PKR 150,000 - 210,000 / month + Housing',
    currency: 'PKR',
    experience: '1-3 years experience in HR operations or labor relations',
    education: 'BBA / MBA in Human Resources or Industrial Relations',
    deadline: 'Active Intake 2026',
    logoText: 'Engro',
    badgeColor: 'emerald',
    description: 'Drive strategic workforce planning, technical staff performance reviews, and plant safety compliance for Engro Fertilizers. Bridge corporate headquarters with manufacturing operational teams.',
    keyRequirements: [
      'Familiarity with Pakistan Industrial Relations Act (IRA) and labor compliance standards',
      'Experience in grievance handling, performance management, and HR analytics in SAP',
      'Willingness to spend scheduled rotation days at the Daharki manufacturing complex'
    ],
    perks: [
      'Full executive family housing and club membership in Daharki residential township',
      'Company car allowance with monthly fuel allocation',
      'Comprehensive medical coverage + Provident Fund & Gratuity'
    ],
    applyUrl: 'https://www.engro.com/careers'
  },
  {
    id: 'foodpanda-people-culture',
    title: 'People & Culture Associate (Regional Operations)',
    company: 'Foodpanda Pakistan',
    category: 'onsite',
    industry: 'E-Commerce & Retail',
    department: 'Human Resources (HR)',
    location: 'Islamabad (Blue Area) / Rawalpindi Hub',
    city: 'Islamabad',
    province: 'Islamabad (ICT)',
    stipendOrSalary: 'PKR 90,000 - 135,000 / month',
    currency: 'PKR',
    experience: 'Fresh Graduate to 1 year',
    education: 'Bachelors in HR, Social Sciences, or Business Administration',
    deadline: 'Open Intake',
    logoText: 'Foodpanda',
    badgeColor: 'pink',
    description: 'Support high-energy people operations across Islamabad, Rawalpindi, and Northern Punjab. Manage rider onboarding audits, internal culture festivities, and workplace happiness programs.',
    keyRequirements: [
      'Energetic and creative mindset with strong organizational abilities',
      'Proficiency in Google Sheets and digital HRIS platforms (Workday/BambooHR)',
      'Fluency in bilingual communication (English/Urdu)'
    ],
    perks: [
      'Monthly Foodpanda corporate food voucher allowance',
      'Flexible hybrid working arrangements',
      'OPD/IPD medical cover for self and dependents'
    ],
    applyUrl: 'https://careers.deliveryhero.com'
  },

  // ==========================================
  // 2. MANAGEMENT & LEADERSHIP TRAINEE (MTO)
  // ==========================================
  {
    id: 'pepsi-mto-leadership',
    title: 'PepsiCo Graduate Leadership Trainee (MTO Commercial)',
    company: 'PepsiCo Pakistan',
    category: 'onsite',
    industry: 'FMCG & Consumer Goods',
    department: 'Management & Leadership',
    location: 'Lahore (Gulberg HQ) / Multan Industrial Plant',
    city: 'Lahore',
    province: 'Punjab',
    stipendOrSalary: 'PKR 160,000 - 230,000 / month + 1000cc Car',
    currency: 'PKR',
    experience: 'Graduating Batch 2025/2026 or 0-1 year experience',
    education: 'Bachelors or Masters from an accredited institution',
    deadline: 'Spring/Summer Batch 2026',
    logoText: 'PepsiCo',
    badgeColor: 'indigo',
    description: 'Fast-track executive incubation program. Rotate through beverage and snacks commercial units (Lay’s, Kurkure, Sting, Mountain Dew), field sales management, and wholesale channel planning.',
    keyRequirements: [
      'Minimum CGPA 3.0 / 4.0 or equivalent distinction',
      'Strong leadership track record in student societies, debate, or athletics',
      'Readiness for cross-city rotations across Lahore, Multan, and Faisalabad'
    ],
    perks: [
      '1000cc company-maintained vehicle with complete fuel quota',
      'Subsidized company cafeteria and snacks allowance',
      'Executive mentorship with Vice President of General Trade'
    ],
    applyUrl: 'https://www.pepsicojobs.com'
  },
  {
    id: 'unilever-pk-mto',
    title: 'Unilever Future Leaders Program (UFLP / MTO)',
    company: 'Unilever Pakistan',
    category: 'onsite',
    industry: 'FMCG & Consumer Goods',
    department: 'Management & Leadership',
    location: 'Karachi (Avari Plaza) / Rahim Yar Khan Factory',
    city: 'Karachi',
    province: 'Sindh',
    stipendOrSalary: 'PKR 180,000 - 250,000 / month',
    currency: 'PKR',
    experience: 'Fresh Graduates / 0-1 yr experience',
    education: 'Bachelors / Masters in Business, Engineering, or CS',
    deadline: 'Annual Intake',
    logoText: 'Unilever',
    badgeColor: 'blue',
    description: 'The premier corporate leadership incubation in South Asia. Work directly with iconic global brands (Dove, Sunsilk, Lifebuoy, Surf Excel), rotating through Commercial Strategy and Factory Operations.',
    keyRequirements: [
      'Graduating in 2025/2026 or less than 12 months post-graduate work',
      'High emotional resilience, strategic problem-solving, and team alignment',
      'Willingness to spend 4-6 months at manufacturing plants in Punjab/Sindh'
    ],
    perks: [
      'Market-leading fresh graduate salary with bi-annual inflation reviews',
      'Executive company vehicle and fuel card upon confirmation',
      'Comprehensive hospital insurance for employee, spouse, and parents'
    ],
    applyUrl: 'https://careers.unilever.com/pakistan'
  },
  {
    id: 'daraz-business-ops',
    title: 'Business Operations & Marketplace Associate',
    company: 'Daraz Pakistan (Alibaba Group)',
    category: 'onsite',
    industry: 'E-Commerce & Retail',
    department: 'Management & Leadership',
    location: 'Karachi (Dolmen City, Clifton) & Lahore Hub',
    city: 'Karachi',
    province: 'Sindh',
    stipendOrSalary: 'PKR 110,000 - 165,000 / month',
    currency: 'PKR',
    experience: '0-2 years in business operations, logistics, or consulting',
    education: 'Bachelors in Management, Economics, or Data Analytics',
    deadline: 'Active 2026',
    logoText: 'Daraz',
    badgeColor: 'amber',
    description: 'Manage seller performance, 11.11 mega campaign logistics, and seller ecosystem operations for Pakistan’s leading digital e-commerce marketplace.',
    keyRequirements: [
      'High-velocity data modeling in Excel and SQL',
      'Root-cause mindset to diagnose delivery delays and warehouse bottlenecks',
      'Ability to negotiate commercial terms with multi-brand sellers'
    ],
    perks: [
      'Alibaba global e-commerce training certifications',
      'Discounted Daraz shopping credits and monthly health insurance',
      'Flexible, modern corporate work environment'
    ],
    applyUrl: 'https://careers.daraz.com'
  },
  {
    id: 'netsol-project-trainee',
    title: 'Associate Project Coordinator / Trainee',
    company: 'NetSol Technologies',
    category: 'onsite',
    industry: 'IT & Enterprise Software',
    department: 'Management & Leadership',
    location: 'Lahore (NetSol IT Village, Ring Road)',
    city: 'Lahore',
    province: 'Punjab',
    stipendOrSalary: 'PKR 90,000 - 140,000 / month',
    currency: 'PKR',
    experience: 'Fresh Graduate to 1 year',
    education: 'BS in Computer Science, SE, or BBA Project Management',
    deadline: 'Active 2026',
    logoText: 'NetSol',
    badgeColor: 'purple',
    description: 'Coordinate global asset finance and leasing software implementations (NFS Ascent) for Tier-1 automotive and leasing clients across China, Europe, and North America.',
    keyRequirements: [
      'Familiarity with Agile Scrum principles, Jira, and Confluence',
      'Exceptional written documentation and sprint tracking skills',
      'Effective communication for coordinating engineering and client deliveries'
    ],
    perks: [
      'Sponsorship for CAPM / PMP or Scrum Master certification',
      'Onsite gym, sports complex, and subsidized catering',
      'Life insurance and annual appraisal increments'
    ],
    applyUrl: 'https://netsoltech.com/careers'
  },

  // ==========================================
  // 3. MARKETING, BRAND & DIGITAL GROWTH
  // ==========================================
  {
    id: 'shan-foods-trade-marketing',
    title: 'Trade Marketing Executive (South & Interior Sindh)',
    company: 'Shan Foods',
    category: 'onsite',
    industry: 'FMCG & Consumer Goods',
    department: 'Marketing & Brand Management',
    location: 'Karachi (Korangi Industrial Area) & Hyderabad',
    city: 'Hyderabad',
    province: 'Sindh',
    stipendOrSalary: 'PKR 100,000 - 150,000 / month + Fuel',
    currency: 'PKR',
    experience: '1-3 years in retail field marketing or distribution audit',
    education: 'BBA / BS in Marketing or Commerce',
    deadline: 'Immediate',
    logoText: 'Shan',
    badgeColor: 'red',
    description: 'Execute retail visibility, point-of-sale merchandising, and distributor loyalty programs for Pakistan’s renowned culinary recipe brand across Karachi and Hyderabad markets.',
    keyRequirements: [
      'Knowledge of General Trade (GT) retail dynamics and wholesale dealer networks',
      'Fluency in Sindhi and Urdu for effective distributor negotiation',
      'Analytical ability to track Planogram compliance and POSM ROI'
    ],
    perks: [
      'Company motorcycle / car fuel allowance',
      'Daily field allowance and mobile telephone bill reimbursement',
      'Annual performance bonus and health coverage'
    ],
    applyUrl: 'https://shanfoods.com/careers'
  },
  {
    id: 'interwood-digital-marketing',
    title: 'Digital Marketing & Social Media Specialist',
    company: 'Interwood Mobel (Pvt) Ltd',
    category: 'onsite',
    industry: 'Textiles & Apparel Manufacturing',
    department: 'Marketing & Brand Management',
    location: 'Lahore (Karakoram Enclave / Johar Town)',
    city: 'Lahore',
    province: 'Punjab',
    stipendOrSalary: 'PKR 95,000 - 150,000 / month',
    currency: 'PKR',
    experience: '1-3 years managing Meta Ads, Google Ads, and TikTok',
    education: 'Bachelors in Marketing, Media, or Mass Communication',
    deadline: 'Active 2026',
    logoText: 'Interwood',
    badgeColor: 'amber',
    description: 'Drive lead generation, architectural furniture showroom footfall, and e-commerce cart checkouts for Pakistan’s premier home and office lifestyle furnishing brand.',
    keyRequirements: [
      'Proficiency in Meta Business Suite, Google Analytics 4, and search ads',
      'Hands-on experience with lifestyle visual aesthetics and Reels/TikTok direction',
      'Proven track record of managing monthly ad spends exceeding PKR 1.5M with $\ge$ 4x ROAS'
    ],
    perks: [
      'Generous staff discounts on Interwood home furnishings',
      'Performance-linked digital campaign bonuses',
      'OPD health insurance and annual leave encashment'
    ],
    applyUrl: 'https://interwood.pk/careers'
  },
  {
    id: 'bata-ecommerce-growth',
    title: 'Assistant Brand Manager & Growth Specialist',
    company: 'Bata Pakistan',
    category: 'onsite',
    industry: 'Textiles & Apparel Manufacturing',
    department: 'Marketing & Brand Management',
    location: 'Lahore (Batapur HQ) & Sialkot Outlet Cluster',
    city: 'Sialkot',
    province: 'Punjab',
    stipendOrSalary: 'PKR 120,000 - 175,000 / month',
    currency: 'PKR',
    experience: '1-3 years in retail brand management or footwear marketing',
    education: 'BBA / MBA in Marketing from recognized institution',
    deadline: 'Active Intake',
    logoText: 'Bata',
    badgeColor: 'red',
    description: 'Plan nationwide seasonal footwear launches (Back to School, Eid, Wedding collections), collaborate with retail store managers across Sialkot, Gujranwala, and Lahore.',
    keyRequirements: [
      'Experience in 360-degree ATL/BTL campaign planning and retail merchandising',
      'Capability to synthesize customer survey data into consumer price positioning',
      'Strong liaison skills with creative agencies and print production houses'
    ],
    perks: [
      'Subsidized corporate transportation on GT Road / Batapur corridors',
      'Company footwear discount vouchers for family',
      'Provident Fund and complete medical coverage'
    ],
    applyUrl: 'https://www.bata.com.pk/careers'
  },

  // ==========================================
  // 4. FINANCE, ACCOUNTS & AUDIT
  // ==========================================
  {
    id: 'lucky-cement-finance',
    title: 'Corporate Financial Analyst / Budgeting Officer',
    company: 'Lucky Cement (YBG Group)',
    category: 'onsite',
    industry: 'Engineering & Construction',
    department: 'Finance, Accounts & Audit',
    location: 'Karachi (Clifton Head Office) / Pezu Plant',
    city: 'Karachi',
    province: 'Sindh',
    stipendOrSalary: 'PKR 130,000 - 190,000 / month',
    currency: 'PKR',
    experience: '1-3 years experience or Part-Qualified CA / ACCA / CMA',
    education: 'ACCA / CA Finalist / BS Accounting & Finance',
    deadline: 'Immediate',
    logoText: 'Lucky',
    badgeColor: 'emerald',
    description: 'Analyze energy costs, coal import hedging, dispatch freight margins, and plant CAPEX budgets for Pakistan’s largest cement exporter and conglomerate.',
    keyRequirements: [
      'Deep expertise in 3-statement financial modeling and variance reporting in SAP',
      'Sound knowledge of IFRS, Pakistani corporate tax laws, and SBP import regulations',
      'Advanced Excel (Scenario Manager, Power Query, Financial Formulas)'
    ],
    perks: [
      'Annual performance bonus (2-3 gross salaries based on plant profit metrics)',
      'Subsidized executive dining and pick/drop facility',
      'Comprehensive hospital insurance for self and family'
    ],
    applyUrl: 'https://lucky-cement.com/careers'
  },
  {
    id: 'easypaisa-fintech-treasury',
    title: 'FinTech Treasury & Liquidity Risk Analyst',
    company: 'Easypaisa (Telenor Microfinance Bank)',
    category: 'onsite',
    industry: 'Banking & FinTech',
    department: 'Finance, Accounts & Audit',
    location: 'Islamabad (Sector F-8 / I-9 Digital Park)',
    city: 'Islamabad',
    province: 'Islamabad (ICT)',
    stipendOrSalary: 'PKR 140,000 - 210,000 / month',
    currency: 'PKR',
    experience: '1-3 years in banking treasury, risk management, or financial analysis',
    education: 'BS/MS in Finance, Economics, or CFA Level 1 candidate',
    deadline: 'Active 2026',
    logoText: 'Easypaisa',
    badgeColor: 'emerald',
    description: 'Manage liquidity buffers, Raast instant transaction balancing, SBP Cash Reserve Ratio (CRR), and merchant settlement reconciliation for Pakistan’s pioneering digital wallet.',
    keyRequirements: [
      'Understanding of digital money velocity, agent liquidity corridors, and interbank money market',
      'Knowledge of SBP Branchless Banking regulations and AML/CFT guidelines',
      'Proficiency in SQL data extraction and automated ledger reconciliation'
    ],
    perks: [
      'Subsidized staff personal loans and smartphone device allowance',
      'Hybrid work model (2 days work from home)',
      'Premium medical insurance including parents coverage'
    ],
    applyUrl: 'https://easypaisa.com.pk/careers'
  },
  {
    id: 'pwc-audit-trainee',
    title: 'Audit & Assurance Trainee (CA Articleship)',
    company: 'A.F. Ferguson & Co. (PwC Pakistan)',
    category: 'onsite',
    industry: 'Banking & FinTech',
    department: 'Finance, Accounts & Audit',
    location: 'Karachi / Lahore / Islamabad',
    city: 'Rawalpindi',
    province: 'Punjab',
    stipendOrSalary: 'ICAP Stipend Rate (PKR 35,000 - 55,000 / month)',
    currency: 'PKR',
    experience: 'CAF Qualified (ICAP) or ACCA Affiliate',
    education: 'ICAP CAF Qualified / ACCA / BS Accounting',
    deadline: 'Bi-Annual Spring/Autumn Intake',
    logoText: 'PwC',
    badgeColor: 'amber',
    description: 'Gold-standard chartered accountancy training contract with the leading Big 4 firm in Pakistan. Conduct statutory financial audits for multinational banks, FMCGs, and telecom operators.',
    keyRequirements: [
      'CAF qualified from ICAP or full ACCA examination clearance',
      'High analytical rigor, attention to audit trails, and ethics',
      'Readiness for rigorous travel to client premises across Punjab, Sindh, and KPK'
    ],
    perks: [
      'Direct partner mentorship and official ICAP articleship completion certificate',
      'Paid study leave for CFAP examinations and technical coaching',
      'High-prestige CV credential opening doors to Middle East / UK advisory careers'
    ],
    applyUrl: 'https://www.pwc.com/pk/careers'
  },

  // ==========================================
  // 5. SUPPLY CHAIN, LOGISTICS & MANUFACTURING
  // ==========================================
  {
    id: 'engro-supply-chain',
    title: 'Supply Chain Planning & Inventory Executive',
    company: 'Engro Fertilizers',
    category: 'onsite',
    industry: 'Energy & Chemicals',
    department: 'Supply Chain & Logistics',
    location: 'Daharki Plant / Sukkur Distribution Hub / Karachi',
    city: 'Sukkur',
    province: 'Sindh',
    stipendOrSalary: 'PKR 140,000 - 200,000 / month',
    currency: 'PKR',
    experience: '1-3 years in production planning, inventory control, or logistics',
    education: 'BS in Supply Chain, Industrial Engineering, or MBA Operations',
    deadline: 'Active 2026',
    logoText: 'Engro',
    badgeColor: 'emerald',
    description: 'Optimize agricultural fertilizer bagging rates, railway carriage logistics, and nationwide warehouse storage buffer levels across Sindh and Punjab agricultural belts.',
    keyRequirements: [
      'Hands-on expertise in SAP MM / PP modules and inventory optimization models',
      'Familiarity with demurrage minimization and bulk road transportation dispatching',
      'Ability to coordinate with manufacturing plant operations and regional sales directors'
    ],
    perks: [
      'Free residential accommodation in gated Engro housing colony',
      'Comprehensive IPD/OPD medical cover + Provident Fund matching',
      'Annual factory productivity bonus'
    ],
    applyUrl: 'https://www.engro.com/careers'
  },
  {
    id: 'trax-logistics-coordinator',
    title: 'Logistics Fleet & Fulfillment Hub Coordinator',
    company: 'Trax Logistics (Logex Pvt Ltd)',
    category: 'onsite',
    industry: 'Logistics & Supply Chain',
    department: 'Supply Chain & Logistics',
    location: 'Faisalabad Hub / Lahore Central Sort Center',
    city: 'Faisalabad',
    province: 'Punjab',
    stipendOrSalary: 'PKR 80,000 - 120,000 / month',
    currency: 'PKR',
    experience: '1-2 years in e-commerce courier logistics or parcel hub ops',
    education: 'Bachelors in Supply Chain, Commerce, or Business',
    deadline: 'Immediate',
    logoText: 'Trax',
    badgeColor: 'orange',
    description: 'Direct first-mile pickup runs from Faisalabad textile mills and ensure sub-18-hour line-haul dispatch to Karachi, Lahore, and Islamabad fulfillment centers.',
    keyRequirements: [
      'Experience managing rider dispatching and delivery success rate metrics',
      'Proficiency in Excel and Transport Management Software (TMS)',
      'Leadership stamina to supervise high-volume evening sorting operations'
    ],
    perks: [
      'Performance-based monthly on-time delivery dispatch incentives',
      'Fuel reimbursement and company smartphone',
      'Medical insurance coverage'
    ],
    applyUrl: 'https://trax.pk/careers'
  },
  {
    id: 'nishat-textile-qa',
    title: 'Textile Production & Quality Control Officer',
    company: 'Nishat Mills Limited',
    category: 'onsite',
    industry: 'Textiles & Apparel Manufacturing',
    department: 'Supply Chain & Logistics',
    location: 'Faisalabad (Sheikhupura Road Mills) / Lahore',
    city: 'Faisalabad',
    province: 'Punjab',
    stipendOrSalary: 'PKR 90,000 - 145,000 / month',
    currency: 'PKR',
    experience: '0-2 years in spinning, weaving, or garment quality inspection',
    education: 'BSc Textile Engineering (NTU Faisalabad or similar)',
    deadline: 'Active 2026',
    logoText: 'Nishat',
    badgeColor: 'blue',
    description: 'Ensure fabric shade consistency, tensile strength, and export compliance for international retail apparel buyers (Target, GAP, H&M) at Pakistan’s premier integrated textile mill.',
    keyRequirements: [
      'Understanding of OEKO-TEX, ISO 9001, and international fabric defect auditing systems (4-Point System)',
      'PEC registration or recognized Textile Engineering accreditation',
      'Willingness to handle shift rotations in weaving and dyeing sections'
    ],
    perks: [
      'Subsidized bachelor hostel accommodation in Nishat Mill premises',
      'Subsidized mess catering and company transport from Faisalabad city center',
      'Overtime allowance and production target bonuses'
    ],
    applyUrl: 'https://nishatmillsltd.com/careers'
  },

  // ==========================================
  // 6. SOFTWARE & CLOUD ENGINEERING
  // ==========================================
  {
    id: 'systems-ltd-engineer',
    title: 'Associate Software Engineer (.NET / React / Cloud)',
    company: 'Systems Limited',
    category: 'onsite',
    industry: 'IT & Enterprise Software',
    department: 'Software & Cloud Engineering',
    location: 'Lahore (Tech Vista E-1) / Karachi / Islamabad',
    city: 'Lahore',
    province: 'Punjab',
    stipendOrSalary: 'PKR 120,000 - 180,000 / month',
    currency: 'PKR',
    experience: 'Fresh Graduate to 2 years',
    education: 'BS in Computer Science / Software Engineering / IT',
    deadline: 'Immediate Hiring',
    logoText: 'Systems',
    badgeColor: 'teal',
    description: 'Build enterprise banking, retail, and cloud solutions for global Fortune 500 clients. Pakistan’s highest market-cap IT company and Forbes Asia Best Under A Billion winner.',
    keyRequirements: [
      'Strong foundation in Object-Oriented Programming (C# / Java / TypeScript)',
      'Understanding of SQL databases, entity framework, or modern React hooks',
      'Good algorithmic problem-solving and clean coding discipline'
    ],
    perks: [
      'Comprehensive on-job training and certification sponsorship (AWS / Azure)',
      'Provident fund + annual performance bonus',
      'Inpatient/Outpatient medical coverage + Gym & recreational facilities onsite'
    ],
    applyUrl: 'https://www.systemsltd.com/careers'
  },
  {
    id: '10pearls-mobile-dev',
    title: 'Junior Mobile Application Developer (Flutter / React Native)',
    company: '10Pearls Pakistan',
    category: 'onsite',
    industry: 'IT & Enterprise Software',
    department: 'Software & Cloud Engineering',
    location: 'Karachi (Amna Tower, PECHS) / Islamabad',
    city: 'Karachi',
    province: 'Sindh',
    stipendOrSalary: 'PKR 130,000 - 195,000 / month',
    currency: 'PKR',
    experience: '0-2 years mobile app development experience',
    education: 'BS in Computer Science or Software Engineering',
    deadline: 'Active 2026',
    logoText: '10Pearls',
    badgeColor: 'purple',
    description: 'Engineer high-performance cross-platform mobile apps for US enterprise healthcare, telecom, and fintech clients. Focus on offline persistence, biometric auth, and fluid 60fps UI.',
    keyRequirements: [
      'Proficiency in Dart/Flutter or React Native / TypeScript',
      'State management expertise (Bloc, Riverpod, Redux Toolkit, or Zustand)',
      'Published application on Google Play Store or Apple TestFlight is a big plus'
    ],
    perks: [
      'Free hot meals and subsidized executive cafeteria onsite',
      'Learning budget for Udemy/Coursera and conference passes',
      'Complete IPD/OPD medical cover for employee and parents'
    ],
    applyUrl: 'https://10pearls.com/careers'
  },
  {
    id: 'venturedive-devops',
    title: 'Cloud DevOps & Infrastructure Engineer',
    company: 'VentureDive',
    category: 'remote',
    industry: 'IT & Enterprise Software',
    department: 'Software & Cloud Engineering',
    location: 'Lahore (Flexible Remote-First across Pakistan)',
    city: 'Remote',
    province: 'Nationwide / Remote',
    stipendOrSalary: 'PKR 180,000 - 280,000 / month',
    currency: 'PKR',
    experience: '1-3 years in Linux sysadmin, Docker, Kubernetes, and AWS',
    education: 'BS in Computer Science, Software Engineering, or IT',
    deadline: 'Batch Hiring',
    logoText: 'VentureDive',
    badgeColor: 'blue',
    description: 'Design automated CI/CD pipelines, Terraform infrastructure as code (IaC), and resilient Kubernetes clusters powering enterprise logistics and mobility apps in Pakistan and Middle East.',
    keyRequirements: [
      'Hands-on experience with Docker, Kubernetes, Helm, and GitHub Actions',
      'Solid command of AWS core services (EKS, EC2, RDS, IAM, S3, VPC networking)',
      'Proficiency in Bash scripting and Python automation'
    ],
    perks: [
      '100% remote flexibility with home broadband electricity backup allowance',
      'Top-of-the-line MacBook Pro provided to all engineers',
      'Bi-annual performance salary increments'
    ],
    applyUrl: 'https://www.venturedive.com/careers'
  },
  {
    id: 'afiniti-ai-engineer',
    title: 'Junior Artificial Intelligence & ML Engineer',
    company: 'Afiniti Pakistan',
    category: 'onsite',
    industry: 'IT & Enterprise Software',
    department: 'Software & Cloud Engineering',
    location: 'Islamabad (Evacuee Trust Complex, F-5/1)',
    city: 'Islamabad',
    province: 'Islamabad (ICT)',
    stipendOrSalary: 'PKR 170,000 - 260,000 / month',
    currency: 'PKR',
    experience: 'Fresh to 2 years in machine learning, mathematics, or data science',
    education: 'BS / MS in Computer Science, Mathematics, or AI (NUST, FAST, GIKI preferred)',
    deadline: 'Immediate',
    logoText: 'Afiniti',
    badgeColor: 'indigo',
    description: 'Work on cutting-edge behavioral pairing algorithms that analyze enterprise telephony data in real time to match callers with optimal contact center agents worldwide.',
    keyRequirements: [
      'Strong mathematical foundations in probability, linear algebra, and statistics',
      'Proficiency in Python (PyTorch, TensorFlow, Scikit-Learn, Pandas, NumPy)',
      'Understanding of model inference latency optimization and feature store pipelines'
    ],
    perks: [
      'Subsidized transport facility across Rawalpindi and Islamabad',
      'International research collaboration opportunities',
      'Comprehensive healthcare and annual corporate bonus'
    ],
    applyUrl: 'https://www.afiniti.com/careers'
  },

  // ==========================================
  // 7. DATA & BUSINESS INTELLIGENCE
  // ==========================================
  {
    id: 'jazz-data-analyst',
    title: 'Data Analyst & Business Intelligence Specialist',
    company: 'Jazz (VEON Group)',
    category: 'onsite',
    industry: 'Telecommunications',
    department: 'Data & Business Intelligence',
    location: 'Islamabad (F-8 Head Office) & Lahore Tech Hub',
    city: 'Islamabad',
    province: 'Islamabad (ICT)',
    stipendOrSalary: 'PKR 130,000 - 190,000 / month',
    currency: 'PKR',
    experience: '1-3 years in data extraction, SQL, and PowerBI dashboards',
    education: 'BS in Computer Science, Data Science, or Economics',
    deadline: 'Active 2026',
    logoText: 'Jazz',
    badgeColor: 'amber',
    description: 'Analyze mobile subscriber churn, JazzCash transaction velocity, and network cell tower data utilization to produce executive dashboards for commercial directors.',
    keyRequirements: [
      'Advanced SQL (CTEs, Window Functions, Partitioning, Query Tuning)',
      'PowerBI / Tableau dashboard architecture with DAX formulas',
      'Basic Python data cleaning skills using Pandas and Jupyter Notebooks'
    ],
    perks: [
      'Free high-speed internet data SIM card and monthly call quota',
      'Hybrid working schedule (up to 3 days work from home)',
      'Comprehensive inpatient/outpatient medical coverage'
    ],
    applyUrl: 'https://jazz.com.pk/careers'
  },
  {
    id: 'careem-bi-associate',
    title: 'Business Intelligence & Marketplace Analyst',
    company: 'Careem Pakistan',
    category: 'remote',
    industry: 'IT & Enterprise Software',
    department: 'Data & Business Intelligence',
    location: 'Karachi / Lahore / 100% Remote',
    city: 'Remote',
    province: 'Nationwide / Remote',
    stipendOrSalary: 'PKR 150,000 - 220,000 / month',
    currency: 'PKR',
    experience: '1-3 years experience in marketplace or consumer analytics',
    education: 'Bachelors in CS, Engineering, Mathematics, or Finance',
    deadline: 'Rolling Intake',
    logoText: 'Careem',
    badgeColor: 'emerald',
    description: 'Deconstruct captain supply-demand elasticity, ride cancellation trends, and food delivery ETA accuracy across major Pakistani metros (Karachi, Lahore, Islamabad, Peshawar).',
    keyRequirements: [
      'Strong command of PostgreSQL / Snowflake and Looker dashboard creation',
      'Statistical hypothesis testing and A/B test experimentation analysis',
      'Clear stakeholder communication to turn data numbers into product roadmap actions'
    ],
    perks: [
      'Careem ride and food monthly promo credits',
      'Flexible remote policy across Pakistan',
      'Competitive equity options / performance bonus'
    ],
    applyUrl: 'https://www.careem.com/careers'
  },

  // ==========================================
  // 8. UI/UX & PRODUCT DESIGN
  // ==========================================
  {
    id: 'sadapay-product-designer',
    title: 'Associate UI/UX & Product Designer',
    company: 'SadaPay',
    category: 'remote',
    industry: 'Banking & FinTech',
    department: 'UI/UX & Product Design',
    location: 'Islamabad / 100% Remote across Pakistan',
    city: 'Remote',
    province: 'Nationwide / Remote',
    stipendOrSalary: 'PKR 140,000 - 220,000 / month',
    currency: 'PKR',
    experience: '1-3 years product design experience with mobile apps',
    education: 'Any Degree / Fine Arts / Human-Computer Interaction / CS',
    deadline: 'Immediate',
    logoText: 'SadaPay',
    badgeColor: 'teal',
    description: 'Design world-class, frictionless mobile banking experiences for Pakistani youth, freelancers, and businesses. Champion simplicity, design systems, and rapid user testing.',
    keyRequirements: [
      'Exceptional Figma craftsmanship (auto-layout, components, variants, prototypes)',
      'Deep understanding of iOS Human Interface Guidelines and Android Material Design',
      'Strong portfolio link showing real-world case studies with problem definitions and results'
    ],
    perks: [
      '100% remote-first culture — work from anywhere in Pakistan',
      'Top-of-the-line MacBook Pro + home office setup stipend',
      'Comprehensive health insurance and generous paid time off'
    ],
    applyUrl: 'https://sadapay.pk/careers'
  },
  {
    id: 'khaadi-brand-designer',
    title: 'Visual Merchandiser & Creative Brand Designer',
    company: 'Khaadi Pakistan',
    category: 'onsite',
    industry: 'Textiles & Apparel Manufacturing',
    department: 'UI/UX & Product Design',
    location: 'Karachi (Khaadi HQ, Korangi) / Lahore Outlets',
    city: 'Karachi',
    province: 'Sindh',
    stipendOrSalary: 'PKR 100,000 - 160,000 / month',
    currency: 'PKR',
    experience: '1-3 years in graphic design, retail visual layout, or digital media',
    education: 'Bachelors in Graphic Design, Fine Arts (IVS, NCA, or equivalent)',
    deadline: 'Active 2026',
    logoText: 'Khaadi',
    badgeColor: 'pink',
    description: 'Design captivating campaign aesthetics, retail store window installations, and digital catalog assets for Pakistan’s iconic fashion and lifestyle brand.',
    keyRequirements: [
      'Mastery of Adobe Creative Suite (Photoshop, Illustrator, InDesign)',
      'Strong eye for color theory, typography, and contemporary Pakistani cultural motifs',
      'Capability to manage tight seasonal launch print production deadlines'
    ],
    perks: [
      'Exclusive Khaadi employee shopping discounts',
      'Company transport facility on major Karachi commuter routes',
      'Subsidized corporate cafeteria and medical cover'
    ],
    applyUrl: 'https://khaadi.com/careers'
  },

  // ==========================================
  // 9. HEALTHCARE, PHARMA & QUALITY ASSURANCE
  // ==========================================
  {
    id: 'getz-pharma-rep',
    title: 'Medical Representative / Territory Field Officer',
    company: 'Getz Pharma (Pvt) Ltd',
    category: 'onsite',
    industry: 'Pharmaceuticals & Healthcare',
    department: 'Quality Assurance & Regulatory',
    location: 'Peshawar (Hayatabad) / Rawalpindi / Abbottabad',
    city: 'Peshawar',
    province: 'Khyber Pakhtunkhwa',
    stipendOrSalary: 'PKR 85,000 - 135,000 / month + Daily Allowance',
    currency: 'PKR',
    experience: 'Fresh Science Graduate to 2 years experience',
    education: 'Pharm-D / BS in Biotechnology, Microbiology, or Chemistry',
    deadline: 'Immediate',
    logoText: 'Getz',
    badgeColor: 'blue',
    description: 'Promote WHO-prequalified pharmaceuticals to doctors, clinic networks, and hospital pharmacies across Peshawar, Mardan, and Abbottabad medical corridors.',
    keyRequirements: [
      'Strong scientific articulation to discuss drug indications, dosage, and clinical trials with physicians',
      'Valid driving license (Motorcycle provided by company)',
      'High persistence and disciplined daily call planning schedule'
    ],
    perks: [
      'Company-provided 125cc/150cc motorcycle + complete daily fuel allowance',
      'Substantial quarterly sales achievement incentives and bonuses',
      'Inpatient/outpatient medical coverage including parents'
    ],
    applyUrl: 'https://getzpharma.com/careers'
  },
  {
    id: 'searle-qa-officer',
    title: 'Quality Assurance & Compliance Chemist',
    company: 'The Searle Company Limited',
    category: 'onsite',
    industry: 'Pharmaceuticals & Healthcare',
    department: 'Quality Assurance & Regulatory',
    location: 'Karachi (SITE Area Plant) & Lahore Plant',
    city: 'Karachi',
    province: 'Sindh',
    stipendOrSalary: 'PKR 95,000 - 150,000 / month',
    currency: 'PKR',
    experience: '1-3 years in pharmaceutical QA/QC laboratories',
    education: 'Pharm-D / MSc in Analytical Chemistry or Biochemistry',
    deadline: 'Active 2026',
    logoText: 'Searle',
    badgeColor: 'teal',
    description: 'Conduct HPLC analytical testing, raw material chemical assay audits, and DRAP (Drug Regulatory Authority of Pakistan) documentation for sterile and solid dosage production.',
    keyRequirements: [
      'Working knowledge of cGMP, US-FDA, and DRAP regulatory guidelines',
      'Hands-on expertise operating HPLC, UV Spectrophotometers, and Dissolution testers',
      'Rigorous record-keeping discipline for batch manufacturing records (BMR)'
    ],
    perks: [
      'Subsidized plant mess and transportation services',
      'Annual pharmaceutical production bonus',
      'Comprehensive hospital insurance and provident fund'
    ],
    applyUrl: 'https://searlecompany.com/careers'
  },

  // ==========================================
  // 10. SALES, CLIENT RELATIONS & TELECOM
  // ==========================================
  {
    id: 'zong-b2b-sales',
    title: 'Corporate B2B Account Manager (Enterprise Solutions)',
    company: 'Zong 4G (China Mobile Pakistan)',
    category: 'onsite',
    industry: 'Telecommunications',
    department: 'Sales & Client Relations',
    location: 'Rawalpindi (CMPak Complex) & Islamabad / Peshawar',
    city: 'Rawalpindi',
    province: 'Punjab',
    stipendOrSalary: 'PKR 115,000 - 180,000 / month + Commissions',
    currency: 'PKR',
    experience: '1-3 years in corporate IT, telecom, or SaaS sales',
    education: 'BBA / BS in Marketing, Telecom, or Business Administration',
    deadline: 'Active 2026',
    logoText: 'Zong',
    badgeColor: 'pink',
    description: 'Pitch enterprise fiber connectivity, cloud IoT solutions, and bulk enterprise data packages to multinational corporations, banks, and government ministries across the twin cities.',
    keyRequirements: [
      'Demonstrated track record of achieving quarterly B2B revenue quotas',
      'Persuasive executive presentation skills and contract negotiation capability',
      'Understanding of corporate RFPs (Request for Proposals) and tender submissions'
    ],
    perks: [
      'Uncapped commission structure on high-value enterprise contracts',
      'Company fuel allowance and corporate smartphone device',
      'Provident fund, gratuity, and family medical cover'
    ],
    applyUrl: 'https://www.zong.com.pk/careers'
  },
  {
    id: 'quetta-banking-officer',
    title: 'Branch Operations Officer & Trade Finance Associate',
    company: 'Meezan Bank Limited',
    category: 'onsite',
    industry: 'Banking & FinTech',
    department: 'Sales & Client Relations',
    location: 'Quetta (Liaquat Bazaar / Jinnah Road Branches)',
    city: 'Quetta',
    province: 'Balochistan',
    stipendOrSalary: 'PKR 85,000 - 130,000 / month',
    currency: 'PKR',
    experience: 'Fresh Graduate to 2 years in retail banking or trade finance',
    education: 'BBA / B.Com / BS in Islamic Banking & Finance or Economics',
    deadline: 'Active 2026',
    logoText: 'Meezan',
    badgeColor: 'emerald',
    description: 'Handle customer relationship management, Islamic Murabaha trade financing, cross-border border trade remittances, and retail cash operations at Pakistan’s premier Islamic bank.',
    keyRequirements: [
      'Sound understanding of Islamic banking concepts (Murabaha, Ijarah, Diminishing Musharakah)',
      'High integrity, compliance mindset, and attention to KYC/AML documentation',
      'Fluency in Urdu; knowledge of Pashto or Balochi is a major advantage for regional customer trust'
    ],
    perks: [
      'Interest-free staff Islamic home and auto financing',
      'Comprehensive hospital insurance for self, spouse, and parents',
      'Annual performance bonus and gratuity benefits'
    ],
    applyUrl: 'https://www.meezanbank.com/careers'
  },
  {
    id: 'gilgit-microfinance-officer',
    title: 'Microfinance Field & Community Enterprise Officer',
    company: 'First MicroFinanceBank (AKDN Group)',
    category: 'onsite',
    industry: 'Banking & FinTech',
    department: 'Sales & Client Relations',
    location: 'Gilgit City & Hunza Regional Branches',
    city: 'Gilgit',
    province: 'Gilgit-Baltistan & AJK',
    stipendOrSalary: 'PKR 75,000 - 115,000 / month + Field Travel',
    currency: 'PKR',
    experience: 'Fresh to 2 years in community development or micro-credit',
    education: 'Bachelors in Economics, Agriculture, Commerce, or Social Sciences',
    deadline: 'Active 2026',
    logoText: 'FMFB',
    badgeColor: 'teal',
    description: 'Empower mountain farming communities, women-led handicraft enterprises, and eco-tourism entrepreneurs with sustainable microcredit loans and financial literacy coaching.',
    keyRequirements: [
      'Deep cultural respect for local mountain communities and ethical finance',
      'Willingness to travel to surrounding valley villages for loan appraisal audits',
      'Basic numeracy and credit repayment tracking skills'
    ],
    perks: [
      'High-altitude / regional climate hardship allowances',
      'Motorcycle fuel allowance for community field visits',
      'AKDN healthcare benefits and life insurance'
    ],
    applyUrl: 'https://fmfb.com.pk/careers'
  },

  // ==========================================
  // 11. GLOBAL REMOTE IN US DOLLARS ($ USD)
  // ==========================================
  {
    id: 'remote-react-usd',
    title: 'Senior / Mid Frontend Engineer ($ USD Contractor)',
    company: 'Turing / Arc.dev Partner (Global Remote)',
    category: 'remote',
    industry: 'IT & Enterprise Software',
    department: 'Software & Cloud Engineering',
    location: '100% Remote (Work from Anywhere in Pakistan)',
    city: 'Remote',
    province: 'Nationwide / Remote',
    stipendOrSalary: '$1,800 - $3,200 / month (~PKR 500,000 - 890,000)',
    currency: 'USD',
    experience: '2-4 years web development experience',
    education: 'Any Degree / Self-Taught / BS Computer Science',
    deadline: 'Always Hiring',
    logoText: 'Global',
    badgeColor: 'emerald',
    description: 'Work with fast-growing Silicon Valley and European tech scale-ups while living in Pakistan. Earn in US Dollars deposited straight into your Pakistani bank account via Wise, Elevate, or Payoneer with 0% PSEB IT export tax.',
    keyRequirements: [
      'Proficiency in React 19, Next.js App Router, TypeScript, and modern state architectures',
      'Fluent written and verbal English for async Slack, Loom video updates, and PR reviews',
      'Disciplined home setup with high-speed fiber internet and uninterrupted solar/UPS backup'
    ],
    perks: [
      'Direct USD salary payout — complete immunity against PKR currency depreciation',
      '100% work from home — save 3+ hours daily commute time and fuel expenses',
      'Annual home workstation & learning equipment budget ($1,200/year)'
    ],
    applyUrl: 'https://www.turing.com'
  },
  {
    id: 'jobrack-project-va',
    title: 'Remote Technical Project Coordinator ($ USD)',
    company: 'Jobrack.eu Client (EU Tech Scale-Up)',
    category: 'remote',
    industry: 'IT & Enterprise Software',
    department: 'Management & Leadership',
    location: '100% Remote (Pakistan)',
    city: 'Remote',
    province: 'Nationwide / Remote',
    stipendOrSalary: '$900 - $1,600 / month (~PKR 250,000 - 445,000)',
    currency: 'USD',
    experience: '1-3 years in project coordination, virtual assistance, or tech support',
    education: 'Bachelors in Any Field / CS / Business / English',
    deadline: 'Rolling Intake',
    logoText: 'Jobrack',
    badgeColor: 'purple',
    description: 'Manage Asana sprint tasks, coordinate client meetings, write user documentation, and follow up with developers for a growing European SaaS company operating on CET time (only 3-4 hours difference from Pakistan).',
    keyRequirements: [
      'Flawless English writing skills with concise business professionalism',
      'High responsiveness and mastery of Notion, Slack, Google Workspace, and Zapier',
      'Punctual reliability during core European business hours (1 PM – 6 PM PKT)'
    ],
    perks: [
      'Stable USD compensation transferred on the 1st of every month',
      'Paid European bank holidays and 20 days annual vacation',
      'Rapid promotion pathway to Operations Manager'
    ],
    applyUrl: 'https://jobrack.eu'
  }
];
