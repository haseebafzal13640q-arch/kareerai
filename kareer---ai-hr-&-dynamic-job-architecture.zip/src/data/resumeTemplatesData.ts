import { ResumeData, ResumeTemplateId } from '../types';

export interface TemplateMetadata {
  id: ResumeTemplateId;
  name: string;
  regionStandard: string;
  bestFor: string;
  description: string;
  previewColor: string;
  features: string[];
}

export const INTERNATIONAL_TEMPLATES: TemplateMetadata[] = [
  {
    id: 'harvard-classic',
    name: 'Harvard Classic ATS',
    regionStandard: 'US Ivy League & Global ATS Standard',
    bestFor: 'Finance, Consulting, Engineering, Multinationals (Nestlé, PepsiCo, Engro)',
    description: 'Gold-standard ATS-friendly layout. Single-column, timeless serif headers, maximum text density, clean horizontal rules, zero graphical elements that confuse ATS parsers.',
    previewColor: '#1e293b',
    features: ['100% ATS Workday/Taleo Score', 'Single-Column Compact Density', 'Action-Verb Bullet Optimization', 'Serif / Modern Clean Balance']
  },
  {
    id: 'fresh-graduate',
    name: 'Student & Fresh Graduate',
    regionStandard: 'Entry-Level & MTO Scheme Standard (Pakistan & Global)',
    bestFor: 'University Students, Recent Grads, Final-Year Projects, Internships',
    description: 'Prioritizes Education, Academic Honors/GPA, Key Coursework, University Societies, and Final Year Projects (FYP) right at the top so employers immediately see academic excellence.',
    previewColor: '#059669',
    features: ['Education & Honors First', 'Final Year Project (FYP) Callout', 'Student Societies & Leadership', 'Internship Focus']
  },
  {
    id: 'silicon-valley',
    name: 'Silicon Valley Tech',
    regionStandard: 'US West Coast & Global Remote Tech',
    bestFor: 'Software Engineers, DevOps, UI/UX, Data Scientists, Remote Tech Roles',
    description: 'Modern, crisp sans-serif design with subtle emerald/slate accent lines, live GitHub/Portfolio link badges, and structured technical stack matrices.',
    previewColor: '#0f766e',
    features: ['GitHub & Portfolio Highlights', 'Categorized Tech Stack Matrix', 'Quantified Metric Callouts', 'Clean Modern Hierarchy']
  },
  {
    id: 'europass-minimal',
    name: 'UK & European Minimalist',
    regionStandard: 'UK, EU, and Gulf / UAE Corporate Standard',
    bestFor: 'Corporate Roles, Supply Chain, Operations, International Relocation',
    description: 'Structured layout with a dedicated left timeline/metadata column, clean typographic boundaries, European corporate standard spacing, and clear chronological flow.',
    previewColor: '#334155',
    features: ['Structured Two-Column Grid', 'Clean Timeline Markers', 'European Corporate Standard', 'Language & Competency Matrix']
  },
  {
    id: 'executive-leadership',
    name: 'Executive & Strategic Lead',
    regionStandard: 'Global Executive Standard',
    bestFor: 'Directors, Senior Managers, Lead Architects, Seasoned Professionals',
    description: 'Features an authoritative Executive Profile summary block, a 3-column "Core Competencies & Strategic Domains" matrix, and highlighted career milestones.',
    previewColor: '#1e1b4b',
    features: ['Executive Summary Banner', 'Core Competencies Grid', 'Key P&L Impact Metrics', 'Board & Strategic Advisory']
  },
  {
    id: 'modern-minimalist',
    name: 'Nordic Modern Minimalist',
    regionStandard: 'Scandinavian & Central European Tech',
    bestFor: 'Product Managers, Tech Scale-ups, Fintech, Creative Technologists',
    description: 'Ultra-sleek typography with refined line dividers, elegant letter-spacing, high whitespace balance, and clean single-page density.',
    previewColor: '#0284c7',
    features: ['Crisp Line Dividers', 'High Whitespace Legibility', 'Modern Typographic Hierarchy', 'Compact Multi-Skill Grid']
  },
  {
    id: 'creative-portfolio',
    name: 'Creative & Brand Showcase',
    regionStandard: 'Global Creative & Marketing Standard',
    bestFor: 'Brand Managers (Nestlé/Pepsi), UI/UX Designers, Growth Marketers, Media',
    description: 'Dual-panel format with an elegant left metadata sidebar (Contact, Stack, Tools, Languages) and expansive right canvas for campaigns, case studies, and projects.',
    previewColor: '#7c3aed',
    features: ['Dual-Panel Sidebar Layout', 'Campaign & Project Showcase', 'Visual Tool Badges', 'Marketing Impact Focus']
  },
  {
    id: 'academic-research',
    name: 'Academic & Scholar CV',
    regionStandard: 'Higher Studies & Scholarship Standard (Fulbright, DAAD, Erasmus)',
    bestFor: 'Postgrad Applicants, Research Assistants, Teaching Fellows, Lab Scholars',
    description: 'Comprehensive academic format prioritizing Publications, Teaching Assistantships, Thesis Research, Conference Presentations, and Faculty References.',
    previewColor: '#b45309',
    features: ['Research & Thesis Priority', 'Teaching Assistant Callouts', 'Publications & Conferences', 'Scholarship Ready']
  }
];

export const SAMPLE_RESUMES: Record<string, { label: string; data: ResumeData }> = {
  'fresh-student': {
    label: '🎓 Fresh University Student / Graduate',
    data: {
      personalInfo: {
        fullName: 'Zainab Ahmed',
        title: 'BS Computer Science Graduate | Aspiring Full-Stack & AI Engineer',
        email: 'zainab.ahmed@example.com',
        phone: '+92 300 1234567',
        location: 'Lahore, Pakistan (Open to Hybrid & Remote)',
        linkedin: 'linkedin.com/in/zainab-ahmed-pk',
        github: 'github.com/zainabahmed-dev',
        portfolio: 'zainabahmed.dev'
      },
      summary:
        'Motivated Computer Science graduate from FAST-NUCES (CGPA: 3.74/4.00) with proven full-stack and machine learning project experience. Winner of FAST Developer Hackathon 2025. Seeking an entry-level Software Engineer or Management Trainee role in a high-growth technology firm or multinational to deploy scalable cloud software and AI-augmented features.',
      education: [
        {
          id: 'edu-1',
          degree: 'Bachelor of Science in Computer Science (BS CS)',
          institution: 'FAST National University of Computer & Emerging Sciences (NUCES)',
          location: 'Lahore, Pakistan',
          graduationYear: '2022 - 2026',
          gpaOrHonors: 'CGPA: 3.74 / 4.00 (Dean’s Honor List: 5 Consecutive Semesters)',
          details: 'Core Coursework: Data Structures & Algorithms, Distributed Systems, Database Architecture, Machine Learning, Cloud Computing, Software Engineering.'
        },
        {
          id: 'edu-2',
          degree: 'F.Sc. Pre-Engineering (Higher Secondary School Certificate)',
          institution: 'Punjab Group of Colleges',
          location: 'Lahore, Pakistan',
          graduationYear: '2020 - 2022',
          gpaOrHonors: 'Marks: 1042 / 1100 (Grade: A1 / Distinction)'
        }
      ],
      experience: [
        {
          id: 'exp-1',
          jobTitle: 'Software Engineering Intern',
          company: 'Systems Limited',
          location: 'Lahore, Pakistan',
          startDate: 'Jun 2025',
          endDate: 'Aug 2025',
          isCurrent: false,
          bullets: [
            'Engineered RESTful backend microservices in Node.js and TypeScript for an enterprise logistics client, reducing payload transmission latency by 28%.',
            'Implemented automated unit testing with Jest achieving 88% branch coverage, eliminating 14 regressions prior to user acceptance testing (UAT).',
            'Collaborated in daily agile standups with senior architects, presenting weekly sprint demos to international client stakeholders.'
          ]
        },
        {
          id: 'exp-2',
          jobTitle: 'Lead Teaching Assistant (Data Structures & OOP)',
          company: 'FAST-NUCES Department of CS',
          location: 'Lahore, Pakistan',
          startDate: 'Sep 2024',
          endDate: 'May 2025',
          isCurrent: false,
          bullets: [
            'Mentored 120+ sophomore students through bi-weekly programming lab sessions in C++ and Python, improving average lab exam scores by 16%.',
            'Developed automated test-bench scripts to evaluate algorithmic correctness and memory leak detection across 200+ student repository submissions.'
          ]
        }
      ],
      projects: [
        {
          id: 'proj-1',
          name: 'AI-Powered Resume & Skill Gap Analyzer (Final Year Project)',
          role: 'Lead Full-Stack Architect',
          technologies: 'React, TypeScript, Python FastAPI, PostgreSQL, Gemini API, Docker',
          link: 'github.com/zainabahmed-dev/career-intel',
          bullets: [
            'Built an end-to-end ATS resume analysis platform processing PDF resumes and computing cosine similarity against job descriptions in under 1.8 seconds.',
            'Containerized application with Docker and orchestrated deployment on Google Cloud Run with automated GitHub Actions CI/CD.',
            'Awarded 1st Place at Annual FAST Capstone Project Exhibition out of 85 participating engineering teams.'
          ]
        },
        {
          id: 'proj-2',
          name: 'Campus RideShare & Carpool Mobile Application',
          role: 'Mobile Developer',
          technologies: 'Flutter, Firebase Firestore, Google Maps API',
          link: 'github.com/zainabahmed-dev/campus-ride',
          bullets: [
            'Created secure student ride-sharing application with real-time GPS tracking and university email verification, reaching 450+ active campus testers.'
          ]
        }
      ],
      skills: {
        technical: ['Python', 'TypeScript / JavaScript', 'React / Next.js', 'Node.js', 'C++', 'SQL (PostgreSQL)', 'RESTful APIs'],
        tools: ['Git & GitHub', 'Docker', 'Postman', 'VS Code', 'Linux / Bash', 'Figma', 'Google Cloud Platform (GCP)'],
        soft: ['Structured Problem Solving', 'Clear Technical Communication', 'Agile Teamwork', 'Fast Autonomous Learning']
      },
      certifications: [
        {
          id: 'cert-1',
          name: 'Meta Front-End Developer Professional Certificate',
          issuer: 'Coursera / Meta',
          year: '2025'
        },
        {
          id: 'cert-2',
          name: 'Google Data Analytics Professional Certificate',
          issuer: 'Google',
          year: '2024'
        }
      ],
      languages: ['English (Fluent / Professional)', 'Urdu (Native / Bilingual)']
    }
  },
  'mto-candidate': {
    label: '🏢 FMCG Management Trainee (Nestlé / PepsiCo / Engro)',
    data: {
      personalInfo: {
        fullName: 'Bilal Farooq',
        title: 'BBA Honors Graduate | Management Trainee & Commercial Strategy Specialist',
        email: 'bilal.farooq@example.com',
        phone: '+92 321 9876543',
        location: 'Karachi, Pakistan (Willing to Relocate Nationwide)',
        linkedin: 'linkedin.com/in/bilal-farooq-mto',
        portfolio: ''
      },
      summary:
        'High-performing BBA (Honors) graduate from IBA Karachi (Major in Marketing & Supply Chain) with experience in FMCG commercial internships and brand activation. Proven track record in retail market audits, distributor margin modeling, and consumer research. Seeking a Management Trainee (MTO) role at Nestlé, PepsiCo, Engro, or Unilever to drive operational excellence and revenue growth.',
      education: [
        {
          id: 'edu-1',
          degree: 'Bachelor of Business Administration (BBA Hons)',
          institution: 'Institute of Business Administration (IBA)',
          location: 'Karachi, Pakistan',
          graduationYear: '2022 - 2026',
          gpaOrHonors: 'CGPA: 3.68 / 4.00 (Dean’s List for Academic Merit)',
          details: 'President, IBA Marketing Club. Led 14 national corporate brand engagement events.'
        }
      ],
      experience: [
        {
          id: 'exp-1',
          jobTitle: 'Commercial & Trade Marketing Intern',
          company: 'Nestlé Pakistan',
          location: 'Karachi, Pakistan',
          startDate: 'Jun 2025',
          endDate: 'Aug 2025',
          isCurrent: false,
          bullets: [
            'Conducted nationwide retail audit across 85 Tier-1 modern trade and general trade stores, analyzing on-shelf availability and competitor pricing for dairy portfolio.',
            'Collaborated with regional trade marketing managers to redesign POSM (Point of Sale Materials), boosting secondary sales velocity by 11% across pilot stores.',
            'Automated daily distributor dispatch and inventory tracking using advanced Excel and PowerBI, saving 8 manual hours weekly for the commercial field team.'
          ]
        },
        {
          id: 'exp-2',
          jobTitle: 'Supply Chain Operations Trainee',
          company: 'Engro Corporation',
          location: 'Karachi, Pakistan',
          startDate: 'Jul 2024',
          endDate: 'Aug 2024',
          isCurrent: false,
          bullets: [
            'Analyzed logistics transportation routes from Port Qasim distribution centers, identifying route consolidation opportunities that saved PKR 1.6M in quarterly freight costs.',
            'Co-authored 12 standard operating procedures (SOPs) for warehouse temperature audits, achieving 100% compliance during internal quality reviews.'
          ]
        }
      ],
      projects: [
        {
          id: 'proj-1',
          name: 'FMCG Rural Market Penetration Strategy (IBA Capstone)',
          role: 'Team Lead',
          technologies: 'Market Research, Nielsen Retail Data, Financial Modeling, PowerBI',
          bullets: [
            'Formulated complete business plan for affordable single-serve nutritional sachets in interior Sindh, modeling distribution economics and breaking even within 14 months.'
          ]
        }
      ],
      skills: {
        technical: ['P&L Financial Modeling', 'Retail Audit Analysis', 'Data Visualization (PowerBI)', 'Market Research Methodologies'],
        tools: ['Microsoft Excel (Advanced: VBA, Pivot, Solver)', 'SAP ERP Fundamentals', 'Tableau', 'PowerPoint / Executive Pitching'],
        soft: ['Assertive Stakeholder Leadership', 'Resilience in High-Pressure Rotations', 'Negotiation', 'Strategic Problem Solving']
      },
      certifications: [
        {
          id: 'cert-1',
          name: 'McKinsey Forward Leadership Program',
          issuer: 'McKinsey & Company',
          year: '2025'
        },
        {
          id: 'cert-2',
          name: 'Lean Six Sigma White Belt',
          issuer: 'Six Sigma Institute',
          year: '2024'
        }
      ],
      languages: ['English (Fluent)', 'Urdu (Native)', 'Sindhi (Conversational)']
    }
  },
  'software-engineer': {
    label: '💻 Senior / Mid Software Engineer (Global & Remote)',
    data: {
      personalInfo: {
        fullName: 'Hamza Tariq',
        title: 'Senior Full-Stack Engineer | React, Node.js & Distributed Systems',
        email: 'hamza.tariq@example.com',
        phone: '+92 333 4455667',
        location: 'Islamabad, Pakistan (Open to Global Remote in USD)',
        linkedin: 'linkedin.com/in/hamza-tariq-dev',
        github: 'github.com/hamzatariq-eng',
        portfolio: 'hamzatariq.com'
      },
      summary:
        'Senior Software Engineer with 5+ years of experience architecting high-throughput distributed web applications and modern React/Next.js interfaces. Scaled fintech microservices to 2.5M+ active users. Deep expertise in PostgreSQL performance optimization, Docker, Kubernetes, and event-driven architectures. Proven track record in remote cross-timezone collaboration with US and European engineering teams.',
      education: [
        {
          id: 'edu-1',
          degree: 'BS in Computer Software Engineering',
          institution: 'NUST (National University of Sciences & Technology)',
          location: 'Islamabad, Pakistan',
          graduationYear: '2016 - 2020',
          gpaOrHonors: 'CGPA: 3.82 / 4.00 (Magna Cum Laude)'
        }
      ],
      experience: [
        {
          id: 'exp-1',
          jobTitle: 'Senior Full-Stack Engineer',
          company: 'RemotelyHQ (US Tech Client)',
          location: 'Remote (US Eastern Time)',
          startDate: 'Jan 2023',
          endDate: 'Present',
          isCurrent: true,
          bullets: [
            'Architected and delivered multi-tenant billing engine using Node.js, Stripe API, and PostgreSQL, processing $4.2M in monthly recurring revenue with 99.99% idempotency.',
            'Refactored legacy monolith into event-driven serverless microservices on AWS Lambda and SQS, slashing p99 API latency from 680ms to 95ms.',
            'Mentored 6 junior and mid-level engineers across 3 continents, establishing automated PR review checklists and static security linting.'
          ]
        },
        {
          id: 'exp-2',
          jobTitle: 'Software Engineer',
          company: 'Afiniti / VentureDive',
          location: 'Islamabad, Pakistan',
          startDate: 'Aug 2020',
          endDate: 'Dec 2022',
          isCurrent: false,
          bullets: [
            'Built responsive design system and core banking dashboard in React, TypeScript, and Redux Toolkit, adopted by 800k+ active mobile and web banking users.',
            'Optimized complex SQL queries and created composite indexes on high-volume transactions table, reducing database CPU load by 38% during peak payroll cycles.',
            'Authored comprehensive automated Cypress integration test suite, reducing release regression incidents by 45%.'
          ]
        }
      ],
      projects: [
        {
          id: 'proj-1',
          name: 'Distributed Rate Limiter & Token Bucket Gateway',
          role: 'Creator & Maintainer',
          technologies: 'Go, Redis, Docker, GitHub Actions',
          link: 'github.com/hamzatariq-eng/go-ratelimit',
          bullets: [
            'Open-source rate limiting middleware handling 100k requests/second with sub-millisecond Redis synchronization; earned 850+ GitHub stars.'
          ]
        }
      ],
      skills: {
        technical: ['TypeScript / JavaScript', 'React / Next.js', 'Node.js / Express', 'Go (Golang)', 'PostgreSQL', 'Redis', 'GraphQL / REST'],
        tools: ['Docker & Kubernetes', 'AWS (EC2, S3, RDS, Lambda)', 'GitHub Actions CI/CD', 'Terraform', 'Datadog', 'TailwindCSS'],
        soft: ['Asynchronous Remote Collaboration', 'Technical RFC Architecture', 'Mentorship & Code Review', 'Incident Post-Mortems']
      },
      certifications: [
        {
          id: 'cert-1',
          name: 'AWS Certified Solutions Architect – Associate',
          issuer: 'Amazon Web Services',
          year: '2024'
        }
      ],
      languages: ['English (Full Professional Proficiency)', 'Urdu (Native)']
    }
  }
};

export const ACTION_VERBS_BY_CATEGORY = {
  leadership: ['Architected', 'Spearheaded', 'Directed', 'Championed', 'Orchestrated', 'Mobilized', 'Empowered'],
  engineering: ['Engineered', 'Refactored', 'Deployed', 'Automated', 'Containerized', 'Constructed', 'Implemented'],
  optimization: ['Accelerated', 'Streamlined', 'Eliminated', 'Minimized', 'Maximized', 'Consolidated', 'Standardized'],
  analytics: ['Quantified', 'Diagnosed', 'Forecasted', 'Uncovered', 'Synthesized', 'Audited', 'Modelled'],
  growth: ['Generated', 'Expanded', 'Captured', 'Boosted', 'Elevated', 'Acquired', 'Penetrated']
};
