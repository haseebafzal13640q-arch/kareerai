export interface JobPreset {
  id: string;
  title: string;
  roleTitle: string;
  industry: string;
  companyType: string;
  region: string;
  experienceLevel: string;
  workMode: string;
  customContext: string;
}

export const JOB_PRESETS: JobPreset[] = [
  {
    id: 'nestle-mgmt-trainee',
    title: 'Nestlé Pakistan - Management Trainee (HR / Supply Chain)',
    roleTitle: 'Management Trainee Officer (MTO)',
    industry: 'FMCG & Consumer Goods',
    companyType: 'Nestlé Pakistan (Multinational Leader)',
    region: 'Pakistan (Lahore Head Office - Onsite PKR)',
    experienceLevel: 'Fresh Graduate / Student (0-1 yr)',
    workMode: 'Onsite (Lahore 308 Upper Mall)',
    customContext: 'Rotational MTO program across supply chain, talent acquisition, and manufacturing. High-energy fresh graduates from LUMS, IBA, NUST, FAST.',
  },
  {
    id: 'pepsi-brand-intern',
    title: 'PepsiCo Pakistan - Marketing & Brand Intern',
    roleTitle: 'Brand Marketing & Digital Intern',
    industry: 'Beverages & Snacks (PepsiCo)',
    companyType: 'PepsiCo Pakistan (Gulberg Lahore)',
    region: 'Pakistan (Lahore - Onsite PKR)',
    experienceLevel: 'Student / Internship (0 yrs)',
    workMode: 'Onsite / Hybrid (Lahore)',
    customContext: 'Supporting brand campaigns for Lay’s, Kurkure, and Pepsi Max. Market research, campus activations, and digital agency coordination.',
  },
  {
    id: 'systems-software-dev',
    title: 'Systems Limited - Associate Software Engineer (PKR)',
    roleTitle: 'Associate Full-Stack Developer',
    industry: 'Enterprise Software & IT Export',
    companyType: 'Systems Limited (Pakistan Premier Tech)',
    region: 'Pakistan (Lahore / Karachi / Islamabad PKR)',
    experienceLevel: 'Junior / Fresh Graduate (0-2 yrs)',
    workMode: 'Hybrid (Lahore Tech Vista)',
    customContext: 'Enterprise cloud services, .NET Core, React, and cloud migrations. Comprehensive training bootcamps for student engineers.',
  },
  {
    id: 'jazz-remote-data',
    title: 'Jazz (VEON) - Remote Data & Business Analyst',
    roleTitle: 'Junior Data Analyst (Remote)',
    industry: 'Telecommunications & FinTech (JazzCash)',
    companyType: 'Jazz (VEON Group)',
    region: 'Pakistan (100% Remote PKR)',
    experienceLevel: 'Early Career (1-3 yrs)',
    workMode: '100% Remote (Anywhere in Pakistan)',
    customContext: 'SQL querying, PowerBI dashboards, customer churn analysis for JazzCash & digital subscribers. Internet & power backup allowances provided.',
  },
  {
    id: 'global-remote-usd',
    title: 'Global Remote Tech - React/Node Engineer ($ USD)',
    roleTitle: 'Remote Full-Stack Developer',
    industry: 'Global SaaS & Cloud',
    companyType: 'International Remote Startup (US/Europe)',
    region: 'Global Remote (USD)',
    experienceLevel: 'Mid-Senior (2-5 yrs)',
    workMode: '100% Work from Home (USD Salary)',
    customContext: 'Asynchronous workflows, GitHub pull requests, high dollar compensation directly into Pakistani bank accounts via Wise / Payoneer.',
  }
];

export const SAMPLE_RESUMES = {
  softwareEngineer: `John Doe - Senior Software Engineer
Email: johndoe@example.com | GitHub: github.com/johndoe | LinkedIn: linkedin.com/in/johndoe
Location: Lahore, Pakistan (Available for Global Remote)

SUMMARY:
Software Engineer with 5 years of experience in JavaScript, React, Node.js, and cloud services. Experienced in building responsive web applications, collaborating with teams, and maintaining backend APIs.

WORK EXPERIENCE:
Software Engineer | DevCorp Technologies | 2022 - Present
- Responsible for developing web applications and fixing bugs for client projects.
- Helped the team migrate old databases to modern cloud services.
- Worked with team members to conduct code reviews and improve code quality.
- Maintained REST APIs and wrote documentation for frontend developers.
- Built features for e-commerce checkout using React and Redux.

Associate Developer | CloudWave Solutions | 2020 - 2022
- Created landing pages and dashboard widgets for internal portals.
- Assisted senior engineers in debugging Node.js API endpoints.
- Participated in weekly agile standups and sprint planning sessions.

SKILLS:
Languages & Frameworks: JavaScript, TypeScript, React, HTML5, CSS3, Node.js, Express, MongoDB, PostgreSQL.
Tools: Git, Docker, Postman, VS Code, Jira.`,

  hrProfessional: `Fatima Zahra - People Operations & HR Specialist
Email: fatima.zahra@example.com | Location: Karachi, Pakistan

SUMMARY:
Dedicated Human Resources Specialist with 4 years of experience handling employee recruitment, onboarding, payroll coordination, and company policy administration. Passionate about talent engagement and workforce retention.

EXPERIENCE:
HR Specialist | Apex Logistics Pakistan | 2022 - Present
- Handled recruitment for engineering, sales, and customer support departments.
- Responsible for onboarding new joiners and setting up their accounts and welcome kits.
- Managed employee attendance, leave records, and monthly payroll coordination.
- Coordinated company annual events, quarterly team outings, and employee wellness workshops.
- Resolved employee grievances and conducted exit interviews.

HR Assistant | Horizon Media Group | 2020 - 2022
- Screened resumes on job portals and scheduled candidate interviews.
- Maintained physical and digital employee personnel files in compliance with labor policies.
- Assisted HR manager in drafting job advertisements and company memos.

SKILLS & CERTIFICATIONS:
Talent Sourcing, HRIS Systems, Employee Engagement, Onboarding, Basic Labor Law Understanding, SHRM-CP in progress.`,

  productManager: `Ali Khan - Digital Product Manager
Location: Islamabad, Pakistan / Global Remote

SUMMARY:
Product Manager with 4+ years leading cross-functional teams across fintech and SaaS products. Skilled in agile methodologies, product discovery, user research, and roadmap execution.

EXPERIENCE:
Product Manager | FinEdge Digital | 2022 - Present
- Managed product roadmap for digital mobile wallet feature.
- Worked with UX designers and developers to ship 15 product releases.
- Collected user feedback and converted requirements into user stories in Jira.
- Monitored key product metrics such as daily active users and retention.

Associate Product Manager | VentureTech Labs | 2020 - 2022
- Conducted competitor analysis for new B2B SaaS product offerings.
- Supported Senior PM in backlog grooming and sprint retrospective facilitation.
- Analyzed Google Analytics traffic and user conversion funnels.

SKILLS:
Agile Scrum, Product Discovery, Jira/Confluence, User Journey Mapping, Wireframing (Figma), Mixpanel, SQL basics.`
};

export const MARKET_BENCHMARKS = [
  {
    region: 'Pakistan (PKR)',
    currency: 'PKR',
    flag: '🇵🇰',
    tierLevels: [
      { level: 'Junior (1-3 yrs)', range: 'PKR 120,000 - 220,000 / mo', usdApprox: '$430 - $790 / mo' },
      { level: 'Mid-Level (3-5 yrs)', range: 'PKR 250,000 - 450,000 / mo', usdApprox: '$900 - $1,600 / mo' },
      { level: 'Senior (5-8 yrs)', range: 'PKR 450,000 - 800,000 / mo', usdApprox: '$1,620 - $2,870 / mo' },
      { level: 'Lead / Principal (8+ yrs)', range: 'PKR 850,000 - 1,500,000+ / mo', usdApprox: '$3,000 - $5,400+ / mo' },
    ],
    commonPerks: [
      'Provident Fund / Gratuity (matching 5% - 8.33%)',
      'Comprehensive IPD & OPD Medical Insurance for family',
      'High-speed Internet & Generator/UPS backup stipend',
      'Fuel / Mobile allowance & Annual performance bonus',
      'Inflation-adjusted bi-annual salary reviews'
    ],
    marketContext: 'Pakistan’s top software engineers, architects, and HR leaders are increasingly benchmarking against global remote USD salaries. Local Tier-1 tech firms in Lahore, Karachi, and Islamabad offer USD-pegged or inflation-hedged PKR packages to retain elite talent.'
  },
  {
    region: 'Global Remote (USD)',
    currency: 'USD',
    flag: '🌐',
    tierLevels: [
      { level: 'Junior (1-3 yrs)', range: '$50,000 - $75,000 / yr', usdApprox: '$4,100 - $6,250 / mo' },
      { level: 'Mid-Level (3-5 yrs)', range: '$80,000 - $120,000 / yr', usdApprox: '$6,600 - $10,000 / mo' },
      { level: 'Senior (5-8 yrs)', range: '$120,000 - $165,000 / yr', usdApprox: '$10,000 - $13,750 / mo' },
      { level: 'Staff / Principal (8+ yrs)', range: '$170,000 - $240,000+ / yr', usdApprox: '$14,100 - $20,000+ / mo' },
    ],
    commonPerks: [
      'Equity / Stock Options (0.05% - 0.5% depending on stage)',
      'Global Health Insurance (via SafetyWing / RemotePass)',
      '$1,500 - $3,000 one-time home office setup stipend',
      'Annual Learning & Conference Budget ($1,500 - $3,000)',
      'Flexible asynchronous hours & Coworking space allowance'
    ],
    marketContext: 'Remote-first organizations hire on global competence. Compensation models either follow geo-neutral bands (Silicon Valley/EU benchmarks) or local-cost-of-living multiplier models.'
  },
  {
    region: 'United Arab Emirates / GCC (AED)',
    currency: 'AED',
    flag: '🇦🇪',
    tierLevels: [
      { level: 'Junior (1-3 yrs)', range: 'AED 9,000 - 16,000 / mo', usdApprox: '$2,450 - $4,350 / mo' },
      { level: 'Mid-Level (3-5 yrs)', range: 'AED 18,000 - 32,000 / mo', usdApprox: '$4,900 - $8,700 / mo' },
      { level: 'Senior (5-8 yrs)', range: 'AED 32,000 - 50,000 / mo', usdApprox: '$8,700 - $13,600 / mo' },
      { level: 'Director / Exec (8+ yrs)', range: 'AED 52,000 - 85,000+ / mo', usdApprox: '$14,150 - $23,100+ / mo' },
    ],
    commonPerks: [
      '0% Personal Income Tax (Net equals Gross)',
      'Comprehensive UAE-compliant Health Insurance',
      'Annual roundtrip flight tickets home for employee and dependents',
      'End of Service Gratuity (mandatory by UAE Labor Law)',
      'Schooling allowance support for senior/executive roles'
    ],
    marketContext: 'Dubai and Riyadh have emerged as major tech and digital hubs. High disposable income due to zero personal tax, but housing and international schooling costs require solid basic salary structures.'
  },
  {
    region: 'United Kingdom (GBP)',
    currency: 'GBP',
    flag: '🇬🇧',
    tierLevels: [
      { level: 'Junior (1-3 yrs)', range: '£32,000 - £48,000 / yr', usdApprox: '$3,400 - $5,100 / mo' },
      { level: 'Mid-Level (3-5 yrs)', range: '£50,000 - £75,000 / yr', usdApprox: '$5,300 - $8,000 / mo' },
      { level: 'Senior (5-8 yrs)', range: '£78,000 - £110,000 / yr', usdApprox: '$8,300 - $11,700 / mo' },
      { level: 'Staff / Head (8+ yrs)', range: '£115,000 - £160,000+ / yr', usdApprox: '$12,200 - $17,000+ / mo' },
    ],
    commonPerks: [
      'Workplace Pension Scheme (minimum 3% employer contribution)',
      '25-30 days statutory paid annual leave + 8 Bank Holidays',
      'Private Healthcare & Dental plan supplements',
      'Cycle to Work scheme & Commuter transport benefits',
      'Electric Vehicle (EV) salary sacrifice schemes'
    ],
    marketContext: 'London commands an approximate 15-25% premium compared to regional UK hubs (Manchester, Edinburgh, Birmingham). Strong labor protections and statutory benefits.'
  }
];
