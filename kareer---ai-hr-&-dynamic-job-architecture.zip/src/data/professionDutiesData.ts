import { ProfessionDutyData } from '../types';

export const PROFESSIONS_DATA: ProfessionDutyData[] = [
  // 1. MANAGEMENT TRAINEE OFFICER (MTO)
  {
    id: 'management-trainee-mto',
    title: 'Management Trainee Officer (MTO)',
    category: 'Multinationals & Corporate Leadership',
    badge: 'Top Choice for Pakistani Graduates',
    summary:
      'A cross-functional leadership incubation role in leading FMCGs and conglomerates (Nestlé, PepsiCo, Engro, Unilever, British American Tobacco). Rotates across Supply Chain, Commercial, Marketing, and Operations to cultivate future executive leaders.',
    primaryResponsibilities: [
      'Executed 3 high-impact cross-departmental rotational projects across Commercial, Operations, and Supply Chain, driving a 14% improvement in process turnaround time.',
      'Conducted root-cause analysis on retail distributor stock-outs, collaborating with territory managers to optimize delivery schedules and reduce inventory loss by PKR 2.4M.',
      'Synthesized market consumer insights across urban Tier-1 retail channels to pitch innovative trade marketing activations directly to the Executive Leadership Committee.',
      'Designed and standardized internal Standard Operating Procedures (SOPs) for field sales monitoring, decreasing reporting discrepancies by 28%.',
      'Spearheaded sustainability and waste-reduction initiatives in factory packaging lines, reducing non-recyclable material usage by 9% year-on-year.'
    ],
    dailyTasks: [
      'Participate in daily operational syncs with factory managers, brand leads, or logistics supervisors.',
      'Track and analyze primary and secondary sales volumes using ERP tools (SAP, PowerBI).',
      'Conduct field visits to wholesale markets and retail outlets to audit shelf share and competitor pricing.',
      'Prepare weekly executive milestone decks and present recommendations to business unit heads.',
      'Collaborate with HR business partners on leadership development KPIs and project assessments.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Advanced Microsoft Excel (VLOOKUP, INDEX/MATCH, Pivot Tables, Sensitivity Analysis)',
        'Business Case Financial Modeling & ROI Calculation',
        'Data Visualization & Executive Dashboarding (PowerBI or Tableau)',
        'Structured Problem Solving (MECE Framework & Root Cause Analysis)'
      ],
      essentialSoftSkills: [
        'Resilience & High Adaptability to Fast Rotations',
        'Exceptional Executive Presentation & Storytelling',
        'Assertive Stakeholder Management & Conflict Resolution',
        'Uncompromising Ownership & Bias for Action'
      ],
      techStackOrTools: ['SAP S/4HANA', 'Microsoft 365 / PowerBI', 'Tableau', 'Canva / Pitch', 'Asana / Trello'],
      redFlagsAndDealbreakers: [
        'Purely theoretical mindset unable to handle factory floors or retail wholesale market heat.',
        'Lack of quantitative backing during behavioral interviews (unable to explain metrics).',
        'Inflexible attitude toward geographical relocation across factory sites (e.g., Sheikhupura, Multan, Port Qasim, Sukkur).',
        'Passive communication or inability to speak confidently before C-suite leaders.'
      ],
      typicalInterviewFocus: [
        'Assessment Center Case Studies: "Distributor network is losing margin in North Region—diagnose and fix within 6 months."',
        'Behavioral STAR Questions: "Tell us about a time you led a team without formal authority."',
        'Numerical & Logical Reasoning psychometric assessments (SHL / Pymetrics).'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'Bachelors or Masters degree (BBA, MBA, BS Computer Science, Industrial/Mechanical/Chemical Engineering)',
        'Graduating from accredited universities (LUMS, IBA, NUST, FAST, GIKI, Lahore School, Punjab University, etc.)',
        'Minimum CGPA generally $\\ge 3.00/4.00$ or upper-second class honors'
      ],
      experiencePrerequisites: [
        '0 to 1 year of post-graduation experience (strict fresh graduate cap in most FMCGs)',
        'Demonstrable leadership roles in student societies, debate circuits, or social entrepreneurship capstones',
        'Prior summer internship experience at reputable corporate or startup organizations'
      ],
      workEnvironmentContext:
        'Dynamic hybrid environment: corporate headquarters, modern air-conditioned office suites, active factory manufacturing plant floors (noise, industrial safety gear required), and outdoor retail wholesale market visits.',
      regulatoryAndComplianceStandards: [
        'Pakistan Labor Laws & Industrial Safety Guidelines',
        'Corporate Governance Code (Securities & Exchange Commission of Pakistan - SECP)',
        'ISO 9001 (Quality) and ISO 14001 (Environmental Management) standards',
        'Foreign Corrupt Practices Act (FCPA) & Antitrust Commercial Compliance'
      ],
      cognitiveAndPhysicalDemands: [
        'High cognitive agility to absorb new departmental jargon and processes every 3-4 months',
        'Physical stamina for plant tours and high-temperature wholesale market field audits',
        'Stamina for rapid context switching and executive presentation under scrutiny'
      ]
    },
    transferableSkills: [
      {
        skill: 'Cross-Functional Stakeholder Alignment',
        description: 'Ability to orchestrate work across sales, finance, engineering, and factory teams that hold competing priorities.',
        crossIndustryApplication: 'Applicable in Tech Product Management, Management Consulting, Healthcare Ops, and Government Policy.',
        howToDemonstrateInResume: 'Led 4-department task force across Supply Chain and Brand Marketing to align product rollout timeline, accelerating launch by 3 weeks.'
      },
      {
        skill: 'Root-Cause Problem Decomposition',
        description: 'Deconstructing ambiguous corporate losses into MECE (Mutually Exclusive, Collectively Exhaustive) hypotheses.',
        crossIndustryApplication: 'Directly transferable to Investment Banking, Software Architecture, and Operations Strategy.',
        howToDemonstrateInResume: 'Identified root cause of 18% inventory variance by synthesizing warehouse logs, reducing audit anomalies to under 2%.'
      },
      {
        skill: 'Data-Driven Executive Storytelling',
        description: 'Transforming complex ERP raw data into high-stakes executive slides with clear financial action steps.',
        crossIndustryApplication: 'Essential for any leadership or client-facing consulting engagement.',
        howToDemonstrateInResume: 'Delivered quarterly business review to Executive Committee, securing PKR 12M budget approval for distributor automation pilot.'
      }
    ],
    keyPerformanceIndicators: [
      'On-time delivery and operational ROI of rotational capstone projects',
      'Distributor satisfaction index and stock-out mitigation rate',
      'Leadership competency rating assessed by cross-functional department heads',
      'Cost-saving initiatives delivered during factory/supply chain rotations'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 140,000 - 230,000 / month (Plus 1000cc-1300cc company car, fuel & medical)',
      globalUSD: '$45,000 - $70,000 / year (International Graduate Scheme)'
    },
    careerProgression: [
      'Management Trainee (Year 1)',
      'Assistant Manager / Territory Manager (Years 2-3)',
      'Manager / Category Lead (Years 4-6)',
      'Department Head / Commercial Director (Years 7+)'
    ],
    recommendedCertifications: [
      'Google Project Management Professional Certificate',
      'McKinsey Forward Leadership Program',
      'Lean Six Sigma Green Belt',
      'CFA Level 1 (for Finance MTOs)'
    ]
  },

  // 2. HUMAN RESOURCE MANAGER & STRATEGIC HRBP
  {
    id: 'hr-manager-people-ops',
    title: 'Human Resource Manager & Strategic HRBP',
    category: 'Human Resources & Corporate Strategy',
    badge: 'Core Corporate Anchor',
    summary:
      'Architects organizational design, talent retention policies, compensation matrices, and workplace culture. Serves as strategic business advisor to C-suite executives while maintaining compliance with Pakistani labor statutes.',
    primaryResponsibilities: [
      'Engineered enterprise performance evaluation rubric across 650+ employees, replacing subjective grading with OKR benchmarks and elevating promotion fairness index by 34%.',
      'Formulated annualized talent retention strategy reducing voluntary high-performer attrition from 19% to 7.8% across technical engineering departments.',
      'Directed total compensation benchmarking against peer multinationals, structuring PKR currency inflation cushioning allowances and medical tiers.',
      'Led union negotiation and statutory labor audits with zero work stoppages, ensuring 100% compliance with provincial labor departments (Punjab & Sindh).',
      'Overhauled organizational onboarding academy, reducing fresh graduate time-to-full-productivity from 90 days to 42 days.'
    ],
    dailyTasks: [
      'Coach department directors and team leads on performance management, constructive feedback, and conflict de-escalation.',
      'Audit monthly payroll variances, tax deductions (FBR slabs), EOBI, and social security remittances.',
      'Review talent acquisition pipeline metrics (time-to-hire, offer acceptance rate, source-of-hire quality).',
      'Conduct exit interviews and confidential employee grievance hearings.',
      'Lead leadership development workshops and organizational succession planning reviews.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'In-depth mastery of Pakistan Labor Laws (Workmen Compensation, Industrial Relations Act, Payment of Wages, EOBI/SESSI)',
        'Compensation & Benefits (C&B) Design & Job Grading Methodology (Hay Group / Mercer frameworks)',
        'HRIS Architecture & Analytics (Workday, SAP SuccessFactors, BambooHR)',
        'Workplace Investigation & Grievance Resolution Protocol'
      ],
      essentialSoftSkills: [
        'Impeccable Confidentiality & Ethical Integrity',
        'Assertive Diplomacy & Emotional Equilibrium',
        'Strategic Influence with Department Executives',
        'Empathetic Listening & Coaching Ability'
      ],
      techStackOrTools: ['SAP SuccessFactors', 'Workday', 'BambooHR', 'Microsoft Excel (Advanced)', 'Lattice / 15Five', 'Slack / Teams'],
      redFlagsAndDealbreakers: [
        'Treating HR as purely administrative paper-filing rather than a commercial business partner.',
        'Breaching confidentiality regarding employee salaries, medical conditions, or disciplinary proceedings.',
        'Inability to analyze workforce turnover and compensation numbers using Excel.',
        'Avoiding difficult termination or performance critique conversations.'
      ],
      typicalInterviewFocus: [
        'Scenario: "A top-billing sales director is verbally mistreating subordinates—how do you handle investigations without losing key revenue?"',
        'Knowledge Check: Statutory compliance regarding maternity leave, provident fund rules, and severance calculations under Pakistani law.'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'BBA / MBA in Human Resources, Industrial Relations, or Organizational Psychology',
        'SHRM-CP / SHRM-SCP or CIPD Level 5/7 certification highly preferred for multinational roles',
        'Law degree (LLB) with labor law specialization is a distinct competitive advantage'
      ],
      experiencePrerequisites: [
        '4 to 8 years of progressive HR experience, including at least 2 years managing teams or acting as dedicated HRBP',
        'Demonstrated track record of implementing performance management systems and managing labor disputes'
      ],
      workEnvironmentContext:
        'Corporate office environment with regular travel to regional branch offices, warehouses, and factory manufacturing complexes for workforce engagement and labor inspections.',
      regulatoryAndComplianceStandards: [
        'Industrial and Commercial Employment (Standing Orders) Ordinance',
        'Employees’ Old-Age Benefits Act (EOBI) & Provincial Social Security (PESSI / SESSI)',
        'Protection against Harassment of Women at the Workplace Act 2010',
        'Factories Act 1934 and Industrial Relations Act (IRA)'
      ],
      cognitiveAndPhysicalDemands: [
        'High emotional stamina to navigate sensitive disputes, terminations, and employee stress',
        'Cognitive balance between organizational commercial profitability and ethical employee welfare'
      ]
    },
    transferableSkills: [
      {
        skill: 'Negotiation & Conflict Mediation',
        description: 'Resolving deadlocks between factions with competing interests while preserving working relationships.',
        crossIndustryApplication: 'Transferable to Legal Advisory, Commercial Sales, Procurement, and Executive Management.',
        howToDemonstrateInResume: 'Mediated 14 inter-departmental resource disputes, achieving unanimous agreement on staffing allocations without project delay.'
      },
      {
        skill: 'Organizational Diagnosis & Change Management',
        description: 'Analyzing team dysfunctions, structural bottlenecks, and leading company-wide operational reorganizations.',
        crossIndustryApplication: 'Directly applicable to Management Consulting, Chief of Staff, and Operational Turnaround.',
        howToDemonstrateInResume: 'Spearheaded agile organizational restructuring across 5 business units, eliminating redundant reporting layers and saving PKR 18M annually.'
      },
      {
        skill: 'Data-Driven Retention Analytics',
        description: 'Using statistical regression and employee survey data to diagnose early flight risk signals.',
        crossIndustryApplication: 'Transferable to Customer Success, Product Analytics, and Risk Advisory.',
        howToDemonstrateInResume: 'Built predictive attrition model identifying 8 risk markers, enabling preemptive interventions that retained 92% of critical engineers.'
      }
    ],
    keyPerformanceIndicators: [
      'High-performer retention rate ($\ge 90\\%$ target)',
      'Employee Engagement & Culture Score (eNPS)',
      'Time-to-fill critical leadership vacancies (< 45 days)',
      'Zero statutory labor regulatory violations or audit fines'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 250,000 - 480,000 / month (Senior HR Director: 600k - 1M+)',
      globalUSD: '$75,000 - $140,000 / year (International HRBP / People Lead)'
    },
    careerProgression: [
      'HR Executive / Talent Officer (Years 1-3)',
      'Assistant HR Manager / HRBP (Years 3-5)',
      'Human Resources Manager (Years 5-8)',
      'Head of People & Culture / HR Director (Years 9+)'
    ],
    recommendedCertifications: [
      'SHRM-CP / SHRM-SCP (Society for Human Resource Management)',
      'CIPD Level 5 / Level 7 Associate Diploma in People Management',
      'Hogan Assessment Certification',
      'Certified Compensation Professional (CCP)'
    ]
  },

  // 3. TALENT ACQUISITION & RECRUITMENT SPECIALIST
  {
    id: 'hr-officer-talent-acquisition',
    title: 'Talent Acquisition & People Operations Specialist',
    category: 'Human Resources & Corporate Strategy',
    badge: 'High Industry Demand',
    summary:
      'Sources, interviews, and closes top talent across technology, engineering, and corporate domains. Crafts employer branding campaigns, optimizes ATS applicant funnels, and guarantees pristine candidate experiences.',
    primaryResponsibilities: [
      'Orchestrated end-to-end recruitment lifecycle for 85+ technical, commercial, and executive hires within 12 months, slashing average time-to-hire from 52 to 27 days.',
      'Sourced passive senior engineering candidates via LinkedIn Recruiter and technical communities, generating a 42% qualified phone screen rate.',
      'Revamped campus recruitment roadshow across FAST, NUST, and LUMS, attracting 1,400+ fresh graduate applicants for technical MTO batch.',
      'Implemented structured competency-based interviewing rubrics, reducing 90-day new-hire voluntary turnover to under 3%.',
      'Standardized automated candidate rejection communications with constructive feedback, elevating company Glassdoor employer rating from 3.6 to 4.6 stars.'
    ],
    dailyTasks: [
      'Execute Boolean search queries on LinkedIn Recruiter, GitHub, and Rozee.pk to headhunt specialized talent.',
      'Conduct 4-6 initial video pre-screens daily evaluating cultural alignment and salary expectations.',
      'Liaise with engineering directors and department heads to calibrate job descriptions and interview scorecards.',
      'Draft formal job offers, calculate compensation packages, and negotiate closing terms with candidates.',
      'Manage ATS candidate stages and prepare weekly recruiting metrics reports for management.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Advanced Boolean Search & Talent Sourcing Strategy',
        'Applicant Tracking Systems (Lever, Greenhouse, Workable, Zoho Recruit)',
        'Competency-Based Behavioral Interviewing (STAR Methodology)',
        'Salary Benchmarking & Candidate Offer Negotiation'
      ],
      essentialSoftSkills: [
        'High Persuasion & Active Listening',
        'Candidate Experience Empathy & Punctuality',
        'Tenacity in Closing Competitive Multiple-Offer Candidates',
        'Clear, Engaging Written Outreach Pitching'
      ],
      techStackOrTools: ['LinkedIn Recruiter', 'Greenhouse / Lever', 'Rozee.pk', 'Google Sheets / Excel', 'Calendly', 'Canva (Employer Branding)'],
      redFlagsAndDealbreakers: [
        'Ghosting candidates without status updates (destroys employer reputation).',
        'Inability to understand the technical stack of roles they are hiring for.',
        'Relying solely on inbound applicants without active outbound headhunting.',
        'Mismatched salary expectations brought late into final interview rounds.'
      ],
      typicalInterviewFocus: [
        'Roleplay: "Pitch our mid-tier software company to a senior engineer who already holds an offer from Systems Limited or VentureDive."',
        'Metric Review: How do you balance recruitment speed vs. quality of hire?'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'Bachelors in Human Resources, Business Administration, Psychology, or Computer Science',
        'Relevant certifications in technical recruiting or behavioral assessment'
      ],
      experiencePrerequisites: [
        '1 to 3 years of hands-on recruitment experience in high-volume agencies or corporate tech scale-ups'
      ],
      workEnvironmentContext:
        'Fast-paced corporate office or hybrid/remote setup. Requires extensive phone and video screen time, university campus visits, and job fair attendances.',
      regulatoryAndComplianceStandards: [
        'Equal Employment Opportunity principles & non-discriminatory hiring',
        'Candidate data privacy and personal record retention regulations'
      ],
      cognitiveAndPhysicalDemands: [
        'High verbal stamina to conduct continuous interviews without cognitive fatigue',
        'Rapid assessment capability to spot behavioral inconsistencies in candidate resumes'
      ]
    },
    transferableSkills: [
      {
        skill: 'Executive Pitching & Persuasive Selling',
        description: 'Selling vision, culture, and career trajectory to skeptical high-demand individuals.',
        crossIndustryApplication: 'Directly transferable to B2B Sales, Business Development, and Venture Capital.',
        howToDemonstrateInResume: 'Persuaded 6 senior Silicon Valley remote contractors to join Pakistani engineering office with 100% offer acceptance.'
      },
      {
        skill: 'Funnel Optimization & Pipeline Analytics',
        description: 'Treating candidate pipelines as conversion funnels and identifying drop-off stages.',
        crossIndustryApplication: 'Directly transferable to Digital Marketing, Growth Hacking, and Sales Ops.',
        howToDemonstrateInResume: 'Analyzed recruitment conversion bottlenecks, improving candidate interview-to-offer ratio from 12% to 28%.'
      }
    ],
    keyPerformanceIndicators: [
      'Time-to-Fill (Target < 30 days)',
      'Offer Acceptance Rate ($\ge 85\\%$ target)',
      'Cost-Per-Hire reduction',
      'Candidate Satisfaction (CSAT) rating'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 100,000 - 180,000 / month (Lead Recruiter: 220k - 350k)',
      globalUSD: '$45,000 - $80,000 / year (Remote Technical Recruiter in USD)'
    },
    careerProgression: [
      'Talent Acquisition Coordinator (Year 1)',
      'Senior Talent Acquisition Specialist (Years 2-4)',
      'Talent Acquisition Lead / Recruitment Manager (Years 5-7)',
      'Head of Talent & Employer Brand (Years 8+)'
    ],
    recommendedCertifications: [
      'LinkedIn Certified Professional–Recruiter',
      'AIRS Certified Internet Recruiter (CIR)',
      'SHRM Talent Acquisition Specialty Credential'
    ]
  },

  // 4. FULL-STACK SOFTWARE ENGINEER
  {
    id: 'software-engineer-fullstack',
    title: 'Full-Stack Software Engineer',
    category: 'Software & Technology',
    badge: 'High Global & Remote Demand',
    summary:
      'Architects and scales modern web applications, resilient backend microservices, and reactive client frontends. Highly sought after by Pakistani IT powerhouses (Systems Limited, 10Pearls, VentureDive) and international US/EU remote teams paying in US Dollars.',
    primaryResponsibilities: [
      'Architected scalable microservices using Node.js/Go and React/TypeScript, handling over 1.2M daily active user requests with 99.98% uptime.',
      'Refactored legacy database queries and implemented distributed Redis caching, reducing average API p99 latency from 420ms to 78ms.',
      'Authored automated test suites (unit, integration, end-to-end via Jest/Playwright), improving continuous deployment test coverage from 62% to 91%.',
      'Engineered real-time notification microservice utilizing WebSockets and Apache Kafka, eliminating event drops during peak e-commerce flash sales.',
      'Mentored 4 junior engineers on clean architectural patterns, TypeScript type safety, and rigorous peer code review standards.'
    ],
    dailyTasks: [
      'Collaborate in agile sprint ceremonies (daily standups, refinement, retrospectives).',
      'Write modular, clean, and well-typed code for frontend user flows and backend REST/GraphQL APIs.',
      'Conduct rigorous code reviews focusing on security, performance, and maintainability.',
      'Monitor production services using Datadog, Sentry, or Grafana dashboards to proactively address errors.',
      'Draft technical design documents (RFCs) for upcoming system features.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Proficiency in React / Next.js, TypeScript, and Modern Node.js or Python/Go',
        'Database Architecture (PostgreSQL indexing, query optimization, ACID transactions, NoSQL MongoDB)',
        'RESTful & GraphQL API Design & Authentication (JWT, OAuth2, RBAC)',
        'Containerization & Cloud Basics (Docker, Kubernetes, AWS S3/EC2, CI/CD pipelines)'
      ],
      essentialSoftSkills: [
        'Asynchronous Communication for Distributed/Remote Teams',
        'Pragmatic Problem Solving (balancing technical debt vs. delivery speed)',
        'Curiosity & Fast Adoption of Emerging AI Coding Tooling (Cursor, Copilot, LLM APIs)',
        'Constructive Peer Review & Collaborative Demeanor'
      ],
      techStackOrTools: ['React', 'Next.js', 'Node.js', 'PostgreSQL', 'Docker', 'Redis', 'TailwindCSS', 'AWS / GCP'],
      redFlagsAndDealbreakers: [
        'Inability to write basic algorithmic or data structure logic without LLM generation.',
        'Ignoring edge cases (network timeouts, unhandled promise rejections, security sanitization).',
        'Not having a personal GitHub with demonstrable projects or live code samples.',
        'Defensiveness when receiving architectural feedback during interviews.'
      ],
      typicalInterviewFocus: [
        'Live Coding / System Design: "Design an idempotency system for a fintech payment gateway or URL shortener."',
        'Deep-dive into past architectural decisions and production incidents handled.'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'BS in Computer Science, Software Engineering, Computer Engineering, or Information Technology',
        'Accredited universities (FAST-NUCES, NUST, GIKI, COMSATS, PUCIT, ITU, NED, etc.) or verifiable equivalent portfolio'
      ],
      experiencePrerequisites: [
        'Associate: 0-2 years (strong capstone FYP, open-source or internship project)',
        'Mid-Level: 2-5 years leading feature squads and cloud deployment',
        'Senior: 5+ years driving system architecture, RFCs, and reliability'
      ],
      workEnvironmentContext:
        'Office-based tech campus or 100% remote home office. Requires reliable high-speed broadband, dual monitors, and uninterrupted UPS/solar power backup in Pakistan.',
      regulatoryAndComplianceStandards: [
        'OWASP Top 10 Web Application Security Standards',
        'Data Protection & Privacy Regulations (GDPR, SBP Cybersecurity Framework for Fintechs)',
        'PSEB (Pakistan Software Export Board) IT Exporter Compliance'
      ],
      cognitiveAndPhysicalDemands: [
        'Intense logical concentration, abstract reasoning, and debugging patience',
        'Prolonged seated workstation posture (ergonomic chair and setup essential)'
      ]
    },
    transferableSkills: [
      {
        skill: 'Systems Thinking & Architectural Deconstruction',
        description: 'Analyzing how interconnected systems, microservices, and databases behave under stress.',
        crossIndustryApplication: 'Transferable to Supply Chain Planning, Financial Engineering, and Quantitative Risk.',
        howToDemonstrateInResume: 'Designed fault-tolerant payment retry queue that eliminated transaction dropping during network brownouts.'
      },
      {
        skill: 'Root-Cause Incident Post-Mortem',
        description: 'Investigating high-pressure failures without assigning blame, producing preventative engineering measures.',
        crossIndustryApplication: 'Valuable in Operations Management, Aviation Safety, and Clinical Healthcare Systems.',
        howToDemonstrateInResume: 'Authored root-cause post-mortem for critical DB deadlock, instituting query timeouts that prevented future crashes.'
      }
    ],
    keyPerformanceIndicators: [
      'Sprint velocity and on-time sprint ticket delivery',
      'Production bug defect escape rate (< 2% target)',
      'Service reliability (99.95%+ uptime SLA compliance)',
      'Code review turnaround time (< 18 hours)'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 140,000 - 350,000 / month (Senior: 450k - 900k+)',
      globalUSD: '$60,000 - $130,000 / year (Remote Contractor / Global Tech)'
    },
    careerProgression: [
      'Associate / Junior Software Engineer (0-2 years)',
      'Mid-Level Software Engineer (2-4 years)',
      'Senior Software Engineer (5-7 years)',
      'Staff Engineer / Engineering Manager (8+ years)'
    ],
    recommendedCertifications: [
      'AWS Certified Solutions Architect Associate',
      'Meta Front-End / Back-End Professional Certificate',
      'Docker Certified Associate',
      'PostgreSQL Certified Professional'
    ]
  },

  // 5. DATA ANALYST & BUSINESS INTELLIGENCE
  {
    id: 'data-analyst-bi',
    title: 'Data Analyst & Business Intelligence Specialist',
    category: 'Data & Analytics',
    badge: 'Exploding Market Need',
    summary:
      'Transforms raw transactional, customer, and telemetry datasets into actionable commercial intelligence. Builds dynamic dashboards and statistical models for telecoms (Jazz, Telenor), fintechs (Easypaisa, SadaPay), and retail FMCGs.',
    primaryResponsibilities: [
      'Engineered executive automated PowerBI dashboards for C-suite, consolidating sales, inventory, and churn across 4 regions into a single real-time view.',
      'Authored complex SQL queries (Window functions, CTEs, self-joins) extracting insights from 25M+ rows of customer interaction data in PostgreSQL and Snowflake.',
      'Identified an 11% leakage in customer checkout funnels through cohort analysis, proposing UI modifications that recovered PKR 3.8M in lost monthly GMV.',
      'Built automated data validation pipelines using Python (Pandas/Great Expectations), eliminating 94% of manual Excel reconciliation hours.',
      'Designed and analyzed A/B test experiments for new subscription tier pricing, calculating statistical significance ($p < 0.01$) before national rollout.'
    ],
    dailyTasks: [
      'Write optimized SQL queries to answer urgent commercial questions from product and marketing leads.',
      'Maintain and refresh production PowerBI/Tableau semantic models and DAX measures.',
      'Clean dirty transactional data exports using Python or Excel Power Query.',
      'Present weekly performance findings to business unit directors with clear commercial interpretations.',
      'Collaborate with data engineers to define schema requirements for new data warehouse tables.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Advanced SQL (Subqueries, Window Functions, Performance Tuning)',
        'Data Visualization & Dashboarding (PowerBI with complex DAX, Tableau, or Metabase)',
        'Python for Data Analysis (Pandas, NumPy, Matplotlib/Seaborn)',
        'Statistical Thinking (Hypothesis testing, distributions, regression analysis)'
      ],
      essentialSoftSkills: [
        'Commercial Acumen (connecting numbers directly to company profit & loss)',
        'Intellectual Skepticism (verifying anomalies before presenting conclusions)',
        'Data Storytelling for Non-Technical Audiences',
        'Prioritization under competing stakeholder requests'
      ],
      techStackOrTools: ['SQL (PostgreSQL/MySQL/Snowflake)', 'PowerBI (DAX)', 'Python (Pandas)', 'Tableau', 'Excel (Power Query)', 'Git'],
      redFlagsAndDealbreakers: [
        'Presenting charts without business context or actionable recommendations.',
        'Not checking for data bias, missing values, or survivorship bias in analysis.',
        'Relying solely on drag-and-drop tools without writing raw SQL queries.',
        'Inability to explain the difference between correlation and causation during interviews.'
      ],
      typicalInterviewFocus: [
        'Live SQL Assessment: "Write a query finding the top 3 highest-spending users per city over the last 90 days."',
        'Business Case: "Our mobile app monthly active users (MAU) dropped 8% last month. Walk us through your diagnosis step by step."'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'BS in Computer Science, Data Science, Statistics, Mathematics, Economics, or Accounting & Finance',
        'Google Data Analytics or Microsoft Certified Data Analyst Associate certification'
      ],
      experiencePrerequisites: [
        '0 to 2 years in data reporting, business analysis, or financial modeling'
      ],
      workEnvironmentContext:
        'Corporate office or flexible hybrid/remote environment. Heavy dual-screen analysis work and cross-departmental presentations.',
      regulatoryAndComplianceStandards: [
        'Data Privacy & Anonymization Standards (GDPR, SBP Customer Data Protection Rules)',
        'SOC2 compliance for cloud data storage and access permissions'
      ],
      cognitiveAndPhysicalDemands: [
        'High cognitive concentration for detecting statistical anomalies and debugging queries'
      ]
    },
    transferableSkills: [
      {
        skill: 'Metric Deconstruction & Hypothesis Testing',
        description: 'Isolating factors driving KPI drops and designing experiments to validate solutions.',
        crossIndustryApplication: 'Crucial for Product Management, Financial Trading, Operations, and Medical Research.',
        howToDemonstrateInResume: 'Isolated 3 variables causing user churn, designing A/B test that increased retention by 14%.'
      },
      {
        skill: 'Data Translation for Non-Technical Leaders',
        description: 'Distilling complex regressions into simple, decisive business actions.',
        crossIndustryApplication: 'Essential in Corporate Strategy, Public Policy, and Executive Advisory.',
        howToDemonstrateInResume: 'Presented multi-million PKR budget reallocation model to board of directors with zero technical confusion.'
      }
    ],
    keyPerformanceIndicators: [
      'Dashboard user adoption and weekly active usage by stakeholders',
      'Query turnaround time for ad-hoc business requests (< 24 hours)',
      'Accuracy of data models and absence of reporting discrepancies',
      'Measurable financial impact generated from data insights'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 110,000 - 240,000 / month (Senior Lead: 280k - 500k)',
      globalUSD: '$50,000 - $95,000 / year (Remote Global Data Analyst)'
    },
    careerProgression: [
      'Junior Data Analyst (0-2 years)',
      'Data Analyst / BI Specialist (2-4 years)',
      'Senior BI Analyst / Analytics Engineer (4-6 years)',
      'Head of Data & Business Intelligence (7+ years)'
    ],
    recommendedCertifications: [
      'Microsoft Certified: PowerBI Data Analyst Associate (PL-300)',
      'Google Data Analytics Professional Certificate',
      'IBM Data Science Professional Certificate',
      'Snowflake SnowPro Core Certification'
    ]
  },

  // 6. BRAND MANAGER & PRODUCT MARKETING LEAD
  {
    id: 'brand-manager-fmcg',
    title: 'Brand Manager & Product Marketing Lead',
    category: 'Marketing & Commercial Strategy',
    badge: 'Premier Commercial Role',
    summary:
      'P&L owner for recognized consumer brands in FMCG and consumer tech. Coordinates 360-degree advertising campaigns, brand packaging redesigns, pricing strategies, and retail activations to capture market share.',
    primaryResponsibilities: [
      'Managed P&L for PKR 850M consumer packaged goods brand, achieving 18% year-over-year revenue expansion and 2.4 percentage points gain in national market share.',
      'Spearheaded 360-degree Ramadan national brand campaign across television, digital video, outdoor billboards, and retail trade, garnering 48M verified impressions.',
      'Directed consumer research focus groups across Lahore, Karachi, and Multan to formulate brand repositioning for younger Gen-Z demographics.',
      'Partnered with R&D and factory manufacturing teams to launch 2 innovative product variants, reaching break-even profitability in under 5 months.',
      'Restructured promotional trade spend allocation, improving Return on Marketing Investment (ROMI) by 26% through optimized distributor pricing.'
    ],
    dailyTasks: [
      'Review daily Nielsen retail audit data and distributor primary sales dispatches.',
      'Collaborate with creative advertising and media buying agencies on campaign storyboards and copy.',
      'Coordinate with supply chain planners to guarantee packaging material readiness for upcoming brand pushes.',
      'Track monthly brand budget utilization and P&L marketing expenses.',
      'Conduct store visits to general trade and modern trade outlets to inspect point-of-sale shelf displays.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Brand P&L Financial Management & Gross Margin Analysis',
        'Consumer Research & Retail Audit Interpretation (Nielsen, Kantar, Retail Panel Data)',
        '360-Degree Integrated Marketing Communication (IMC) Strategy',
        'Agency Management & Creative Direction (Brief formulation, Media Planning)'
      ],
      essentialSoftSkills: [
        'Cultural Intuition & Consumer Empathy',
        'Persuasive Leadership with Creative & Commercial Teams',
        'Decisiveness under Market Ambiguity',
        'Mastery of Emotional Brand Storytelling'
      ],
      techStackOrTools: ['Nielsen Retail Data / Kantar', 'Microsoft Excel (P&L Models)', 'PowerPoint / Keynote', 'Meta Ads Manager', 'Google Analytics'],
      redFlagsAndDealbreakers: [
        'Focusing only on creative aesthetics without understanding unit economics or gross margins.',
        'Inability to read a retail audit report or explain market share calculation.',
        'Producing generic advertising copy disconnected from real Pakistani consumer behaviors.',
        'Blaming sales or supply chain for marketing campaign underperformance.'
      ],
      typicalInterviewFocus: [
        'Commercial Challenge: "Our competitor launched a price-slashed 20% extra SKU. How do you respond without eroding your brand premium?"',
        'Creative Critique: Present your analysis of an existing Pakistani brand campaign that succeeded or failed.'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'BBA / MBA in Marketing, Commercial Strategy, or Communications from accredited institutions (LUMS, IBA, LSE, FAST, etc.)'
      ],
      experiencePrerequisites: [
        '3 to 6 years of progressive brand management experience in top FMCGs or consumer goods companies'
      ],
      workEnvironmentContext:
        'Corporate office headquarters with regular travel to advertising agency production studios, film shoot locations, and nationwide wholesale markets.',
      regulatoryAndComplianceStandards: [
        'Pakistan Standards & Quality Control Authority (PSQCA) packaging guidelines',
        'Pakistan Advertising Association (PAA) and PEMRA broadcasting codes',
        'Halal certification and consumer protection laws'
      ],
      cognitiveAndPhysicalDemands: [
        'Stamina for multi-day film shoots and high-pressure executive campaign reviews'
      ]
    },
    transferableSkills: [
      {
        skill: 'P&L Financial Accountability',
        description: 'Managing revenue, cost of goods sold (COGS), and marketing investments to drive net margin.',
        crossIndustryApplication: 'Essential for General Management, Tech Product Management, and Entrepreneurship.',
        howToDemonstrateInResume: 'Managed PKR 650M brand budget, driving 18% top-line growth while preserving 34% gross profit margin.'
      },
      {
        skill: 'Consumer Psychology & Market Segmentation',
        description: 'Identifying unmet consumer desires and positioning products to solve psychological pain points.',
        crossIndustryApplication: 'Applicable in UX Research, Political Strategy, and Venture Capital.',
        howToDemonstrateInResume: 'Identified unmet Gen-Z snacking habit, conceptualizing mini-sachet SKU that captured 14% new buyer penetration.'
      }
    ],
    keyPerformanceIndicators: [
      'Brand Market Share growth (Nielsen RMS points)',
      'Brand Health Metrics (Spontaneous Awareness, Brand Consideration, Net Promoter Score)',
      'Return on Marketing Investment (ROMI)',
      'Gross Profit margin and net revenue target achievement'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 220,000 - 450,000 / month (Senior Brand Lead: 500k - 850k+)',
      globalUSD: '$65,000 - $120,000 / year (International Product Marketing Lead)'
    },
    careerProgression: [
      'Assistant Brand Manager (Years 1-3)',
      'Brand Manager (Years 3-6)',
      'Senior Brand Manager / Category Lead (Years 6-9)',
      'Marketing Director / Chief Commercial Officer (Years 10+)'
    ],
    recommendedCertifications: [
      'Mini MBA in Marketing (Mark Ritson)',
      'HubSpot Inbound Marketing / Content Strategy',
      'Google Digital Marketing & E-Commerce Professional Certificate'
    ]
  },

  // 7. FINANCIAL ANALYST & CORPORATE FINANCE
  {
    id: 'financial-analyst-corporate',
    title: 'Financial Analyst & Corporate Finance Associate',
    category: 'Finance & Banking',
    badge: 'High Prestige & Analytical Depth',
    summary:
      'Engineers discounted cash flow (DCF) models, conducts CAPEX appraisals, forecasts working capital, and analyzes corporate financing structures for conglomerates, investment banks, and commercial leaders.',
    primaryResponsibilities: [
      'Constructed 3-statement dynamic financial models and 5-year forecasts in Excel, evaluating a PKR 1.8B capital expansion project that achieved 22% Internal Rate of Return (IRR).',
      'Spearheaded monthly variance reporting across 7 business units, detecting PKR 14M in recurring cost overruns and recommending corrective budgetary freezes.',
      'Evaluated foreign currency debt exposure against Pakistani Rupee depreciation, formulating interest rate hedging scenarios presented to the Chief Financial Officer.',
      'Prepared detailed investor presentation memoranda and financial information packages for syndicated debt financing with commercial banking consortiums.',
      'Automated rolling cash flow projections, optimizing treasury short-term money market placements to generate PKR 6.2M in additional yield.'
    ],
    dailyTasks: [
      'Update and reconcile daily bank liquidity positions and foreign exchange exposures.',
      'Analyze departmental monthly expense variance against approved annual operating plans (AOP).',
      'Conduct scenario sensitivity analysis for inflation, interest rate hikes (SBP policy rate), and raw material import duties.',
      'Draft board executive finance summaries and investor relations briefings.',
      'Collaborate with statutory audit teams to verify balance sheet schedules.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Advanced Financial Modeling (DCF, LBO, 3-Statement, Scenario Planning, Sensitivity Tables)',
        'Thorough grasp of IFRS (International Financial Reporting Standards) & Corporate Tax',
        'ERP Proficiency (SAP FICO, Oracle Financials)',
        'Valuation Methodologies (WACC, Multiple-based Comps, IRR, NPV)'
      ],
      essentialSoftSkills: [
        'Meticulous Attention to Detail (zero tolerance for formula or reconciliation errors)',
        'High Discretion & Integrity Handling Material Non-Public Information',
        'Ability to Explain Financial Nuances to Non-Finance Department Heads',
        'Stress Tolerance during Quarterly & Year-End Closings'
      ],
      techStackOrTools: ['Microsoft Excel (Advanced VBA, Power Query)', 'SAP S/4HANA (FICO)', 'Bloomberg Terminal / Capital IQ', 'PowerBI / Tableau'],
      redFlagsAndDealbreakers: [
        'Hardcoding numbers inside Excel formulas without transparent audit trails.',
        'Not knowing how SBP policy rate changes affect corporate borrowing costs.',
        'Inability to read or reconstruct a Cash Flow Statement from Balance Sheet changes.',
        'Careless formatting errors in executive financial decks.'
      ],
      typicalInterviewFocus: [
        'Technical Modeling Test: Build a fully dynamic 3-statement model with debt schedule and revolving credit facility in 90 minutes.',
        'Conceptual Question: "If depreciation increases by PKR 10M, walk me through how it affects the Income Statement, Cash Flow, and Balance Sheet."'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'BSc / BS in Accounting & Finance, Economics, or Business Administration',
        'Chartered Financial Analyst (CFA Level 1/2 cleared) or ACCA / ICAP part-qualified candidates hold significant advantage'
      ],
      experiencePrerequisites: [
        '1 to 3 years in corporate finance, financial planning & analysis (FP&A), equity research, or Big-4 transaction advisory'
      ],
      workEnvironmentContext:
        'Corporate boardroom and finance floor. Requires high concentration during financial closing windows and budget review cycles.',
      regulatoryAndComplianceStandards: [
        'Securities and Exchange Commission of Pakistan (SECP) Regulations',
        'State Bank of Pakistan (SBP) Foreign Exchange Manual and Prudential Regulations',
        'Federal Board of Revenue (FBR) Corporate Income Tax & Sales Tax statutes'
      ],
      cognitiveAndPhysicalDemands: [
        'Extreme numerical vigilance and multi-hour focused spreadsheet modeling'
      ]
    },
    transferableSkills: [
      {
        skill: 'Capital Allocation & ROI Rigor',
        description: 'Evaluating every initiative through the lens of return on invested capital and opportunity cost.',
        crossIndustryApplication: 'Essential in Venture Capital, Private Equity, Real Estate Development, and Executive Strategy.',
        howToDemonstrateInResume: 'Screened 14 proposed CAPEX investments, reallocating PKR 45M into high-yield initiatives that raised portfolio IRR by 4.2%.'
      },
      {
        skill: 'Scenario & Downside Risk Modeling',
        description: 'Stress-testing business assumptions under macroeconomic shocks, currency drops, and inflation surges.',
        crossIndustryApplication: 'Transferable to Enterprise Risk Management, Supply Chain Strategy, and Insurance.',
        howToDemonstrateInResume: 'Modeled currency devaluation impact across 5 exchange rate scenarios, protecting PKR 80M in import margins.'
      }
    ],
    keyPerformanceIndicators: [
      'Financial forecast variance accuracy (< 5% error threshold)',
      'CAPEX project delivery within modeled budget',
      'Timely completion of month-end financial reviews',
      'Identified cost-saving opportunities implemented'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 130,000 - 280,000 / month (Senior Finance Manager: 350k - 650k+)',
      globalUSD: '$65,000 - $115,000 / year (Remote Corporate FP&A Analyst)'
    },
    careerProgression: [
      'Junior Financial Analyst (Years 1-2)',
      'Financial Analyst / FP&A Associate (Years 2-4)',
      'Finance Manager / Treasury Lead (Years 5-8)',
      'Chief Financial Officer (CFO) / Finance Director (Years 9+)'
    ],
    recommendedCertifications: [
      'CFA (Chartered Financial Analyst) Charter',
      'Financial Modeling & Valuation Analyst (FMVA) – CFI',
      'ACCA (Association of Chartered Certified Accountants)',
      'Certified Management Accountant (CMA)'
    ]
  },

  // 8. SUPPLY CHAIN & LOGISTICS PLANNER
  {
    id: 'supply-chain-planner',
    title: 'Supply Chain & Logistics Planner',
    category: 'Supply Chain & Manufacturing',
    badge: 'Critical National Backbone',
    summary:
      'Coordinates national demand forecasting, factory production schedules, raw material procurement, and line-haul distribution networks across Pakistani industrial corridors.',
    primaryResponsibilities: [
      'Orchestrated monthly Sales & Operations Planning (S&OP) across 4 manufacturing plants, cutting inventory holding cost by PKR 16.5M while elevating order fulfillment rate to 98.4%.',
      'Constructed demand forecast models integrating seasonal wedding peaks, Ramadan surges, and distributor trends, improving forecast accuracy from 71% to 89%.',
      'Mitigated raw material import shipment delays through secondary local supplier qualification, averting factory shutdown during maritime shipping disruptions.',
      'Redesigned freight line-haul routes connecting Karachi seaport to Punjab distribution centers, lowering transportation costs by 12%.',
      'Standardized warehouse safety protocols and cycle count auditing, reducing stock shrinkage from 2.8% to 0.4% across 6 regional warehouses.'
    ],
    dailyTasks: [
      'Monitor raw material inventory safety stock levels and trigger automated SAP purchase orders.',
      'Coordinate with plant production supervisors to adjust daily packaging line schedules based on urgent stock orders.',
      'Liaise with freight transport contractors regarding truck availability, diesel price adjustments, and dispatch timing.',
      'Review distributor backorder lists and resolve delivery bottlenecks with territory sales leads.',
      'Track container port clearance times at Karachi Port (KPT) and Port Qasim.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Sales & Operations Planning (S&OP) Process Execution',
        'ERP Mastery (SAP MM, PP, and SD modules)',
        'Inventory Optimization (Economic Order Quantity - EOQ, Safety Stock modeling)',
        'Transport & Freight Rate Negotiation'
      ],
      essentialSoftSkills: [
        'Crisis Management under Unexpected Disruptions',
        'Assertive Coordination with Factory Floor Staff and Commercial Directors',
        'Logical Calmness under High Operational Pressure',
        'Field Reality Empathy (understanding transport driver challenges)'
      ],
      techStackOrTools: ['SAP ERP (MM/PP/SD)', 'Oracle SCM', 'Microsoft Excel (Solver, What-If Analysis)', 'PowerBI', 'WMS / TMS Software'],
      redFlagsAndDealbreakers: [
        'Making production schedules based on gut feelings rather than empirical demand data.',
        'Lack of visibility into warehouse stock levels or freight transit times.',
        'Refusing to visit industrial plants, loading docks, or distribution hubs in person.',
        'Inability to calculate carrying costs versus stock-out penalty trade-offs.'
      ],
      typicalInterviewFocus: [
        'Operational Simulation: "A key imported packaging film is stuck at Karachi Port for 2 weeks, and the plant runs out in 3 days. What are your immediate moves?"',
        'Quantitative Question: Calculate safety stock required when lead-time variability doubles.'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'BSc in Industrial Engineering, Supply Chain Management, Mechanical Engineering, or MBA Operations'
      ],
      experiencePrerequisites: [
        '1 to 3 years in demand planning, logistics coordination, or factory production planning'
      ],
      workEnvironmentContext:
        'Industrial factory plants, distribution warehouses (forklifts, dust, noise), transport terminals, and corporate offices.',
      regulatoryAndComplianceStandards: [
        'Customs Act 1969 and Pakistan Single Window (PSW) import clearance regulations',
        'Hazardous Material Transport & Storage Regulations',
        'ISO 22000 (Food Safety) and Good Distribution Practice (GDP)'
      ],
      cognitiveAndPhysicalDemands: [
        'High operational stamina and readiness to resolve midnight transport or dispatch crises'
      ]
    },
    transferableSkills: [
      {
        skill: 'Bottleneck Identification & Flow Optimization',
        description: 'Applying Theory of Constraints to eliminate blockages across end-to-end operational pipelines.',
        crossIndustryApplication: 'Transferable to Software CI/CD Pipelines, Hospital Emergency Ops, and Fintech Transactions.',
        howToDemonstrateInResume: 'Identified warehouse loading bottleneck, sequencing dock doors to accelerate dispatch turnaround by 35%.'
      },
      {
        skill: 'Contractor Sourcing & Procurement Negotiation',
        description: 'Evaluating vendor reliability, structuring service level agreements (SLAs), and cutting procurement expenses.',
        crossIndustryApplication: 'Applicable in Construction, Tech Vendor Procurement, and Government Contracting.',
        howToDemonstrateInResume: 'Renegotiated nationwide fleet contract with 5 logistics partners, saving PKR 8.4M while enforcing 99% on-time delivery.'
      }
    ],
    keyPerformanceIndicators: [
      'On-Time In-Full (OTIF) delivery percentage ($\ge 98\\%$ target)',
      'Inventory Days of Supply (DOS) reduction',
      'Demand Forecast Accuracy (MAD / MAPE metrics)',
      'Total logistics cost as a percentage of revenue'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 120,000 - 240,000 / month (Senior Supply Chain Lead: 300k - 550k)',
      globalUSD: '$60,000 - $110,000 / year (International Supply Chain Planner)'
    },
    careerProgression: [
      'Supply Chain Executive / Logistics Officer (Years 1-3)',
      'Demand / Supply Planner (Years 3-5)',
      'Supply Chain Manager / S&OP Lead (Years 5-8)',
      'Head of Supply Chain / Operations Director (Years 9+)'
    ],
    recommendedCertifications: [
      'CSCP (Certified Supply Chain Professional) – APICS / ASCM',
      'CPIM (Certified in Planning and Inventory Management)',
      'Six Sigma Green / Black Belt',
      'Chartered Institute of Logistics and Transport (CILT)'
    ]
  },

  // 9. OPERATIONS & PROJECT MANAGER
  {
    id: 'operations-project-manager',
    title: 'Operations & Project Manager',
    category: 'Operations & Project Management',
    badge: 'Universal Industry Relevance',
    summary:
      'Coordinates cross-functional initiatives, project milestones, resource allocation, and operational efficiency across software houses, telecoms, engineering contractors, and retail conglomerates.',
    primaryResponsibilities: [
      'Directed multi-disciplinary squad of 24 engineers, designers, and business analysts to deliver enterprise fintech product on time and 8% under budget.',
      'Overhauled operational workflows using Lean Six Sigma methodologies, eliminating 18 redundant approval steps and accelerating project velocity by 31%.',
      'Formulated risk mitigation matrix across 6 parallel project tracks, preventing critical client milestone penalties.',
      'Facilitated sprint planning, retrospectives, and milestone burn-down tracking across remote and onsite engineering cohorts.',
      'Managed external client vendor contracts worth PKR 120M, ensuring 100% adherence to agreed Service Level Agreements (SLAs).'
    ],
    dailyTasks: [
      'Run morning standup check-ins and unblock operational roadblocks for squad members.',
      'Track project budget consumption, milestone schedules, and resource capacity in Jira and Asana.',
      'Draft weekly executive status reports for internal C-suite and external enterprise clients.',
      'Conduct risk assessments and contingency planning for upcoming feature deployments.',
      'Collaborate with HR and department leads on technical resource staffing forecasts.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Agile Scrum & Waterfall Methodologies (Scrum ceremonies, backlog grooming, sprint velocity)',
        'Project Management Tools (Jira, Confluence, Asana, Monday.com, MS Project)',
        'Budget & Resource Capacity Management',
        'Risk Identification & Contingency Planning'
      ],
      essentialSoftSkills: [
        'Decisive Leadership without Bureaucracy',
        'High Emotional Intelligence & Team Motivation',
        'Assertive Client Expectation Management',
        'Calmness under Tight Delivery Deadlines'
      ],
      techStackOrTools: ['Jira', 'Confluence', 'Asana', 'Trello', 'Slack', 'Microsoft Excel / Project', 'Miro / Figma'],
      redFlagsAndDealbreakers: [
        'Acting as a passive note-taker rather than driving proactive accountability.',
        'Hiding project delays until the final deadline week.',
        'Inability to shield the technical execution team from unreasonable scope creep.',
        'Micromanaging tasks rather than focusing on milestone outcomes.'
      ],
      typicalInterviewFocus: [
        'Crisis Scenario: "Your engineering lead resigns 3 weeks before a major multi-million PKR client launch. What is your recovery playbook?"',
        'Framework Application: Walk us through how you handle scope creep when a high-profile client demands extra features without budget increase.'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'Bachelors in Computer Science, Engineering, Project Management, or Business Administration',
        'PMP (Project Management Professional) or Scrum Master (CSM/PSM) certification highly advantageous'
      ],
      experiencePrerequisites: [
        '2 to 5 years in project coordination, operational management, or scrum facilitation'
      ],
      workEnvironmentContext:
        'Corporate office or hybrid/remote setup. Requires continuous communication across engineering, commercial, and executive teams.',
      regulatoryAndComplianceStandards: [
        'ISO 27001 (Information Security Management)',
        'Corporate Service Level Agreements (SLAs) and Non-Disclosure Agreements (NDAs)'
      ],
      cognitiveAndPhysicalDemands: [
        'High multitasking bandwidth and stress resilience during critical delivery milestones'
      ]
    },
    transferableSkills: [
      {
        skill: 'Cross-Functional Resource Orchestration',
        description: 'Aligning individuals from diverse technical, commercial, and creative backgrounds toward a single objective.',
        crossIndustryApplication: 'Transferable to Construction Management, Film Production, Healthcare, and Government Projects.',
        howToDemonstrateInResume: 'Orchestrated 32-person team across engineering, compliance, and marketing to launch product 2 weeks ahead of schedule.'
      },
      {
        skill: 'Scope Management & Client Negotiation',
        description: 'Managing client demands diplomatically while safeguarding project timeline and team sanity.',
        crossIndustryApplication: 'Essential in Consulting, Enterprise Sales, and Contract Management.',
        howToDemonstrateInResume: 'Successfully pushed back on 14 scope creep requests, preserving project budget and preventing PKR 4M in penalty fees.'
      }
    ],
    keyPerformanceIndicators: [
      'On-Time, In-Scope, and In-Budget milestone delivery rate ($\ge 92\\%$ target)',
      'Sprint velocity predictability and team capacity utilization',
      'Client Satisfaction (CSAT) rating',
      'Risk mitigation effectiveness'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 150,000 - 320,000 / month (Senior Program Lead: 380k - 650k)',
      globalUSD: '$65,000 - $125,000 / year (Remote Technical Project Manager)'
    },
    careerProgression: [
      'Project Coordinator / Associate (Years 1-2)',
      'Project Manager / Scrum Master (Years 2-5)',
      'Senior Project / Program Manager (Years 5-8)',
      'Director of Operations / VP of Delivery (Years 9+)'
    ],
    recommendedCertifications: [
      'PMP (Project Management Professional) – PMI',
      'Certified ScrumMaster (CSM) or Professional Scrum Master (PSM I/II)',
      'CAPM (Certified Associate in Project Management)',
      'PRINCE2 Practitioner'
    ]
  },

  // 10. UI/UX & PRODUCT DESIGNER
  {
    id: 'uiux-product-designer',
    title: 'UI/UX & Product Designer',
    category: 'Design & Product',
    badge: 'High Global & Remote Appeal',
    summary:
      'Designs human-centric user experiences, intuitive mobile app wireframes, and scalable design systems for fintech apps (SadaPay, Nayapay), e-commerce marketplaces (Daraz), and global SaaS platforms.',
    primaryResponsibilities: [
      'Designed end-to-end mobile user journey for fintech digital wallet, reducing user onboarding drop-off rate from 38% to 14%.',
      'Architected comprehensive design system in Figma with 450+ accessible components, accelerating frontend engineering build speed by 35%.',
      'Conducted 28 in-depth qualitative usability interviews across diverse Pakistani demographics, turning findings into high-impact UX redesigns.',
      'Created interactive high-fidelity micro-interaction prototypes, reducing user confusion during biometric authentication checkouts.',
      'Collaborated closely with mobile engineers, inspecting staging builds to ensure 100% pixel-perfect implementation of layouts.'
    ],
    dailyTasks: [
      'Build user flows, low-fidelity wireframes, and production-ready visual UI layouts in Figma.',
      'Conduct usability testing sessions with real users, observing friction points and task completion times.',
      'Maintain design system tokens, typography scales, and component variants.',
      'Hand off detailed design specs and assets to frontend engineering teams.',
      'Analyze Mixpanel and Hotjar heatmaps to identify where users abandon digital journeys.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Mastery of Figma (Auto-layout, Components, Variants, Interactive Prototyping)',
        'User Research Methodologies (Usability testing, Card sorting, User journey mapping)',
        'Design Systems Architecture & Accessibility Standards (WCAG 2.1 AA)',
        'Understanding of Mobile Human Interface Guidelines (iOS & Material Design)'
      ],
      essentialSoftSkills: [
        'Deep Empathy for Non-Tech-Savvy Everyday Users',
        'Ability to Articulate Design Rationale with Business Impact',
        'Collaborative Receptivity to Engineering Feedback',
        'Curiosity about Real-World Psychological Behaviors'
      ],
      techStackOrTools: ['Figma', 'FigJam / Miro', 'Adobe Creative Suite', 'Protopie', 'Hotjar / Mixpanel', 'Zeplin'],
      redFlagsAndDealbreakers: [
        'Portfolios showcasing pretty Dribbble mockups without real user problem definitions or design thinking rationale.',
        'Designing interfaces that ignore local cultural context (e.g., Urdu right-to-left layout or low-end Android phone screens).',
        'Defensiveness when user testing invalidates personal design assumptions.',
        'Not knowing how frontend CSS flexbox or grid translates to design auto-layout.'
      ],
      typicalInterviewFocus: [
        'Portfolio Deep-Dive: Walk through one project from initial messy user research through to measured business outcomes.',
        'Whiteboard Design Challenge: "Design a simple digital medicine ordering experience for elderly Pakistani diabetic patients in 45 minutes."'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'Bachelors in Design, Fine Arts, Human-Computer Interaction (HCI), Computer Science, or verifiable high-quality case study portfolio'
      ],
      experiencePrerequisites: [
        '1 to 3 years designing live mobile and responsive web applications'
      ],
      workEnvironmentContext:
        'Modern creative studio or flexible remote home office. High requirement for color-calibrated display monitors and quiet user testing environments.',
      regulatoryAndComplianceStandards: [
        'Web Content Accessibility Guidelines (WCAG 2.1 AA)',
        'Digital consent and user data privacy standards'
      ],
      cognitiveAndPhysicalDemands: [
        'Intense visual focus, aesthetic sensitivity, and empathy fatigue management during user research'
      ]
    },
    transferableSkills: [
      {
        skill: 'User Empathy & Qualitative Research',
        description: 'Observing human behavior objectively to identify unstated psychological obstacles.',
        crossIndustryApplication: 'Transferable to Market Research, Clinical Psychology, Brand Strategy, and Healthcare Delivery.',
        howToDemonstrateInResume: 'Conducted 24 field interviews with rural merchants, redesigning app interface to double daily digital payments.'
      },
      {
        skill: 'Rapid Prototyping & Assumption De-risking',
        description: 'Building low-cost simulations to test commercial assumptions before committing expensive engineering resources.',
        crossIndustryApplication: 'Essential in Lean Startup Venture Building, Industrial Product Design, and Service Architecture.',
        howToDemonstrateInResume: 'Prototyped 3 checkout concepts in 4 days, validating optimal flow with users before engineering wrote a single line of code.'
      }
    ],
    keyPerformanceIndicators: [
      'User Task Success Rate and Time-on-Task reduction',
      'Onboarding and checkout funnel conversion rate improvement',
      'System Usability Scale (SUS) score ($\ge 80\\%$ target)',
      'Design-to-code velocity and absence of visual implementation bugs'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 120,000 - 260,000 / month (Lead Product Designer: 320k - 600k+)',
      globalUSD: '$55,000 - $110,000 / year (Remote Global Product Designer in USD)'
    },
    careerProgression: [
      'Junior UI/UX Designer (Years 1-2)',
      'Product Designer (Years 2-4)',
      'Senior Product Designer / Design Lead (Years 5-7)',
      'Head of Design / VP of User Experience (Years 8+)'
    ],
    recommendedCertifications: [
      'Google UX Design Professional Certificate',
      'Nielsen Norman Group (NN/g) UX Master Certified',
      'Interaction Design Foundation (IxDF) Specialist Certifications'
    ]
  },

  // 11. DEVOPS & CLOUD INFRASTRUCTURE ENGINEER
  {
    id: 'devops-cloud-engineer',
    title: 'DevOps & Cloud Infrastructure Engineer',
    category: 'Software & Technology',
    badge: 'Top Tier Compensation',
    summary:
      'Engineers automated CI/CD pipelines, provisions multi-region cloud infrastructure using Terraform, and safeguards high-availability Kubernetes microservices for high-growth tech firms.',
    primaryResponsibilities: [
      'Architected resilient AWS multi-AZ cloud infrastructure utilizing Terraform, achieving 99.99% system uptime across 40+ microservices.',
      'Constructed automated CI/CD deployment pipelines via GitHub Actions and ArgoCD, slashing deployment cycle duration from 4 hours to 11 minutes.',
      'Orchestrated cost-optimization audit across cloud resources, identifying oversized database instances and cutting monthly AWS bill by 32% ($14,000/month saved).',
      'Implemented centralized logging and observability stack using Prometheus, Grafana, and OpenTelemetry, reducing Mean Time to Detection (MTTD) by 65%.',
      'Enforced enterprise zero-trust security architecture, automated IAM credential rotations, and encrypted data at rest and in transit.'
    ],
    dailyTasks: [
      'Maintain Kubernetes clusters (EKS/GKE), ensuring nodes scale automatically during traffic spikes.',
      'Review and apply Terraform pull requests for infrastructure modifications.',
      'Investigate production infrastructure alerts and latency spikes with on-call rotation squads.',
      'Automate backup recovery testing and disaster recovery simulation exercises.',
      'Advise software developers on container security scanning and optimal Dockerfile builds.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Cloud Infrastructure Mastery (AWS, GCP, or Azure)',
        'Containerization & Orchestration (Docker, Kubernetes, Helm)',
        'Infrastructure as Code (Terraform, CloudFormation)',
        'CI/CD Pipeline Automation (GitHub Actions, GitLab CI, ArgoCD)'
      ],
      essentialSoftSkills: [
        'Calmness & Methodical Precision during Production Outages',
        'Automation Obsession (eliminating repetitive manual steps)',
        'Security-First Mindset',
        'Clear Technical Communication under High Urgency'
      ],
      techStackOrTools: ['Kubernetes', 'Docker', 'Terraform', 'AWS / GCP', 'GitHub Actions', 'Prometheus / Grafana', 'Linux (Ubuntu/Debian)', 'Bash / Python'],
      redFlagsAndDealbreakers: [
        'Making manual configuration changes directly inside the cloud web console instead of Terraform.',
        'Not having automated database backups or never testing disaster recovery restoration.',
        'Hardcoding secret API keys or passwords inside repository code.',
        'Blaming software engineers during outages instead of building systemic automated guardrails.'
      ],
      typicalInterviewFocus: [
        'Live Scenario: "Our production web server is suddenly reporting 100% CPU and dropping 50% of user traffic. Walk us through how you diagnose and remediate on the terminal."',
        'Architecture Design: Design a multi-region disaster recovery setup with sub-15-minute RPO and RTO.'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'BS in Computer Science, Software Engineering, Telecommunications, or Information Technology'
      ],
      experiencePrerequisites: [
        '2 to 5 years in systems administration, cloud engineering, or software deployment'
      ],
      workEnvironmentContext:
        'Remote-first or corporate tech campus. Requires high-availability on-call rotation readiness for production emergencies.',
      regulatoryAndComplianceStandards: [
        'SOC2 Type II, ISO 27001, and PCI-DSS financial cloud security compliance'
      ],
      cognitiveAndPhysicalDemands: [
        'High psychological resilience to manage production downtime emergencies without panic'
      ]
    },
    transferableSkills: [
      {
        skill: 'Automation & Repetitive Waste Elimination',
        description: 'Automating complex manual procedures into reproducible code scripts.',
        crossIndustryApplication: 'Transferable to Industrial Robotics, Lab Automation, Financial Trading, and Supply Chain.',
        howToDemonstrateInResume: 'Automated 18 manual server setup tasks into single Terraform script, saving 12 developer hours weekly.'
      },
      {
        skill: 'Observability & Proactive Anomaly Detection',
        description: 'Instrumenting systems with telemetry to catch degradation signals before catastrophe occurs.',
        crossIndustryApplication: 'Valuable in Healthcare Patient Monitoring, Flight Telemetry, and Fraud Prevention.',
        howToDemonstrateInResume: 'Engineered alert thresholds that caught memory leak 4 hours before service failure, averting customer outage.'
      }
    ],
    keyPerformanceIndicators: [
      'Mean Time to Recovery (MTTR < 20 minutes)',
      'Service Availability SLA (99.95%+ uptime target)',
      'Deployment frequency and change failure rate (< 3%)',
      'Monthly cloud infrastructure spend efficiency'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 180,000 - 450,000 / month (Senior Cloud Architect: 550k - 1M+)',
      globalUSD: '$75,000 - $145,000 / year (Remote Global DevOps Engineer in USD)'
    },
    careerProgression: [
      'Junior DevOps / Cloud Engineer (Years 1-2)',
      'DevOps / SRE Engineer (Years 2-5)',
      'Senior DevOps Engineer / Cloud Architect (Years 5-8)',
      'Head of Infrastructure / Platform Engineering Director (Years 9+)'
    ],
    recommendedCertifications: [
      'AWS Certified Solutions Architect – Associate / Professional',
      'Certified Kubernetes Administrator (CKA)',
      'HashiCorp Certified: Terraform Associate',
      'Google Cloud Certified Professional Cloud Architect'
    ]
  },

  // 12. B2B SALES & BUSINESS DEVELOPMENT
  {
    id: 'b2b-sales-business-development',
    title: 'B2B Enterprise Sales & Client Relationship Manager',
    category: 'Sales & Business Development',
    badge: 'Direct Revenue Driver',
    summary:
      'Drives corporate revenue growth by identifying high-value corporate prospects, pitching enterprise telecom, software, or logistics solutions, and negotiating multi-million PKR contracts with decision-makers.',
    primaryResponsibilities: [
      'Generated PKR 140M in new corporate enterprise contracts within 12 months, exceeding annual sales quota by 28% across telecom and cloud services.',
      'Prospected, pitched, and closed 18 Tier-1 corporate clients (banks, FMCGs, universities), managing sales cycles from initial discovery to contract signing.',
      'Engineered structured Request for Proposal (RFP) response system, improving competitive tender win rate from 24% to 46%.',
      'Collaborated with engineering delivery squads to ensure post-sale onboarding met promised SLAs, preserving a 96% client contract renewal rate.',
      'Represented company at major national trade expos, building senior C-suite executive relationships that fueled a robust sales pipeline.'
    ],
    dailyTasks: [
      'Conduct outbound outreach via LinkedIn, phone, and warm referrals to corporate CEOs, CTOs, and Procurement Directors.',
      'Lead 2-3 formal executive sales presentations and solution demonstrations daily.',
      'Draft customized commercial proposals, pricing quotes, and master service agreements.',
      'Log deal stages, notes, and probability weights inside CRM (Salesforce / HubSpot).',
      'Follow up on invoice clearance and contract renewals with existing accounts.'
    ],
    employerLookingFor: {
      mustHaveHardSkills: [
        'Consultative & Value-Based Selling Methodologies (MEDDPICC, Challenger Sale, SPIN)',
        'Pipeline & CRM Management (Salesforce, HubSpot)',
        'Contract Negotiation & Legal Terms Structuring',
        'Executive Financial Proposal Writing & ROI Justification'
      ],
      essentialSoftSkills: [
        'Unshakeable Rejection Resilience & High Drive',
        'Executive Presence & Articulate Persuasion',
        'Active Listening to Diagnose Underlying Commercial Pain Points',
        'Trust-Building Integrity & Relationship Longevity'
      ],
      techStackOrTools: ['HubSpot / Salesforce CRM', 'LinkedIn Sales Navigator', 'Zoom / Teams', 'Microsoft PowerPoint / Pitch', 'DocuSign'],
      redFlagsAndDealbreakers: [
        'Pushing product features rather than solving the client’s financial pain points.',
        'Giving up after 1 or 2 follow-ups (deals often require 6-8 touchpoints to close).',
        'Overpromising technical capabilities that engineering teams cannot deliver.',
        'Not knowing your own pricing margins or competitor alternatives during client negotiations.'
      ],
      typicalInterviewFocus: [
        'Cold Pitch Simulation: "You have 3 minutes with the CTO of a major commercial bank. Pitch our cybersecurity or cloud solution from scratch."',
        'Objection Handling: How do you respond when a procurement director says your price is 30% higher than a local competitor?'
      ]
    },
    occupationalRequirements: {
      minimumEducation: [
        'BBA / BS in Marketing, Business Administration, Engineering, or Economics'
      ],
      experiencePrerequisites: [
        '2 to 5 years in B2B corporate sales, software SaaS, enterprise telecom, or corporate banking'
      ],
      workEnvironmentContext:
        'Corporate office and client executive boardrooms. Extensive inter-city travel for client visits and trade expos.',
      regulatoryAndComplianceStandards: [
        'Public Procurement Regulatory Authority (PPRA) rules for government contracts',
        'Commercial contract law and standard indemnity / liability clauses'
      ],
      cognitiveAndPhysicalDemands: [
        'High emotional resilience to handle frequent rejection and demanding quarterly quotas'
      ]
    },
    transferableSkills: [
      {
        skill: 'Executive Persuasion & Trust Building',
        description: 'Establishing rapid credibility with C-suite decision-makers and overcoming skepticism.',
        crossIndustryApplication: 'Transferable to Fundraising, Political Diplomacy, Real Estate, and Management Consulting.',
        howToDemonstrateInResume: 'Built relationship with 12 C-level executives, securing exclusive sole-source enterprise contracts.'
      },
      {
        skill: 'Contract Negotiation & Commercial Compromise',
        description: 'Negotiating high-stakes commercial terms while preserving profit margins and client goodwill.',
        crossIndustryApplication: 'Directly applicable to Procurement, Strategic Partnerships, and M&A.',
        howToDemonstrateInResume: 'Negotiated 3-year enterprise software contract, successfully defending pricing against 20% discount demand.'
      }
    ],
    keyPerformanceIndicators: [
      'Quarterly & Annual Quota Attainment percentage ($\ge 100\\%$ target)',
      'Sales Pipeline Velocity and Deal Conversion Rate',
      'Average Deal Size and Customer Lifetime Value (LTV)',
      'Client Retention & Contract Renewal Rate ($\ge 90\\%$ target)'
    ],
    averageSalary: {
      pakistanPKR: 'PKR 120,000 - 250,000 / month (Plus Uncapped Sales Commissions: Total 300k - 700k+)',
      globalUSD: '$60,000 - $130,000 / year (Remote Account Executive in USD)'
    },
    careerProgression: [
      'Business Development Representative (Years 1-2)',
      'Enterprise Account Executive (Years 2-5)',
      'Senior Sales Manager (Years 5-8)',
      'VP of Sales / Chief Revenue Officer (Years 9+)'
    ],
    recommendedCertifications: [
      'HubSpot Inbound Sales & Sales Enablement Certification',
      'Certified Professional Sales Person (CPSP) – NASP',
      'Challenger Sales Methodology Credential'
    ]
  }
];
