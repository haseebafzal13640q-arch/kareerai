export interface KeyDutyCategory {
  category: string;
  weight: string;
  duties: string[];
}

export interface KSAO {
  knowledge: string[];
  skills: string[];
  abilities: string[];
  other: string[];
}

export interface CompensationTier {
  entry: string;
  median: string;
  topTier: string;
}

export interface Compensation {
  currency: string;
  range: string;
  frequency: string;
  tierBreakdown: CompensationTier;
  benefitsAndPerks: string[];
  marketInsights: string;
}

export interface OnetCritique {
  staticLimitation: string;
  modernDynamicAdvantage: string;
}

export interface InterviewQuestion {
  type: string;
  question: string;
  whatToLookFor: string;
}

export interface JobAnalysisResult {
  jobTitle: string;
  roleSummary: string;
  department: string;
  reportingTo: string;
  keyDuties: KeyDutyCategory[];
  ksao: KSAO;
  compensation: Compensation;
  onetCritique: OnetCritique;
  interviewQuestions: InterviewQuestion[];
}

export interface ScoreBreakdown {
  keywordMatch: number;
  actionVerbStrength: number;
  quantifiedImpact: number;
  layoutClarity: number;
}

export interface MissingKeyword {
  keyword: string;
  importance: 'High' | 'Medium' | 'Low';
  contextSuggestion: string;
}

export interface BulletRewrite {
  original: string;
  rewritten: string;
  critique: string;
}

export interface AtsAnalysisResult {
  atsScore: number;
  verdict: string;
  scoreBreakdown: ScoreBreakdown;
  detectedStrengths: string[];
  criticalGaps: string[];
  missingKeywords: MissingKeyword[];
  bulletPointRewrites: BulletRewrite[];
  haseebAdvice: string;
}

export interface CourseRecommendation {
  title: string;
  provider: string;
  estimatedDuration: string;
  focusArea: string;
  reason: string;
}

export interface RoadmapPhase {
  focus: string;
  milestones: string[];
  capstone: string;
}

export interface SkillGapResult {
  targetRole: string;
  readinessScore: number;
  summary: string;
  skillGaps: {
    criticalGaps: string[];
    secondaryGaps: string[];
    emergingDifferentiators: string[];
  };
  recommendedCourses: CourseRecommendation[];
  roadmap: {
    phase1_30Days: RoadmapPhase;
    phase2_60Days: RoadmapPhase;
    phase3_90Days: RoadmapPhase;
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

// Resume Builder Types
export type ResumeTemplateId =
  | 'harvard-classic'
  | 'fresh-graduate'
  | 'silicon-valley'
  | 'europass-minimal'
  | 'executive-leadership'
  | 'modern-minimalist'
  | 'creative-portfolio'
  | 'academic-research';

export interface ResumeWorkExperience {
  id: string;
  jobTitle: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
  bullets: string[];
}

export interface ResumeEducation {
  id: string;
  degree: string;
  institution: string;
  location: string;
  graduationYear: string;
  gpaOrHonors?: string;
  details?: string;
}

export interface ResumeProject {
  id: string;
  name: string;
  role?: string;
  link?: string;
  technologies: string;
  bullets: string[];
}

export interface ResumeCertification {
  id: string;
  name: string;
  issuer: string;
  year: string;
}

export interface ResumeData {
  personalInfo: {
    fullName: string;
    title: string;
    email: string;
    phone: string;
    location: string;
    linkedin: string;
    github?: string;
    portfolio?: string;
  };
  summary: string;
  experience: ResumeWorkExperience[];
  education: ResumeEducation[];
  skills: {
    technical: string[];
    tools: string[];
    soft: string[];
  };
  projects: ResumeProject[];
  certifications: ResumeCertification[];
  languages: string[];
}

export interface TransferableSkillItem {
  skill: string;
  description: string;
  crossIndustryApplication: string;
  howToDemonstrateInResume: string;
}

export interface OccupationalRequirementsData {
  minimumEducation: string[];
  experiencePrerequisites: string[];
  workEnvironmentContext: string;
  regulatoryAndComplianceStandards: string[];
  cognitiveAndPhysicalDemands: string[];
}

// Profession Task & Duties Intelligence
export interface ProfessionDutyData {
  id: string;
  title: string;
  category: string;
  badge?: string;
  summary: string;
  primaryResponsibilities: string[];
  dailyTasks: string[];
  employerLookingFor: {
    mustHaveHardSkills: string[];
    essentialSoftSkills: string[];
    techStackOrTools: string[];
    redFlagsAndDealbreakers: string[];
    typicalInterviewFocus: string[];
  };
  occupationalRequirements: OccupationalRequirementsData;
  transferableSkills: TransferableSkillItem[];
  keyPerformanceIndicators: string[];
  averageSalary: {
    pakistanPKR: string;
    globalUSD: string;
  };
  careerProgression: string[];
  recommendedCertifications: string[];
}

export interface PakistaniJob {
  id: string;
  title: string;
  company: string;
  category: 'internship' | 'onsite' | 'remote';
  industry: string;
  department: string;
  location: string;
  city: string;
  province: string;
  stipendOrSalary: string;
  currency: 'PKR' | 'USD';
  experience: string;
  education: string;
  deadline: string;
  logoText: string;
  badgeColor: string;
  description: string;
  keyRequirements: string[];
  perks: string[];
  applyUrl: string;
}

export type ActiveTab =
  | 'pak-jobs'
  | 'resume-builder'
  | 'profession-duties'
  | 'job-architect'
  | 'ats-optimizer'
  | 'skill-gap'
  | 'market-radar'
  | 'consult-haseeb';
