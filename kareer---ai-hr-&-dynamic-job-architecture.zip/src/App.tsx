import React, { useState, useEffect } from 'react';
import { ActiveTab, ResumeData } from './types';
import { Navbar } from './components/Navbar';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { DisclaimerModal } from './components/DisclaimerModal';
import { PakistaniJobsHub } from './components/PakistaniJobsHub';
import { ResumeBuilder } from './components/ResumeBuilder';
import { ProfessionDutiesExplorer } from './components/ProfessionDutiesExplorer';
import { DynamicJobArchitect } from './components/DynamicJobArchitect';
import { AtsOptimizer } from './components/AtsOptimizer';
import { SkillGapRoadmap } from './components/SkillGapRoadmap';
import { MarketRadar } from './components/MarketRadar';
import { ConsultHaseeb } from './components/ConsultHaseeb';
import {
  ShieldAlert,
  Sparkles,
  Cpu,
  Layers,
  FileCheck,
  TrendingUp,
  Compass,
  CheckCircle,
  ExternalLink,
  GraduationCap,
  FileText,
  BookOpen
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('pak-jobs');
  const [isDisclaimerModalOpen, setIsDisclaimerModalOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);

  // Cross-tab interaction states
  const [architectPreload, setArchitectPreload] = useState<{
    role?: string;
    company?: string;
    region?: string;
  }>({});
  const [atsPreloadRole, setAtsPreloadRole] = useState<string>('');
  const [atsPreloadResumeText, setAtsPreloadResumeText] = useState<string>('');

  useEffect(() => {
    const accepted = localStorage.getItem('kareer_terms_accepted');
    if (!accepted) {
      setIsOnboardingOpen(true);
    }
  }, []);

  const handleAcceptTerms = () => {
    localStorage.setItem('kareer_terms_accepted', 'true');
    setIsOnboardingOpen(false);
  };

  const handleSelectRoleForAnalysis = (roleTitle: string, company: string, location: string) => {
    setArchitectPreload({
      role: roleTitle,
      company: company,
      region: location.includes('Remote') ? 'Pakistan (100% Remote PKR)' : `Pakistan (${location})`,
    });
    setActiveTab('job-architect');
  };

  const handleOpenATS = (roleTitle: string) => {
    setAtsPreloadRole(roleTitle);
    setActiveTab('ats-optimizer');
  };

  const handleSendToAtsFromResume = (resumeText: string, jobTitle: string) => {
    setAtsPreloadRole(jobTitle);
    setAtsPreloadResumeText(resumeText);
    setActiveTab('ats-optimizer');
  };

  const handleBuildResumeForRole = (roleTitle: string, company: string) => {
    // Optionally update existing draft title if desired
    try {
      const saved = localStorage.getItem('kareer_resume_draft');
      if (saved) {
        const parsed: ResumeData = JSON.parse(saved);
        parsed.personalInfo.title = `${roleTitle} | Candidate for ${company}`;
        localStorage.setItem('kareer_resume_draft', JSON.stringify(parsed));
      }
    } catch (e) {
      console.error(e);
    }
    setActiveTab('resume-builder');
  };

  const handleInsertDutiesIntoResume = (duties: string[], roleTitle: string) => {
    try {
      const saved = localStorage.getItem('kareer_resume_draft');
      if (saved) {
        const parsed: ResumeData = JSON.parse(saved);
        if (parsed.experience.length > 0) {
          parsed.experience[0].bullets.push(...duties.slice(0, 3));
        } else {
          parsed.experience.push({
            id: `exp-${Date.now()}`,
            jobTitle: roleTitle,
            company: 'Target Organization',
            location: 'Pakistan',
            startDate: 'Jan 2024',
            endDate: 'Present',
            isCurrent: true,
            bullets: duties.slice(0, 3),
          });
        }
        localStorage.setItem('kareer_resume_draft', JSON.stringify(parsed));
      }
    } catch (e) {
      console.error(e);
    }
    setActiveTab('resume-builder');
  };

  const handleArchitectFromDuties = (roleTitle: string, category: string) => {
    setArchitectPreload({
      role: roleTitle,
      company: category.includes('Multinational') ? 'Nestlé / PepsiCo / FMCG' : 'Industry Leader',
      region: 'Pakistan (PKR) & Global Remote',
    });
    setActiveTab('job-architect');
  };

  const handleExplorePakJobs = (_searchQuery: string) => {
    setActiveTab('pak-jobs');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-['Plus_Jakarta_Sans',sans-serif] selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Professional Boundary Notification Banner */}
      <DisclaimerBanner onOpenModal={() => setIsDisclaimerModalOpen(true)} />

      {/* Main Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenDisclaimer={() => setIsDisclaimerModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'pak-jobs' && (
          <PakistaniJobsHub
            onSelectRoleForAnalysis={handleSelectRoleForAnalysis}
            onOpenATS={handleOpenATS}
            onBuildResumeForRole={handleBuildResumeForRole}
          />
        )}
        {activeTab === 'resume-builder' && (
          <ResumeBuilder
            onSendToAts={handleSendToAtsFromResume}
            onOpenProfessionDutiesTab={() => setActiveTab('profession-duties')}
          />
        )}
        {activeTab === 'profession-duties' && (
          <ProfessionDutiesExplorer
            onInsertIntoResume={handleInsertDutiesIntoResume}
            onArchitectRole={handleArchitectFromDuties}
            onExplorePakJobs={handleExplorePakJobs}
          />
        )}
        {activeTab === 'job-architect' && (
          <DynamicJobArchitect
            initialRole={architectPreload.role}
            initialCompany={architectPreload.company}
            initialRegion={architectPreload.region}
          />
        )}
        {activeTab === 'ats-optimizer' && (
          <AtsOptimizer
            initialJobTitle={atsPreloadRole}
            initialResumeText={atsPreloadResumeText}
          />
        )}
        {activeTab === 'skill-gap' && <SkillGapRoadmap />}
        {activeTab === 'market-radar' && <MarketRadar />}
        {activeTab === 'consult-haseeb' && <ConsultHaseeb />}
      </main>

      {/* Professional Footer - Clean Light Theme */}
      <footer className="mt-16 bg-white border-t border-slate-200 py-12 text-xs text-slate-600 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2 space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center font-black text-white text-sm">
                  K
                </div>
                <span className="text-lg font-bold text-slate-900 tracking-tight">Kareer</span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                  AI Job Intelligence Platform
                </span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed max-w-md">
                Led by <strong className="text-slate-800">Haseeb</strong>, Lead AI HR Consultant & Job Analysis Architect. Built for Pakistani students and professionals to easily access internships, onsite roles at multinationals (Nestlé, PepsiCo, Systems Limited, Engro), international ATS resume templates, and high-paying remote USD careers with real salary transparency.
              </p>
            </div>

            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Platform Capabilities</h4>
              <ul className="space-y-1.5 text-xs text-slate-600">
                <li>
                  <button onClick={() => setActiveTab('pak-jobs')} className="hover:text-emerald-700 transition-colors">
                    Pakistan Jobs & Internships
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('resume-builder')} className="hover:text-emerald-700 transition-colors font-medium text-emerald-800">
                    Resume Builder (5 International Templates)
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('profession-duties')} className="hover:text-emerald-700 transition-colors font-medium text-emerald-800">
                    Profession Duties & Employer Wishlists
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('job-architect')} className="hover:text-emerald-700 transition-colors">
                    Dynamic Job Analysis & KSAOs
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('ats-optimizer')} className="hover:text-emerald-700 transition-colors">
                    ATS Resume Optimization (XYZ Formula)
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('skill-gap')} className="hover:text-emerald-700 transition-colors">
                    30-60-90 Day Skill Gap Roadmaps
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('market-radar')} className="hover:text-emerald-700 transition-colors">
                    Localized Market Comp (PKR & USD)
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('consult-haseeb')} className="hover:text-emerald-700 transition-colors">
                    Direct Advisory with Haseeb
                  </button>
                </li>
              </ul>
            </div>

            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Governance & Ethics</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Kareer operates under strict ethical AI boundaries. All outputs are advisory recommendations for drafting, evaluation, and student skill enhancement.
              </p>
              <button
                onClick={() => setIsDisclaimerModalOpen(true)}
                className="inline-flex items-center gap-1.5 text-xs text-emerald-700 hover:text-emerald-900 font-semibold"
              >
                <span>Read Ethical Disclaimer</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Bottom Copyright & Disclaimer Statement */}
          <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-[11px] text-slate-500">
            <p>
              &copy; {new Date().getFullYear()} Kareer Platform. Designed for Pakistani Students, Graduates, and Remote Professionals.
            </p>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Haseeb AI Engine: Online & Active (Light Theme)</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Onboarding Welcome Modal */}
      <DisclaimerModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
        onAccept={handleAcceptTerms}
        isOnboarding={true}
      />

      {/* Standard Settings / Disclaimer Modal */}
      <DisclaimerModal
        isOpen={isDisclaimerModalOpen}
        onClose={() => setIsDisclaimerModalOpen(false)}
        isOnboarding={false}
      />
    </div>
  );
}
